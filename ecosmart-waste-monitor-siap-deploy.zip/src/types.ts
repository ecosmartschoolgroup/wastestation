export type Peran = 'Siswa' | 'Petugas' | 'Guru' | 'Admin';
export type Jenjang = 'TK' | 'SD' | 'SMP' | 'SMA/SMK';
export type JenisKey = 'Organik' | 'Anorganik' | 'Residu' | 'Elektronik';
export type SumberSetoran = 'IoT' | 'Manual';
export type StatusSetoran = 'Menunggu' | 'Terverifikasi' | 'Ditolak';
export type TipePenyetor = 'Siswa' | 'Kelas';

export interface Pengguna {
  ID_Pengguna: string;
  Email?: string;
  Nama: string;
  Peran: Peran;
  Kelas: string;
  Jenjang: Jenjang;
  Tingkat: string; // TK-A, TK-B, 1..12
  Kartu_RFID?: string;
  Avatar?: string;
  PIN_Gambar?: string[]; // 4 icon keys for SD 1-3 Mode Kelas
  Persetujuan_Ortu: string; // ISO date or empty string if pending
}

export interface Kelas {
  Kelas: string;
  Jenjang: Jenjang;
  Tingkat: string;
  Wali_Kelas: string;
  Kartu_Kelas?: string;
  Jumlah_Siswa: number;
}

export interface JenisSampah {
  Jenis: JenisKey;
  Label_Aplikasi: string;
  Contoh: string;
  Satuan: 'kg' | 'item';
  Poin_per_satuan: number;
  Warna_Tong: string;
  Subjenis: string[];
  Jalur_Input: 'IoT + Manual' | 'Manual saja';
}

export interface Setoran {
  ID: string;
  Tanggal: string; // ISO string Asia/Jakarta
  ID_Pengguna: string;
  Tipe_Penyetor: TipePenyetor;
  Email?: string;
  Nama_Penyetor: string;
  Kelas: string;
  Jenjang: Jenjang;
  Jenis: JenisKey;
  Jenis_Awal: JenisKey;
  Subjenis?: string;
  Berat_kg: number;
  Berat_Awal_kg?: number;
  Jumlah_item?: number;
  Foto?: string;
  Status: StatusSetoran;
  Poin: number;
  Sumber: SumberSetoran;
  Station_ID?: string;
  Diverifikasi_Oleh?: string;
  Waktu_Verifikasi?: string;
  Alasan_Tolak?: string;
  Anomali?: string;
}

export interface KompartemenStatus {
  jenis: 'Organik' | 'Anorganik' | 'Residu';
  label: string;
  isi_persen: number; // 0-100 or -1 for sensor error
  berat_hari_ini: number;
  episode_penuh: boolean;
  waktu_penuh?: string;
  terakhir_dikosongkan?: string;
  sensor_error?: boolean;
}

export interface Station {
  Station_ID: string;
  Nama: string;
  Lokasi: string;
  Jenjang_Target: Jenjang | 'UMUM';
  MODE_JENJANG: 'TK_SD' | 'UMUM';
  Token: string;
  Last_Heartbeat: string;
  WiFi_SSID: string;
  Kompartemen: KompartemenStatus[];
}

export interface PanduanItem {
  ID: string;
  Jenis: JenisKey;
  Item: string;
  Keterangan: string;
  Salah_Kaprah: string;
  Contoh_Masuk: string[];
  Jangan_Masuk: string[];
  Jenjang: Jenjang[];
}

export interface KuisSoal {
  ID: string;
  Jenjang: Jenjang;
  Pertanyaan: string;
  Opsi_A: string;
  Opsi_B: string;
  Opsi_C: string;
  Opsi_D: string;
  Jawaban: 'A' | 'B' | 'C' | 'D';
  Penjelasan: string;
  Jenis_Terkait: JenisKey;
}

export interface KuisHasil {
  ID: string;
  ID_Pengguna: string;
  Email?: string;
  Nama: string;
  Kelas: string;
  Jenjang: Jenjang;
  Tanggal: string;
  Skor: number;
  Total: number;
}

export interface ObservasiTK {
  ID: string;
  Tanggal: string;
  ID_Pengguna: string;
  Nama_Siswa: string;
  Kelas: string;
  Mandiri_Memilah: boolean;
  Kenal_Warna_Tong: boolean;
  Bantu_Teman: boolean;
  Catatan: string;
  Guru: string;
}

export interface NotifikasiLog {
  ID: string;
  Waktu: string;
  Station_ID: string;
  Kompartemen: string;
  Isi_Persen: number;
  Penerima: string[];
  Pesan: string;
  Status: 'Aktif' | 'Dikosongkan';
  Waktu_Kosong?: string;
  Durasi_Respon_Menit?: number;
  Dikosongkan_Oleh?: string;
}

export interface AuditLog {
  ID: string;
  Waktu: string;
  Aktor: string;
  Aksi: string;
  Detail: string;
}

export interface AppDatabase {
  Pengguna: Pengguna[];
  Kelas: Kelas[];
  JenisSampah: JenisSampah[];
  Setoran: Setoran[];
  Stations: Station[];
  Panduan: PanduanItem[];
  Kuis_Soal: KuisSoal[];
  Kuis_Hasil: KuisHasil[];
  Observasi_TK: ObservasiTK[];
  Notifikasi_Log: NotifikasiLog[];
  Audit_Log: AuditLog[];
}

export interface MonthlyBucket {
  bulan: string; // YYYY-MM
  label: string; // e.g. Jun 2026
  organik_kg: number;
  anorganik_kg: number;
  residu_kg: number;
  elektronik_item: number;
  total_kg: number;
  total_poin: number;
  setoran_count: number;
  iot_count: number;
  manual_count: number;
  diversion_rate: number; // % (organik + anorganik) / total_kg
  accuracy_rate: number; // % manual verified with Jenis === Jenis_Awal
  avg_response_min: number;
}

export interface MonthlyAnalyticsReport {
  generatedAt: string;
  periodeBulan: string;
  ringkasan: {
    total_kg: number;
    diversion_rate: number;
    residu_ratio: number;
    akurasi_pilah: number;
    iot_adoption: number;
    avg_response_hours: number;
    efisiensi_per_siswa_kg: number;
    perubahan_residu_pct: number;
  };
  trenBulanan: MonthlyBucket[];
  perJenjang: {
    jenjang: Jenjang;
    total_kg: number;
    jumlah_siswa: number;
    kg_per_siswa: number;
    kelas_aktif_pct: number;
    diversion_rate: number;
  }[];
  insightOtomatis: {
    id: string;
    tingkat: 'info' | 'warning' | 'success';
    judul: string;
    deskripsi: string;
    rekomendasi: string;
  }[];
}
