import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Edit3,
  Cpu,
  Trash2,
  Search,
  Check,
} from 'lucide-react';
import type {
  JenisKey,
  JenisSampah,
  NotifikasiLog,
  Pengguna,
  Setoran,
  Station,
} from '../types.ts';
import { formatJakartaDateTime, formatTimeAgo, getJenisLabel } from '../utils/wasteStyles.ts';

interface EcoRangerViewProps {
  user: Pengguna;
  setoran: Setoran[];
  stations: Station[];
  jenisSampah: JenisSampah[];
  notifikasiLog: NotifikasiLog[];
  onRefresh: () => void;
}

export const EcoRangerView: React.FC<EcoRangerViewProps> = ({
  user,
  setoran,
  stations,
  jenisSampah,
  notifikasiLog,
  onRefresh,
}) => {
  const [tab, setTab] = useState<'Menunggu' | 'Terverifikasi' | 'Ditolak'>('Menunggu');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editWeight, setEditWeight] = useState<number>(0);
  const [editJenis, setEditJenis] = useState<JenisKey>('Anorganik');
  const [rejectTarget, setRejectTarget] = useState<Setoran | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const activeAlerts = notifikasiLog.filter((n) => n.Status === 'Aktif');

  // FR-VF-09: IoT deposits are automatically Terverifikasi and never appear in Menunggu queue
  const filteredSetoran = setoran.filter((s) => {
    if (s.Status !== tab) return false;
    if (tab === 'Menunggu' && s.Sumber === 'IoT') return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      s.Nama_Penyetor.toLowerCase().includes(q) ||
      s.Kelas.toLowerCase().includes(q) ||
      s.Jenis.toLowerCase().includes(q)
    );
  });

  const pendingCount = setoran.filter(
    (s) => s.Status === 'Menunggu' && s.Sumber === 'Manual'
  ).length;

  const startEdit = (item: Setoran) => {
    setEditingId(item.ID);
    setEditWeight(item.Berat_kg);
    setEditJenis(item.Jenis);
  };

  const handleVerify = async (item: Setoran, useEdits: boolean) => {
    setBusyId(item.ID);
    try {
      await fetch(`/api/setoran/${item.ID}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beratBaru: useEdits ? editWeight : item.Berat_kg,
          jenisBaru: useEdits ? editJenis : item.Jenis,
          petugasNama: user.Nama,
        }),
      });
      setEditingId(null);
      onRefresh();
    } finally {
      setBusyId(null);
    }
  };

  const handleReject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectTarget || !rejectReason.trim()) return;
    setBusyId(rejectTarget.ID);
    try {
      await fetch(`/api/setoran/${rejectTarget.ID}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          alasan: rejectReason.trim(),
          petugasNama: user.Nama,
        }),
      });
      setRejectTarget(null);
      setRejectReason('');
      onRefresh();
    } finally {
      setBusyId(null);
    }
  };

  const handleEmptyCompartment = async (
    stationId: string,
    kompartemen: 'Organik' | 'Anorganik' | 'Residu'
  ) => {
    setBusyId(`${stationId}-${kompartemen}`);
    try {
      await fetch(`/api/station/${stationId}/empty`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kompartemen, petugasNama: user.Nama }),
      });
      onRefresh();
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-bold text-slate-900">
          Verifikasi Eco Ranger & Status Tong
        </h2>
        <p className="text-sm text-slate-600">
          Verifikasi setoran manual siswa dan kelola pengosongan kompartemen Smart Waste Station.
        </p>
      </div>

      {/* FR-VF-07 & FR-VF-08: Real-Time Full Bin Banner Alerts (>80%) */}
      {activeAlerts.length > 0 && (
        <div className="space-y-3">
          {activeAlerts.map((al) => (
            <div
              key={al.ID}
              role="alert"
              className="p-4 sm:p-5 rounded-xl bg-red-50 border border-red-300 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-900 text-sm">
                    Peringatan Tong Penuh: {al.Station_ID} · {al.Kompartemen} ({al.Isi_Persen}%)
                  </h3>
                  <p className="text-xs text-red-800 mt-0.5">
                    {al.Pesan} · Notifikasi dikirim {formatTimeAgo(al.Waktu)} ke{' '}
                    {al.Penerima.join(', ')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={busyId === `${al.Station_ID}-${al.Kompartemen}`}
                onClick={() =>
                  handleEmptyCompartment(
                    al.Station_ID,
                    al.Kompartemen as 'Organik' | 'Anorganik' | 'Residu'
                  )
                }
                className="min-h-[44px] px-4 py-2 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-semibold shrink-0 flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Sudah Dikosongkan</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* US-13: Station Compartment Fill Overview for Route Planning */}
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-slate-900 text-base">
            Kapasitas Kompartemen Semua Station (Real-Time)
          </h3>
          <span className="text-xs text-slate-500">Batas penuh otomatis: &gt; 80%</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {stations.map((st) => (
            <div key={st.Station_ID} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="font-semibold text-sm text-slate-900">{st.Station_ID}</div>
                  <div className="text-xs text-slate-500">{st.Lokasi}</div>
                </div>
                <span className="text-xs text-slate-500">
                  Sinkron {formatTimeAgo(st.Last_Heartbeat)}
                </span>
              </div>
              <div className="space-y-2.5">
                {st.Kompartemen.map((c) => {
                  const isFull = c.isi_persen > 80;
                  return (
                    <div key={c.jenis}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium text-slate-800">
                          {c.label} ({c.jenis})
                        </span>
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono tabular-nums font-semibold ${
                              isFull ? 'text-red-700' : 'text-slate-700'
                            }`}
                          >
                            {c.sensor_error ? 'Sensor Error' : `${c.isi_persen}%`}
                          </span>
                          {isFull && (
                            <button
                              type="button"
                              onClick={() => handleEmptyCompartment(st.Station_ID, c.jenis)}
                              className="text-[11px] font-semibold text-red-700 hover:underline cursor-pointer"
                            >
                              Kosongkan
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            isFull
                              ? 'bg-red-600'
                              : c.jenis === 'Organik'
                              ? 'bg-emerald-600'
                              : c.jenis === 'Anorganik'
                              ? 'bg-amber-500'
                              : 'bg-slate-500'
                          }`}
                          style={{ width: `${Math.max(0, Math.min(100, c.isi_persen))}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Verification Queue */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
            {(['Menunggu', 'Terverifikasi', 'Ditolak'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  tab === t
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t} {t === 'Menunggu' ? `(${pendingCount})` : ''}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama atau kelas..."
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>
        </div>

        {/* FR-VF-09 Note */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200 text-xs text-slate-600 flex items-center gap-2">
          <Cpu className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
          <span>
            Setoran dari Smart Waste Station (IoT) otomatis berstatus Terverifikasi dan tidak masuk antrean Menunggu.
          </span>
        </div>

        {filteredSetoran.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            Tidak ada setoran pada tab {tab}.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredSetoran.slice(0, 25).map((item) => {
              const isEditing = editingId === item.ID;
              return (
                <div key={item.ID} className="p-4 sm:p-5 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-900">
                        <span>{item.Nama_Penyetor}</span>
                        <span className="text-slate-400">·</span>
                        <span>{item.Kelas}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-emerald-800">
                          {getJenisLabel(item.Jenis, jenisSampah)}
                          {item.Subjenis ? ` (${item.Subjenis})` : ''}
                        </span>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono tabular-nums font-semibold text-slate-800">
                          {item.Jumlah_item
                            ? `${item.Jumlah_item} item`
                            : `${item.Berat_kg.toFixed(2)} kg`}
                        </span>
                        <span>·</span>
                        <span>{item.Sumber}</span>
                        <span>·</span>
                        <span>{formatJakartaDateTime(item.Tanggal)}</span>
                        {item.Jenis !== item.Jenis_Awal && (
                          <>
                            <span>·</span>
                            <span className="text-amber-700">
                              Dikoreksi dari {getJenisLabel(item.Jenis_Awal, jenisSampah)}
                            </span>
                          </>
                        )}
                      </div>
                      {item.Alasan_Tolak && (
                        <p className="mt-1 text-xs text-red-700">
                          Alasan ditolak: {item.Alasan_Tolak}
                        </p>
                      )}
                    </div>

                    {item.Foto && (
                      <img
                        src={item.Foto}
                        alt="Foto setoran"
                        className="w-16 h-16 rounded-lg object-cover border border-slate-200 shrink-0"
                      />
                    )}

                    {tab === 'Menunggu' && !isEditing && (
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEdit(item)}
                          className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Ubah / Koreksi</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setRejectTarget(item)}
                          className="min-h-[40px] px-3 py-1.5 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-xs font-semibold text-red-700 flex items-center gap-1.5 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Tolak</span>
                        </button>
                        <button
                          type="button"
                          disabled={busyId === item.ID}
                          onClick={() => handleVerify(item, false)}
                          className="min-h-[40px] px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Verifikasi</span>
                        </button>
                      </div>
                    )}

                    {tab !== 'Menunggu' && (
                      <div className="text-xs font-mono tabular-nums font-semibold text-slate-700 shrink-0">
                        {item.Status === 'Terverifikasi' ? `+${item.Poin} poin` : '0 poin'}
                      </div>
                    )}
                  </div>

                  {/* Inline Edit Form (Ubah Berat & Koreksi Jenis, keeping Jenis_Awal) */}
                  {isEditing && (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-end gap-3">
                      <div className="flex-1">
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Koreksi Jenis (Jenis_Awal tetap: {item.Jenis_Awal})
                        </label>
                        <select
                          value={editJenis}
                          onChange={(e) => setEditJenis(e.target.value as JenisKey)}
                          className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 bg-white text-xs"
                        >
                          {jenisSampah.map((j) => (
                            <option key={j.Jenis} value={j.Jenis}>
                              {j.Label_Aplikasi} ({j.Jenis})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="w-full sm:w-36">
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Berat Final (kg)
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          min="0.1"
                          max="20"
                          value={editWeight}
                          onChange={(e) => setEditWeight(Number(e.target.value))}
                          className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 bg-white font-mono tabular-nums text-xs"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 cursor-pointer"
                        >
                          Batal
                        </button>
                        <button
                          type="button"
                          disabled={busyId === item.ID}
                          onClick={() => handleVerify(item, true)}
                          className="min-h-[40px] px-4 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800 cursor-pointer"
                        >
                          Simpan & Verifikasi
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Reject Modal with mandatory reason (FR-VF-05) */}
      {rejectTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleReject}
            className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 space-y-4"
          >
            <div className="flex items-center gap-2 text-red-700 font-semibold">
              <Trash2 className="w-5 h-5" />
              <h3>Tolak Setoran {rejectTarget.ID}</h3>
            </div>
            <p className="text-xs text-slate-600">
              Setoran milik <strong>{rejectTarget.Nama_Penyetor}</strong> ({rejectTarget.Kelas}) tidak akan dihitung ke poin kelas. Alasan penolakan wajib diisi.
            </p>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Alasan Penolakan *
              </label>
              <textarea
                required
                rows={3}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Mis. Sampah masih tercampur sisa kuah atau berat fisik tidak sesuai."
                className="w-full p-3 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setRejectTarget(null);
                  setRejectReason('');
                }}
                className="min-h-[40px] px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-semibold cursor-pointer"
              >
                Konfirmasi Tolak
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
