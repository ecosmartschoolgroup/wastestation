import React, { useState } from 'react';
import {
  Users,
  CreditCard,
  Sliders,
  Cpu,
  Bell,
  FileClock,
  RefreshCw,
  Upload,
  Search,
  LayoutGrid,
  List,
} from 'lucide-react';
import type { AppDatabase, Jenjang, JenisSampah, Pengguna, Peran } from '../types.ts';
import { formatJakartaDateTime, formatTimeAgo } from '../utils/wasteStyles.ts';
import { StudentRfidCard } from './StudentRfidCard.tsx';

interface AdminViewProps {
  db: AppDatabase;
  onRefresh: () => void;
  selectedJenjang?: Jenjang | 'ALL';
}

export const AdminView: React.FC<AdminViewProps> = ({ db, onRefresh, selectedJenjang }) => {
  const [tab, setTab] = useState<'pengguna' | 'rfid' | 'jenis' | 'station' | 'log'>('pengguna');
  const [feedback, setFeedback] = useState('');

  // New user form
  const [newNama, setNewNama] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPeran, setNewPeran] = useState<Peran>('Siswa');
  const [newJenjang, setNewJenjang] = useState<Jenjang>(
    selectedJenjang && selectedJenjang !== 'ALL' ? selectedJenjang : 'SMA/SMK'
  );
  const [newKelas, setNewKelas] = useState('XI RPL 1');
  const [newConsent, setNewConsent] = useState(true);

  // RFID form & directory filters
  const [rfidTargetType, setRfidTargetType] = useState<'Siswa' | 'Kelas'>('Siswa');
  const [rfidTargetId, setRfidTargetId] = useState(db.Pengguna[0]?.ID_Pengguna || '');
  const [rfidUid, setRfidUid] = useState('');
  const [rfidSearch, setRfidSearch] = useState('');
  const [rfidJenjang, setRfidJenjang] = useState<Jenjang | 'ALL'>(selectedJenjang || 'ALL');
  const [rfidStatus, setRfidStatus] = useState<'ALL' | 'TERDAFTAR' | 'BELUM'>('ALL');
  const [rfidViewMode, setRfidViewMode] = useState<'cards' | 'table'>('cards');

  // Jenis edit
  const [editingJenis, setEditingJenis] = useState<JenisSampah | null>(null);
  const [editLabel, setEditLabel] = useState('');
  const [editPoin, setEditPoin] = useState(5);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback('');
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        Nama: newNama,
        Email: newEmail || undefined,
        Peran: newPeran,
        Jenjang: newJenjang,
        Kelas: newKelas,
        Tingkat: newJenjang === 'TK' ? 'TK-B' : '11',
        Persetujuan_Ortu: newConsent ? new Date().toISOString().slice(0, 10) : '',
      }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      setFeedback(`Gagal: ${data.pesan}`);
      return;
    }
    setNewNama('');
    setNewEmail('');
    setFeedback(`Pengguna ${data.user.Nama} (${data.user.ID_Pengguna}) berhasil ditambahkan.`);
    onRefresh();
  };

  const handleImportSampleCSV = async () => {
    const sampleRows = [
      {
        ID_Pengguna: `IMP-${Date.now().toString().slice(-4)}A`,
        Email: `siswa.baru.${Date.now().toString().slice(-4)}@ypikpamjaya.sch.id`,
        Nama: 'Siswa Impor CSV',
        Peran: 'Siswa',
        Kelas: 'XI RPL 1',
        Jenjang: 'SMA/SMK',
      },
      {
        Email: db.Pengguna[0]?.Email, // Intentional duplicate to demonstrate AC-AD-01 validation
        Nama: 'Duplikat Uji',
        Peran: 'Siswa',
        Kelas: 'XI RPL 1',
        Jenjang: 'SMA/SMK',
      },
    ];
    const res = await fetch('/api/admin/users/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: sampleRows }),
    });
    const data = await res.json();
    setFeedback(
      `Impor selesai: ${data.inserted} masuk, ${data.rejected.length} ditolak (${data.rejected.join('; ')}).`
    );
    onRefresh();
  };

  const handleRegisterRfid = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback('');
    const res = await fetch('/api/admin/rfid', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetType: rfidTargetType,
        targetId: rfidTargetId,
        uid: rfidUid,
      }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      setFeedback(`Ditolak: ${data.pesan}`);
      return;
    }
    setRfidUid('');
    setFeedback(`UID ${data.uid} berhasil didaftarkan ke ${rfidTargetType} ${rfidTargetId}.`);
    onRefresh();
  };

  const handleSaveJenis = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingJenis) return;
    await fetch(`/api/admin/jenis/${editingJenis.Jenis}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        Label_Aplikasi: editLabel,
        Poin_per_satuan: editPoin,
      }),
    });
    setEditingJenis(null);
    setFeedback(`Tarif dan label ${editingJenis.Jenis} diperbarui.`);
    onRefresh();
  };

  const handleRotateToken = async (stationId: string) => {
    const res = await fetch('/api/admin/stations/rotate-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stationId }),
    });
    const data = await res.json();
    if (data.ok) {
      setFeedback(`Token station ${stationId} berhasil dirotasi.`);
      onRefresh();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-bold text-slate-900">
          Administrasi Sekolah &amp; Kesehatan Station
        </h2>
        <p className="text-sm text-slate-600">
          Kelola pengguna lintas jenjang (dengan atau tanpa email), kartu RFID unik, tarif poin, dan keamanan station IoT.
        </p>
      </div>

      {/* Sub-navigation */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-xl self-start w-fit">
        {(
          [
            { id: 'pengguna', label: 'Pengguna & CSV', icon: Users },
            { id: 'rfid', label: 'Kartu RFID', icon: CreditCard },
            { id: 'jenis', label: 'Jenis & Poin', icon: Sliders },
            { id: 'station', label: 'Station & Token', icon: Cpu },
            { id: 'log', label: 'Notifikasi & Audit', icon: FileClock },
          ] as const
        ).map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                tab === item.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-900">
          {feedback}
        </div>
      )}

      {tab === 'pengguna' && (
        <div className="space-y-6">
          <form
            onSubmit={handleCreateUser}
            className="bg-white border border-slate-200 rounded-xl p-5 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display font-semibold text-slate-900">
                Tambah Pengguna Baru (Email Opsional untuk TK/SD)
              </h3>
              <button
                type="button"
                onClick={handleImportSampleCSV}
                className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Uji Impor CSV Massal</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <input
                type="text"
                required
                placeholder="Nama Lengkap"
                value={newNama}
                onChange={(e) => setNewNama(e.target.value)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
              />
              <input
                type="email"
                placeholder="Email (opsional untuk TK/SD)"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
              />
              <select
                value={newPeran}
                onChange={(e) => setNewPeran(e.target.value as Peran)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
              >
                <option value="Siswa">Siswa</option>
                <option value="Petugas">Eco Ranger (Petugas)</option>
                <option value="Guru">Guru</option>
                <option value="Admin">Admin</option>
              </select>
              <select
                value={newJenjang}
                onChange={(e) => setNewJenjang(e.target.value as Jenjang)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
              >
                <option value="TK">TK</option>
                <option value="SD">SD</option>
                <option value="SMP">SMP</option>
                <option value="SMA/SMK">SMA/SMK</option>
              </select>
              <select
                value={newKelas}
                onChange={(e) => setNewKelas(e.target.value)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
              >
                <option value="">(Kosong / Guru)</option>
                {db.Kelas.map((c) => (
                  <option key={c.Kelas} value={c.Kelas}>
                    {c.Kelas} ({c.Jenjang})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newConsent}
                  onChange={(e) => setNewConsent(e.target.checked)}
                  className="w-4 h-4 accent-emerald-700"
                />
                <span>Persetujuan Orang Tua (UU PDP) sudah tercatat</span>
              </label>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
              >
                Simpan Pengguna
              </button>
            </div>
          </form>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-3 px-4">ID_Pengguna</th>
                    <th className="py-3 px-4">Nama</th>
                    <th className="py-3 px-4">Peran</th>
                    <th className="py-3 px-4">Jenjang / Kelas</th>
                    <th className="py-3 px-4">Kartu RFID</th>
                    <th className="py-3 px-4">Persetujuan Ortu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {db.Pengguna.map((u) => (
                    <tr key={u.ID_Pengguna} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono text-slate-700">{u.ID_Pengguna}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{u.Nama}</div>
                        <div className="text-slate-500">{u.Email || 'Tanpa email'}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {u.Peran === 'Petugas' ? 'Eco Ranger (Petugas)' : u.Peran}
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {u.Jenjang} {u.Kelas ? `· ${u.Kelas}` : ''}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {u.Kartu_RFID || '-'}
                      </td>
                      <td className="py-3 px-4">
                        {u.Persetujuan_Ortu ? (
                          <span className="text-emerald-700 font-medium">{u.Persetujuan_Ortu}</span>
                        ) : (
                          <span className="text-amber-700 font-medium">Belum aktif</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'rfid' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <form
              onSubmit={handleRegisterRfid}
              className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4"
            >
              <h3 className="font-display font-semibold text-slate-900">
                Daftarkan atau Ubah Kartu RFID (Cegah UID Ganda)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tipe Pemilik Kartu
                  </label>
                  <select
                    value={rfidTargetType}
                    onChange={(e) => {
                      const val = e.target.value as 'Siswa' | 'Kelas';
                      setRfidTargetType(val);
                      setRfidTargetId(
                        val === 'Siswa'
                          ? db.Pengguna[0]?.ID_Pengguna || ''
                          : db.Kelas.find((k) => k.Jenjang === 'TK' || k.Jenjang === 'SD')?.Kelas || ''
                      );
                    }}
                    className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
                  >
                    <option value="Siswa">Kartu Pribadi Siswa / Pengguna</option>
                    <option value="Kelas">Kartu Kelas (TK / SD 1–3)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Pilih {rfidTargetType}
                  </label>
                  <select
                    value={rfidTargetId}
                    onChange={(e) => setRfidTargetId(e.target.value)}
                    className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-xs"
                  >
                    {rfidTargetType === 'Siswa'
                      ? db.Pengguna.map((u) => (
                          <option key={u.ID_Pengguna} value={u.ID_Pengguna}>
                            {u.Nama} ({u.Kelas || u.Peran})
                          </option>
                        ))
                      : db.Kelas.map((c) => (
                          <option key={c.Kelas} value={c.Kelas}>
                            {c.Kelas} ({c.Jenjang})
                          </option>
                        ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  UID Heksadesimal (dari pembaca RC522, huruf besar)
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: 04F1A2B3"
                  value={rfidUid}
                  onChange={(e) => setRfidUid(e.target.value.toUpperCase())}
                  className="w-full min-h-[42px] px-3 rounded-lg border border-slate-300 font-mono text-xs uppercase"
                />
              </div>

              <button
                type="submit"
                className="min-h-[42px] px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
              >
                Simpan Kartu RFID
              </button>
            </form>

            {/* Kartu Kelas (TK & SD 1-3) Summary */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-3">
              <h3 className="font-display font-semibold text-slate-900">
                Kartu Kelas Kolektif (TK &amp; SD 1–3)
              </h3>
              <p className="text-xs text-slate-600">
                Satu kartu RFID dipegang guru/piket untuk mencatat setoran kolektif kelas.
              </p>
              <div className="divide-y divide-slate-100 text-xs">
                {db.Kelas.filter((c) => Boolean(c.Kartu_Kelas) || c.Jenjang === 'TK' || Number(c.Tingkat) <= 3).map((cls) => (
                  <div key={cls.Kelas} className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-semibold text-slate-900">{cls.Kelas}</span>
                      <span className="text-slate-500 ml-1.5">· {cls.Wali_Kelas}</span>
                    </div>
                    <span className="font-mono font-semibold text-emerald-700">
                      {cls.Kartu_Kelas || 'Belum ada'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Kartu RFID Per Siswa Section */}
          <section className="space-y-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div>
                <h3 className="font-display font-bold text-slate-900 text-base">
                  Kartu RFID Per Siswa ({db.Pengguna.filter((u) => u.Peran === 'Siswa').length} Siswa)
                </h3>
                <p className="text-xs text-slate-500">
                  Klik &ldquo;Daftarkan UID / Ubah UID&rdquo; pada kartu siswa untuk langsung mengisi formulir di atas.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={rfidSearch}
                    onChange={(e) => setRfidSearch(e.target.value)}
                    placeholder="Cari nama, kelas, UID..."
                    className="min-h-[38px] pl-8 pr-3 rounded-lg border border-slate-300 text-xs w-48"
                  />
                </div>
                <select
                  aria-label="Filter Jenjang Kartu RFID"
                  value={rfidJenjang}
                  onChange={(e) => setRfidJenjang(e.target.value as Jenjang | 'ALL')}
                  className="min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                >
                  <option value="ALL">Semua Jenjang</option>
                  <option value="TK">TK</option>
                  <option value="SD">SD</option>
                  <option value="SMP">SMP</option>
                  <option value="SMA/SMK">SMA/SMK</option>
                </select>
                <select
                  aria-label="Filter Status Kartu RFID"
                  value={rfidStatus}
                  onChange={(e) => setRfidStatus(e.target.value as 'ALL' | 'TERDAFTAR' | 'BELUM')}
                  className="min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                >
                  <option value="ALL">Semua Status</option>
                  <option value="TERDAFTAR">Sudah Terdaftar</option>
                  <option value="BELUM">Belum Terdaftar</option>
                </select>
                <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
                  <button
                    type="button"
                    aria-label="Tampilan kartu"
                    onClick={() => setRfidViewMode('cards')}
                    className={`min-h-[34px] px-2.5 rounded-md flex items-center gap-1 text-xs font-medium cursor-pointer ${
                      rfidViewMode === 'cards' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                    }`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>Kartu</span>
                  </button>
                  <button
                    type="button"
                    aria-label="Tampilan tabel"
                    onClick={() => setRfidViewMode('table')}
                    className={`min-h-[34px] px-2.5 rounded-md flex items-center gap-1 text-xs font-medium cursor-pointer ${
                      rfidViewMode === 'table' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                    }`}
                  >
                    <List className="w-3.5 h-3.5" />
                    <span>Tabel</span>
                  </button>
                </div>
              </div>
            </div>

            {(() => {
              const filteredStudents = db.Pengguna.filter((u) => {
                if (u.Peran !== 'Siswa') return false;
                if (rfidJenjang !== 'ALL' && u.Jenjang !== rfidJenjang) return false;
                const clsObj = db.Kelas.find((c) => c.Kelas === u.Kelas);
                const hasAnyUid = Boolean(u.Kartu_RFID || clsObj?.Kartu_Kelas);
                if (rfidStatus === 'TERDAFTAR' && !hasAnyUid) return false;
                if (rfidStatus === 'BELUM' && hasAnyUid) return false;
                if (!rfidSearch.trim()) return true;
                const q = rfidSearch.toLowerCase();
                return (
                  u.Nama.toLowerCase().includes(q) ||
                  u.ID_Pengguna.toLowerCase().includes(q) ||
                  u.Kelas.toLowerCase().includes(q) ||
                  (u.Kartu_RFID || '').toLowerCase().includes(q)
                );
              });

              const handleAssignStudent = (stu: Pengguna) => {
                setRfidTargetType('Siswa');
                setRfidTargetId(stu.ID_Pengguna);
                setRfidUid(stu.Kartu_RFID || '');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              };

              if (filteredStudents.length === 0) {
                return (
                  <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
                    Tidak ada siswa yang sesuai dengan filter pencarian.
                  </div>
                );
              }

              if (rfidViewMode === 'table') {
                return (
                  <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                            <th className="py-3 px-4">ID Siswa</th>
                            <th className="py-3 px-4">Nama Siswa</th>
                            <th className="py-3 px-4">Jenjang / Kelas</th>
                            <th className="py-3 px-4">UID Kartu RFID</th>
                            <th className="py-3 px-4">Persetujuan Ortu</th>
                            <th className="py-3 px-4 text-right">Aksi</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {filteredStudents.map((stu) => {
                            const clsCard = db.Kelas.find((c) => c.Kelas === stu.Kelas)?.Kartu_Kelas;
                            return (
                              <tr key={stu.ID_Pengguna} className="hover:bg-slate-50">
                                <td className="py-3 px-4 font-mono text-slate-600">{stu.ID_Pengguna}</td>
                                <td className="py-3 px-4 font-semibold text-slate-900">{stu.Nama}</td>
                                <td className="py-3 px-4 text-slate-700">{stu.Jenjang} · {stu.Kelas}</td>
                                <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                                  {stu.Kartu_RFID || (clsCard ? `${clsCard} (Kartu Kelas)` : 'Belum Terdaftar')}
                                </td>
                                <td className="py-3 px-4">
                                  {stu.Persetujuan_Ortu ? (
                                    <span className="text-emerald-700 font-medium">{stu.Persetujuan_Ortu}</span>
                                  ) : (
                                    <span className="text-red-700 font-medium">Belum Aktif</span>
                                  )}
                                </td>
                                <td className="py-3 px-4 text-right">
                                  <button
                                    type="button"
                                    onClick={() => handleAssignStudent(stu)}
                                    className="text-emerald-700 font-semibold hover:underline cursor-pointer"
                                  >
                                    {stu.Kartu_RFID ? 'Ubah UID' : 'Daftarkan UID'}
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredStudents.map((stu) => (
                    <StudentRfidCard
                      key={stu.ID_Pengguna}
                      student={stu}
                      classCardUid={db.Kelas.find((c) => c.Kelas === stu.Kelas)?.Kartu_Kelas}
                      onAssignClick={handleAssignStudent}
                    />
                  ))}
                </div>
              );
            })()}
          </section>
        </div>
      )}

      {tab === 'jenis' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Key Data</th>
                  <th className="py-3 px-4">Label Aplikasi</th>
                  <th className="py-3 px-4">Warna Tong</th>
                  <th className="py-3 px-4">Tarif Poin</th>
                  <th className="py-3 px-4">Jalur Input</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {db.JenisSampah.map((j) => (
                  <tr key={j.Jenis}>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-800">{j.Jenis}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{j.Label_Aplikasi}</td>
                    <td className="py-3 px-4 text-slate-700">{j.Warna_Tong}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-emerald-700 font-bold">
                      {j.Poin_per_satuan} / {j.Satuan}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{j.Jalur_Input}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingJenis(j);
                          setEditLabel(j.Label_Aplikasi);
                          setEditPoin(j.Poin_per_satuan);
                        }}
                        className="text-emerald-700 font-semibold hover:underline cursor-pointer"
                      >
                        Ubah Tarif / Label
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {editingJenis && (
            <form
              onSubmit={handleSaveJenis}
              className="p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-end gap-4"
            >
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Label Aplikasi ({editingJenis.Jenis})
                </label>
                <input
                  type="text"
                  value={editLabel}
                  onChange={(e) => setEditLabel(e.target.value)}
                  className="min-h-[40px] px-3 rounded-lg border border-slate-300 bg-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Poin per {editingJenis.Satuan}
                </label>
                <input
                  type="number"
                  min="0"
                  value={editPoin}
                  onChange={(e) => setEditPoin(Number(e.target.value))}
                  className="min-h-[40px] px-3 rounded-lg border border-slate-300 bg-white font-mono text-xs w-28"
                />
              </div>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
              >
                Simpan Perubahan
              </button>
              <button
                type="button"
                onClick={() => setEditingJenis(null)}
                className="min-h-[40px] px-3 py-2 text-xs text-slate-600 cursor-pointer"
              >
                Batal
              </button>
            </form>
          )}
        </div>
      )}

      {tab === 'station' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {db.Stations.map((st) => {
            const offline =
              Date.now() - new Date(st.Last_Heartbeat).getTime() > 15 * 60_000;
            return (
              <div
                key={st.Station_ID}
                className="bg-white border border-slate-200 rounded-xl p-5 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-display font-bold text-slate-900">{st.Station_ID}</h4>
                    <p className="text-xs text-slate-500">
                      {st.Lokasi} · Mode {st.MODE_JENJANG}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      offline ? 'text-red-700' : 'text-emerald-700'
                    }`}
                  >
                    {offline ? 'Offline (>15 mnt)' : 'Online'} · {formatTimeAgo(st.Last_Heartbeat)}
                  </span>
                </div>

                <div className="text-xs text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
                  <span>
                    Token: <code className="font-mono text-slate-800">{st.Token}</code>
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRotateToken(st.Station_ID)}
                    className="min-h-[34px] px-3 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Rotasi Token</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'log' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <h3 className="font-display font-semibold text-slate-900 flex items-center gap-2">
              <Bell className="w-4 h-4 text-red-700" />
              <span>Log Notifikasi Tong Penuh (G-05)</span>
            </h3>
            <div className="divide-y divide-slate-100 text-xs">
              {db.Notifikasi_Log.map((n) => (
                <div key={n.ID} className="py-3 space-y-1">
                  <div className="flex items-center justify-between font-semibold text-slate-900">
                    <span>
                      {n.Station_ID} · {n.Kompartemen} ({n.Isi_Persen}%)
                    </span>
                    <span className={n.Status === 'Aktif' ? 'text-red-700' : 'text-emerald-700'}>
                      {n.Status}
                    </span>
                  </div>
                  <p className="text-slate-600">{n.Pesan}</p>
                  <p className="text-slate-400">
                    {formatJakartaDateTime(n.Waktu)}
                    {n.Durasi_Respon_Menit
                      ? ` · Dikosongkan dalam ${n.Durasi_Respon_Menit} menit`
                      : ''}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <h3 className="font-display font-semibold text-slate-900 flex items-center gap-2">
              <FileClock className="w-4 h-4 text-slate-700" />
              <span>Log Audit Perubahan Data (FR-AD-06)</span>
            </h3>
            <div className="divide-y divide-slate-100 text-xs">
              {db.Audit_Log.slice(0, 12).map((a) => (
                <div key={a.ID} className="py-3 space-y-0.5">
                  <div className="flex items-center justify-between font-semibold text-slate-900">
                    <span>{a.Aksi}</span>
                    <span className="text-slate-500 font-normal">{a.Aktor}</span>
                  </div>
                  <p className="text-slate-600">{a.Detail}</p>
                  <p className="text-slate-400">{formatJakartaDateTime(a.Waktu)}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
