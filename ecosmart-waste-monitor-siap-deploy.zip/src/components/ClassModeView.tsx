import React, { useState } from 'react';
import {
  Volume2,
  Leaf,
  Recycle,
  Trash2,
  Lock,
  CheckCircle2,
  ArrowLeft,
  Star,
  ClipboardCheck,
} from 'lucide-react';
import type {
  JenisKey,
  Kelas,
  ObservasiTK,
  Pengguna,
  Setoran,
} from '../types.ts';
import { speakIndonesian } from '../utils/audio.ts';

interface ClassModeViewProps {
  kelas: Kelas;
  users: Pengguna[];
  setoran: Setoran[];
  observasiTK: ObservasiTK[];
  onRefresh: () => void;
  onExit: () => void;
}

const PIN_ICONS = [
  { id: 'daun', label: 'Daun', symbol: '🌿' },
  { id: 'air', label: 'Air', symbol: '💧' },
  { id: 'matahari', label: 'Matahari', symbol: '☀️' },
  { id: 'bintang', label: 'Bintang', symbol: '⭐' },
  { id: 'apel', label: 'Apel', symbol: '🍎' },
];

const AVATAR_EMOJI: Record<string, string> = {
  kupu: '🦋',
  singa: '🦁',
  gajah: '🐘',
  kelinci: '🐰',
  kura: '🐢',
  rubah: '🦊',
};

export const ClassModeView: React.FC<ClassModeViewProps> = ({
  kelas,
  users,
  setoran,
  observasiTK,
  onRefresh,
  onExit,
}) => {
  const isTK = kelas.Jenjang === 'TK';
  const students = users.filter((u) => u.Kelas === kelas.Kelas && u.Peran === 'Siswa');
  const classVerified = setoran.filter(
    (s) => s.Kelas === kelas.Kelas && s.Status === 'Terverifikasi'
  );
  const classPoinInternal = classVerified.reduce((a, b) => a + b.Poin, 0);
  const treeStage = Math.min(5, Math.max(1, Math.floor(classPoinInternal / 10) + 1));

  // SD 1-3 PIN Gambar Auth state
  const [selectedStudent, setSelectedStudent] = useState<Pengguna | null>(null);
  const [pinAttempt, setPinAttempt] = useState<string[]>([]);
  const [wrongCount, setWrongCount] = useState(0);
  const [locked, setLocked] = useState(false);
  const [unlockedStudent, setUnlockedStudent] = useState<Pengguna | null>(null);

  // TK Teacher Observation state (FR-JJ-11)
  const [obsStudentId, setObsStudentId] = useState<string>(students[0]?.ID_Pengguna || '');
  const [mandiri, setMandiri] = useState(true);
  const [kenalWarna, setKenalWarna] = useState(true);
  const [bantuTeman, setBantuTeman] = useState(false);
  const [obsNote, setObsNote] = useState('');
  const [obsSavedMsg, setObsSavedMsg] = useState('');

  // Quick visual deposit feedback
  const [pickedBinMsg, setPickedBinMsg] = useState('');

  const handlePinPick = (iconId: string) => {
    if (locked || !selectedStudent) return;
    const next = [...pinAttempt, iconId];
    setPinAttempt(next);

    if (next.length === 4) {
      const target = selectedStudent.PIN_Gambar || ['daun', 'daun', 'daun', 'daun'];
      const match = target.every((val, idx) => val === next[idx]);
      if (match) {
        setUnlockedStudent(selectedStudent);
        setPinAttempt([]);
        setWrongCount(0);
        speakIndonesian(`Halo ${selectedStudent.Nama}! Ayo belajar memilah sampah.`);
      } else {
        const nextWrong = wrongCount + 1;
        setWrongCount(nextWrong);
        setPinAttempt([]);
        if (nextWrong >= 3) {
          setLocked(true);
          speakIndonesian('Akses dikunci. Silakan minta bantuan Ibu atau Bapak Guru.');
        }
      }
    }
  };

  const handleTKPracticeBin = (jenis: JenisKey) => {
    const msg =
      jenis === 'Organik'
        ? 'Tong Hijau untuk daun, kulit buah, dan sisa makanan!'
        : jenis === 'Anorganik'
        ? 'Tong Kuning untuk botol plastik, kertas, dan kardus!'
        : 'Tong Abu-abu untuk tisu kotor dan bungkus permen!';
    setPickedBinMsg(msg);
    speakIndonesian(msg);
  };

  const handleSaveObservation = async (e: React.FormEvent) => {
    e.preventDefault();
    const stu = students.find((s) => s.ID_Pengguna === obsStudentId);
    if (!stu) return;
    await fetch('/api/observasi-tk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        idPengguna: stu.ID_Pengguna,
        namaSiswa: stu.Nama,
        kelas: kelas.Kelas,
        mandiriMemilah: mandiri,
        kenalWarnaTong: kenalWarna,
        bantuTeman,
        catatan: obsNote,
        guru: kelas.Wali_Kelas,
      }),
    });
    setObsNote('');
    setObsSavedMsg(`Observasi untuk ${stu.Nama} tersimpan.`);
    onRefresh();
  };

  return (
    <div className="min-h-screen bg-emerald-50/40 pb-12">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onExit}
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Keluar Mode Kelas</span>
          </button>
          <div>
            <h1 className="font-display font-bold text-slate-900 text-base sm:text-lg">
              Mode Kelas {kelas.Kelas} ({kelas.Jenjang})
            </h1>
          </div>
        </div>
        <div className="text-xs text-slate-600 hidden sm:block">
          Kartu Kelas: <span className="font-mono font-semibold">{kelas.Kartu_Kelas || '-'}</span>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {isTK ? (
          /* TK View: NO numeric points, NO ranking, Class Tree growth + Voice + Observation */
          <>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Growing Class Tree (FR-JJ-05, AC-JJ-03) */}
              <section className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 text-center flex flex-col items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Pohon Kelas {kelas.Kelas}
                  </h2>
                  <p className="text-sm text-slate-600 mt-1">
                    Pohon tumbuh hijau saat kita memilah bersama!
                  </p>
                </div>

                {/* Custom SVG Growing Tree */}
                <svg
                  viewBox="0 0 220 200"
                  className="w-52 h-48 my-4"
                  aria-label="Ilustrasi Pohon Kelas yang Tumbuh"
                >
                  <rect x="20" y="175" width="180" height="12" rx="6" fill="#bbf7d0" />
                  <path
                    d="M100 175 L102 105 L118 105 L120 175 Z"
                    fill="#92400e"
                  />
                  <circle cx="110" cy="85" r={28 + treeStage * 6} fill="#16a34a" />
                  {treeStage >= 2 && (
                    <circle cx="78" cy="100" r={22 + treeStage * 3} fill="#22c55e" />
                  )}
                  {treeStage >= 3 && (
                    <circle cx="142" cy="100" r={22 + treeStage * 3} fill="#15803d" />
                  )}
                  {treeStage >= 4 && (
                    <>
                      <circle cx="95" cy="70" r="6" fill="#facc15" />
                      <circle cx="128" cy="84" r="6" fill="#f87171" />
                      <circle cx="80" cy="105" r="5" fill="#fb923c" />
                    </>
                  )}
                </svg>

                <button
                  type="button"
                  onClick={() =>
                    speakIndonesian(
                      `Wah hebat! Pohon kelas ${kelas.Kelas} sudah tumbuh besar karena anak-anak rajin memilah sampah!`
                    )
                  }
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-700 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <Volume2 className="w-5 h-5" />
                  <span>Dengarkan Cerita Pohon</span>
                </button>
              </section>

              {/* Big Visual Bins with Audio (FR-JJ-05) */}
              <section className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
                <h2 className="font-display text-xl font-bold text-slate-900">
                  Pilih Warna Tong Sampah
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Organik')}
                    className="min-h-[140px] p-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex flex-col items-center justify-center gap-3 cursor-pointer transition-transform active:scale-95"
                  >
                    <Leaf className="w-12 h-12" />
                    <span className="font-display font-bold text-lg">HIJAU</span>
                    <span className="text-xs text-emerald-100">Kulit Buah &amp; Daun</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Anorganik')}
                    className="min-h-[140px] p-5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 flex flex-col items-center justify-center gap-3 cursor-pointer transition-transform active:scale-95"
                  >
                    <Recycle className="w-12 h-12" />
                    <span className="font-display font-bold text-lg">KUNING</span>
                    <span className="text-xs text-amber-950">Botol &amp; Kertas</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Residu')}
                    className="min-h-[140px] p-5 rounded-2xl bg-slate-600 hover:bg-slate-700 text-white flex flex-col items-center justify-center gap-3 cursor-pointer transition-transform active:scale-95"
                  >
                    <Trash2 className="w-12 h-12" />
                    <span className="font-display font-bold text-lg">ABU-ABU</span>
                    <span className="text-xs text-slate-200">Tisu Kotor</span>
                  </button>
                </div>

                {pickedBinMsg && (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 font-semibold text-sm flex items-center gap-2">
                    <Volume2 className="w-5 h-5 shrink-0" />
                    <span>{pickedBinMsg}</span>
                  </div>
                )}
              </section>
            </div>

            {/* Guru TK Daily Observation Checklist (FR-JJ-11) */}
            <section className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-emerald-700" />
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Catatan Observasi Harian Guru TK
                </h3>
              </div>

              <form onSubmit={handleSaveObservation} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Pilih Anak
                    </label>
                    <select
                      value={obsStudentId}
                      onChange={(e) => setObsStudentId(e.target.value)}
                      className="w-full min-h-[44px] px-3 rounded-lg border border-slate-300 text-sm"
                    >
                      {students.map((s) => (
                        <option key={s.ID_Pengguna} value={s.ID_Pengguna}>
                          {AVATAR_EMOJI[s.Avatar || 'kupu'] || '🌱'} {s.Nama}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2 text-sm">
                    <label className="flex items-center gap-2.5 min-h-[36px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={mandiri}
                        onChange={(e) => setMandiri(e.target.checked)}
                        className="w-5 h-5 accent-emerald-700"
                      />
                      <span>Membuang di tong yang benar tanpa dibantu</span>
                    </label>
                    <label className="flex items-center gap-2.5 min-h-[36px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={kenalWarna}
                        onChange={(e) => setKenalWarna(e.target.checked)}
                        className="w-5 h-5 accent-emerald-700"
                      />
                      <span>Mengenal warna Hijau, Kuning, dan Abu-abu</span>
                    </label>
                    <label className="flex items-center gap-2.5 min-h-[36px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={bantuTeman}
                        onChange={(e) => setBantuTeman(e.target.checked)}
                        className="w-5 h-5 accent-emerald-700"
                      />
                      <span>Mengingatkan atau membantu teman memilah</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 flex flex-col justify-between">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Catatan Guru
                    </label>
                    <textarea
                      rows={3}
                      value={obsNote}
                      onChange={(e) => setObsNote(e.target.value)}
                      placeholder="Mis. Sudah mandiri saat jam makan bekal..."
                      className="w-full p-3 rounded-lg border border-slate-300 text-sm"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    {obsSavedMsg ? (
                      <span className="text-xs font-semibold text-emerald-700">{obsSavedMsg}</span>
                    ) : (
                      <span />
                    )}
                    <button
                      type="submit"
                      className="min-h-[44px] px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
                    >
                      Simpan Observasi
                    </button>
                  </div>
                </div>
              </form>

              <div className="pt-4 border-t border-slate-200 divide-y divide-slate-100">
                {observasiTK
                  .filter((o) => o.Kelas === kelas.Kelas)
                  .slice(0, 5)
                  .map((o) => (
                    <div key={o.ID} className="py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div>
                        <strong className="text-slate-900">{o.Nama_Siswa}</strong>
                        <span className="text-slate-500 ml-2">{o.Catatan}</span>
                      </div>
                      <span className="text-emerald-700 font-medium">
                        {o.Mandiri_Memilah ? 'Mandiri ✓' : 'Dibimbing'}
                      </span>
                    </div>
                  ))}
              </div>
            </section>
          </>
        ) : (
          /* SD Kelas 1-3 View: Avatar + Picture PIN (AC-JJ-06) + Stickers */
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
            {!unlockedStudent ? (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Pilih Namamu di Kelas {kelas.Kelas}
                  </h2>
                  <p className="text-sm text-slate-600">
                    Ketuk gambar avatarmu, lalu masukkan 4 gambar PIN rahasiamu.
                  </p>
                </div>

                {!selectedStudent ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {students.map((stu) => (
                      <button
                        key={stu.ID_Pengguna}
                        type="button"
                        onClick={() => {
                          setSelectedStudent(stu);
                          setPinAttempt([]);
                          setWrongCount(0);
                          setLocked(false);
                        }}
                        className="min-h-[110px] p-4 rounded-2xl border border-slate-200 bg-slate-50 hover:border-emerald-500 hover:bg-emerald-50 flex flex-col items-center justify-center gap-2 cursor-pointer"
                      >
                        <span className="text-4xl">
                          {AVATAR_EMOJI[stu.Avatar || 'kelinci'] || '🐰'}
                        </span>
                        <span className="font-display font-bold text-slate-900 text-sm">
                          {stu.Nama}
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="max-w-md mx-auto space-y-5 text-center">
                    <div className="text-4xl">
                      {AVATAR_EMOJI[selectedStudent.Avatar || 'kelinci'] || '🐰'}
                    </div>
                    <h3 className="font-display text-lg font-bold text-slate-900">
                      PIN Gambar untuk {selectedStudent.Nama}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Petunjuk demo PIN:{' '}
                      {(selectedStudent.PIN_Gambar || []).join(' → ')}
                    </p>

                    {locked ? (
                      <div className="p-5 rounded-xl bg-red-50 border border-red-200 space-y-3">
                        <Lock className="w-8 h-8 text-red-700 mx-auto" />
                        <p className="text-sm font-semibold text-red-900">
                          PIN salah 3 kali. Akses dikunci sementara — panggil Ibu/Bapak Guru untuk membuka.
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            setLocked(false);
                            setWrongCount(0);
                            setSelectedStudent(null);
                          }}
                          className="min-h-[40px] px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold cursor-pointer"
                        >
                          Buka Kunci (Guru)
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-center gap-3">
                          {[0, 1, 2, 3].map((slot) => {
                            const picked = pinAttempt[slot];
                            const iconObj = PIN_ICONS.find((i) => i.id === picked);
                            return (
                              <div
                                key={slot}
                                className="w-14 h-14 rounded-xl border-2 border-slate-300 bg-slate-50 flex items-center justify-center text-2xl"
                              >
                                {iconObj ? iconObj.symbol : ''}
                              </div>
                            );
                          })}
                        </div>

                        {wrongCount > 0 && (
                          <p className="text-xs font-semibold text-red-600">
                            PIN belum cocok (percobaan {wrongCount} dari 3).
                          </p>
                        )}

                        <div className="grid grid-cols-5 gap-2">
                          {PIN_ICONS.map((ic) => (
                            <button
                              key={ic.id}
                              type="button"
                              onClick={() => handlePinPick(ic.id)}
                              className="min-h-[60px] rounded-xl border border-slate-200 bg-white hover:bg-emerald-50 flex flex-col items-center justify-center gap-1 cursor-pointer"
                            >
                              <span className="text-2xl">{ic.symbol}</span>
                              <span className="text-[11px] font-medium text-slate-700">
                                {ic.label}
                              </span>
                            </button>
                          ))}
                        </div>

                        <button
                          type="button"
                          onClick={() => setSelectedStudent(null)}
                          className="text-xs text-slate-500 hover:underline cursor-pointer"
                        >
                          Ganti Siswa
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>
            ) : (
              /* SD 1-3 Unlocked View: Stars/Stickers, NO numeric ranking, short <=8 word sentences */
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-slate-900">
                      Halo {unlockedStudent.Nama}!
                    </h2>
                    <p className="text-sm text-slate-600">
                      Ayo pilah sampah kelas bersama teman-teman.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-amber-600 font-semibold text-sm">
                    <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
                    <span>{Math.max(1, classVerified.length)} Bintang Kelas Terkumpul!</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Organik')}
                    className="min-h-[120px] p-5 rounded-2xl bg-emerald-50 border-2 border-emerald-300 text-emerald-900 flex flex-col items-center justify-center gap-2 cursor-pointer"
                  >
                    <Leaf className="w-10 h-10 text-emerald-700" />
                    <span className="font-bold">Tong Hijau (Kompos)</span>
                    <span className="text-xs">Sisa buah dan daun kering</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Anorganik')}
                    className="min-h-[120px] p-5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-900 flex flex-col items-center justify-center gap-2 cursor-pointer"
                  >
                    <Recycle className="w-10 h-10 text-amber-700" />
                    <span className="font-bold">Tong Kuning (Daur Ulang)</span>
                    <span className="text-xs">Botol plastik dan kertas bersih</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTKPracticeBin('Residu')}
                    className="min-h-[120px] p-5 rounded-2xl bg-slate-100 border-2 border-slate-300 text-slate-900 flex flex-col items-center justify-center gap-2 cursor-pointer"
                  >
                    <Trash2 className="w-10 h-10 text-slate-700" />
                    <span className="font-bold">Tong Abu-abu (Residu)</span>
                    <span className="text-xs">Tisu kotor dan bungkus permen</span>
                  </button>
                </div>

                {pickedBinMsg && (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm font-semibold text-emerald-900 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-700" />
                    <span>{pickedBinMsg}</span>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setUnlockedStudent(null);
                    setSelectedStudent(null);
                  }}
                  className="min-h-[40px] px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
                >
                  Selesai &amp; Ganti Siswa
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};
