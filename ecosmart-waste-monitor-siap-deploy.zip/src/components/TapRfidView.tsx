import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  CreditCard,
  Wifi,
  Volume2,
  Leaf,
  Recycle,
  Trash2,
  Clock,
  RotateCcw,
  Sparkles,
  School,
} from 'lucide-react';
import type { Jenjang, Kelas, Pengguna, Setoran, Station } from '../types.ts';
import { playBuzzerPattern, speakIndonesian } from '../utils/audio.ts';
import { formatTimeAgo } from '../utils/wasteStyles.ts';
import { StudentRfidCard } from './StudentRfidCard.tsx';

interface TapRfidViewProps {
  stations: Station[];
  users: Pengguna[];
  classes: Kelas[];
  setoran: Setoran[];
  selectedJenjang: Jenjang | 'ALL';
  onChangeJenjang: (j: Jenjang | 'ALL') => void;
  onRefresh: () => void;
  onBackToLogin?: () => void;
}

type TapStep = 'tap' | 'choose_bin' | 'weigh' | 'done' | 'error';

const JENJANG_OPTIONS: { value: Jenjang | 'ALL'; label: string }[] = [
  { value: 'ALL', label: 'Semua Jenjang' },
  { value: 'TK', label: 'TK' },
  { value: 'SD', label: 'SD' },
  { value: 'SMP', label: 'SMP' },
  { value: 'SMA/SMK', label: 'SMA/SMK' },
];

export const TapRfidView: React.FC<TapRfidViewProps> = ({
  stations,
  users,
  classes,
  setoran,
  selectedJenjang,
  onChangeJenjang,
  onRefresh,
  onBackToLogin,
}) => {
  const [selectedStationId, setSelectedStationId] = useState<string>(
    stations[0]?.Station_ID || 'WS-SMK-01'
  );
  const [uidInput, setUidInput] = useState('');
  const [activeUid, setActiveUid] = useState('');
  const [step, setStep] = useState<TapStep>('tap');
  const [countdown, setCountdown] = useState(10);
  const [selectedBin, setSelectedBin] = useState<'Organik' | 'Anorganik' | 'Residu'>('Anorganik');
  const [weightKg, setWeightKg] = useState(0.45);
  const [fillPct, setFillPct] = useState(65);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [resultInfo, setResultInfo] = useState<{
    title: string;
    detail: string;
    poin?: number;
    kelas?: string;
    alertTriggered?: boolean;
  } | null>(null);

  const inputRef = useRef<HTMLInputElement | null>(null);

  // Auto-select station matching active school level
  useEffect(() => {
    if (selectedJenjang === 'ALL') return;
    const match = stations.find((s) => s.Jenjang_Target === selectedJenjang);
    if (match) {
      setSelectedStationId(match.Station_ID);
    }
  }, [selectedJenjang, stations]);

  const station = stations.find((s) => s.Station_ID === selectedStationId) || stations[0];

  // Sync estimated fill % from selected bin on selected station
  useEffect(() => {
    if (!station) return;
    const comp = station.Kompartemen.find((c) => c.jenis === selectedBin);
    if (comp) {
      setFillPct(Math.min(98, comp.isi_persen + 3));
    }
  }, [station, selectedBin]);

  // 10-second window for compartment choice (PRD Section 6.2)
  useEffect(() => {
    if (step !== 'choose_bin') return;
    if (countdown <= 0) {
      if (station) playBuzzerPattern('timeout', station.MODE_JENJANG);
      setResultInfo({
        title: 'Waktu Pemilihan Habis (10 Detik)',
        detail: 'Silakan tap ulang kartu RFID Anda untuk memulai kembali.',
      });
      setStep('error');
      return;
    }
    const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [step, countdown, station]);

  const resolveCard = (rawUid: string) => {
    const clean = rawUid.trim().toUpperCase().replace(/[^A-F0-9]/g, '');
    const userMatch = users.find((u) => (u.Kartu_RFID || '').toUpperCase() === clean);
    const classMatch = classes.find((c) => (c.Kartu_Kelas || '').toUpperCase() === clean);
    return { clean, userMatch, classMatch };
  };

  const handleTapCard = (uidToTap: string) => {
    if (!station) return;
    const { clean, userMatch, classMatch } = resolveCard(uidToTap);
    if (!clean) {
      inputRef.current?.focus();
      return;
    }

    setActiveUid(clean);
    setUidInput(clean);

    // Play short RC522 card read beep (80ms)
    playBuzzerPattern('card_read', station.MODE_JENJANG);

    if (!userMatch && !classMatch) {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setResultInfo({
        title: `Kartu RFID (${clean}) Belum Terdaftar`,
        detail:
          'Hubungi Admin sekolah untuk mendaftarkan UID kartu ini di menu Administrasi RFID (G-01).',
      });
      setStep('error');
      return;
    }

    if (userMatch && userMatch.Peran === 'Siswa' && !userMatch.Persetujuan_Ortu) {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setResultInfo({
        title: `Kartu ${userMatch.Nama} Belum Aktif`,
        detail:
          'Menunggu persetujuan orang tua/wali sesuai UU PDP (BR-14). Aktifkan di Akun Siswa atau Admin.',
      });
      setStep('error');
      return;
    }

    // If tapped card belongs to another school level and user is on ALL, switch station automatically
    const cardJenjang = classMatch?.Jenjang || userMatch?.Jenjang;
    if (cardJenjang) {
      const targetSt = stations.find((s) => s.Jenjang_Target === cardJenjang);
      if (targetSt && targetSt.Station_ID !== station.Station_ID) {
        setSelectedStationId(targetSt.Station_ID);
      }
    }

    const ownerName = classMatch ? `Kelas ${classMatch.Kelas}` : userMatch!.Nama;
    if (voiceEnabled) {
      speakIndonesian(`Halo ${ownerName}. Silakan pilih tempat sampah.`);
    }

    setResultInfo(null);
    setCountdown(10);
    setStep('choose_bin');
  };

  const handleChooseBin = (bin: 'Organik' | 'Anorganik' | 'Residu') => {
    setSelectedBin(bin);
    setStep('weigh');
    if (voiceEnabled) {
      const label = bin === 'Organik' ? 'Kompos Hijau' : bin === 'Anorganik' ? 'Daur Ulang Kuning' : 'Residu Abu-abu';
      speakIndonesian(`Masukkan sampah ke tong ${label}, lalu tekan kirim.`);
    }
  };

  const handleSubmitDeposit = async () => {
    if (!station || submitting) return;
    setSubmitting(true);

    if (weightKg < 0.02) {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setResultInfo({
        title: 'Berat Sampah di Bawah Batas Minimum (< 20 g)',
        detail:
          station.MODE_JENJANG === 'TK_SD'
            ? 'Ayo masukkan sampah lebih banyak lagi agar bisa ditimbang.'
            : 'Sensor load cell HX711 mensyaratkan berat minimal 0,02 kg (20 gram) (BR-05).',
      });
      setStep('error');
      setSubmitting(false);
      return;
    }

    try {
      const res = await fetch('/api/iot/setoran', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: station.Token,
          station: station.Station_ID,
          kartu: activeUid,
          jenis: selectedBin,
          berat_kg: weightKg,
          isi_persen: fillPct,
        }),
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        playBuzzerPattern('error', station.MODE_JENJANG);
        setResultInfo({
          title: 'Setoran Ditolak Server',
          detail: data.pesan || 'Terjadi kesalahan validasi.',
        });
        setStep('error');
      } else {
        playBuzzerPattern('success', station.MODE_JENJANG);
        const isTkSd = data.jenjang === 'TK' || station.MODE_JENJANG === 'TK_SD';
        if (voiceEnabled) {
          speakIndonesian(
            isTkSd
              ? `Terima kasih teman-teman ${data.kelas}, pohon kelas kita makin subur!`
              : `Terima kasih! Setoran ${data.kelas} tersimpan dan mendapat ${data.poin} poin.`
          );
        }
        setResultInfo({
          title: isTkSd
            ? `Hebat! Pohon Kelas ${data.kelas} Tumbuh Subur`
            : `Setoran Berhasil untuk ${data.kelas} (+${data.poin} Poin)`,
          detail: data.alert
            ? `Peringatan otomatis terkirim: ${data.alert.Pesan}`
            : `Tercatat otomatis di ${station.Station_ID} · Status langsung Terverifikasi.`,
          poin: data.poin,
          kelas: data.kelas,
          alertTriggered: Boolean(data.alert),
        });
        setStep('done');
        onRefresh();
      }
    } catch {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setResultInfo({
        title: 'Koneksi Terputus',
        detail: 'Gagal mengirim data setoran ke server sekolah.',
      });
      setStep('error');
    } finally {
      setSubmitting(false);
    }
  };

  const resetReader = () => {
    setStep('tap');
    setActiveUid('');
    setUidInput('');
    setResultInfo(null);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const { userMatch: previewUser, classMatch: previewClass } = resolveCard(activeUid || uidInput);

  const visibleStudents = users.filter(
    (u) =>
      u.Peran === 'Siswa' &&
      Boolean(u.Kartu_RFID) &&
      (selectedJenjang === 'ALL' || u.Jenjang === selectedJenjang)
  );
  const visibleClassCards = classes.filter(
    (c) =>
      Boolean(c.Kartu_Kelas) &&
      (selectedJenjang === 'ALL' || c.Jenjang === selectedJenjang)
  );
  const recentIot = setoran
    .filter(
      (s) =>
        s.Sumber === 'IoT' &&
        (selectedJenjang === 'ALL' || s.Jenjang === selectedJenjang)
    )
    .slice(0, 6);

  if (!station) return null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {onBackToLogin && (
              <button
                type="button"
                onClick={onBackToLogin}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Login</span>
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <h1 className="font-display font-bold text-slate-900 text-base sm:text-lg leading-tight">
                  Layar Tap Kartu RFID · Smart Waste Station
                </h1>
                <p className="text-xs text-slate-500">
                  Pemindai RFID RC522 / NFC · Pemilahan Otomatis Real-Time
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setVoiceEnabled((v) => !v)}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                voiceEnabled
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                  : 'border-slate-200 bg-white text-slate-600'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>{voiceEnabled ? 'Suara Aktif' : 'Suara Mati'}</span>
            </button>

            <select
              aria-label="Pilih Station RFID"
              value={station.Station_ID}
              onChange={(e) => setSelectedStationId(e.target.value)}
              className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800"
            >
              {stations.map((st) => (
                <option key={st.Station_ID} value={st.Station_ID}>
                  {st.Station_ID} · {st.Nama}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* School Level Selector Strip */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pb-3 flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-600 flex items-center gap-1.5 mr-1">
            <School className="w-4 h-4 text-emerald-700" />
            <span>Tingkat / Level Sekolah:</span>
          </span>
          <div className="flex flex-wrap gap-1.5">
            {JENJANG_OPTIONS.map((opt) => {
              const active = selectedJenjang === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onChangeJenjang(opt.value)}
                  className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    active
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left 7 cols: Interactive RFID Tap Pad & 3-Step Deposit Flow */}
          <section className="lg:col-span-7 bg-slate-900 text-white rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="text-xs font-mono text-emerald-400">
                  {station.Station_ID} · {station.Lokasi}
                </div>
                <h2 className="font-display text-xl font-bold mt-0.5">{station.Nama}</h2>
              </div>
              <div className="text-right text-xs text-slate-400">
                <div>Mode: {station.MODE_JENJANG === 'TK_SD' ? 'Ramah Anak (TK/SD)' : 'Umum (SMP & SMA/SMK)'}</div>
                <div>Sinkron {formatTimeAgo(station.Last_Heartbeat)}</div>
              </div>
            </div>

            {/* Step 1: Wait for RFID Tap */}
            {step === 'tap' && (
              <div className="space-y-5">
                <div className="border-2 border-dashed border-emerald-500/60 bg-slate-800/70 rounded-2xl p-6 sm:p-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                    <Wifi className="w-8 h-8 rotate-90" />
                  </div>
                  <div>
                    <h3 className="font-display text-2xl font-bold text-white">
                      Tempelkan Kartu RFID Anda
                    </h3>
                    <p className="mt-1.5 text-sm text-slate-300 max-w-md mx-auto">
                      Pindai dengan pembaca RFID USB/NFC, ketik UID kartu, atau klik langsung salah satu kartu siswa/kelas di panel sebelah kanan.
                    </p>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleTapCard(uidInput);
                    }}
                    className="max-w-md mx-auto flex flex-col sm:flex-row gap-2 pt-2"
                  >
                    <input
                      ref={inputRef}
                      type="text"
                      value={uidInput}
                      onChange={(e) => setUidInput(e.target.value.toUpperCase())}
                      placeholder="Tempel kartu / ketik UID (mis. 04A1B2C3)"
                      className="flex-1 min-h-[46px] px-4 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <button
                      type="submit"
                      className="min-h-[46px] px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm cursor-pointer whitespace-nowrap"
                    >
                      Tap Kartu
                    </button>
                  </form>
                </div>

                {/* Live 3 Compartment Capacities */}
                <div className="grid grid-cols-3 gap-3">
                  {station.Kompartemen.map((comp) => {
                    const isFull = comp.isi_persen > 80;
                    return (
                      <div
                        key={comp.jenis}
                        className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-200">{comp.label}</span>
                          <span className={isFull ? 'text-red-400 font-bold' : 'text-emerald-400'}>
                            {comp.isi_persen}%
                          </span>
                        </div>
                        <div className="mt-2 h-2 rounded-full bg-slate-700 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              isFull
                                ? 'bg-red-500'
                                : comp.jenis === 'Organik'
                                ? 'bg-emerald-500'
                                : comp.jenis === 'Anorganik'
                                ? 'bg-amber-400'
                                : 'bg-slate-400'
                            }`}
                            style={{ width: `${comp.isi_persen}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Step 2: Choose Waste Bin (10s timer) */}
            {step === 'choose_bin' && (
              <div className="space-y-5">
                <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-700 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-xs text-emerald-300 font-semibold">
                      Kartu Terbaca ({activeUid})
                    </div>
                    <div className="font-display text-lg font-bold text-white">
                      {previewClass
                        ? `Kartu Kelas ${previewClass.Kelas} (${previewClass.Jenjang})`
                        : `${previewUser?.Nama} · ${previewUser?.Kelas} (${previewUser?.Jenjang})`}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono tabular-nums text-amber-300">
                    <Clock className="w-4 h-4" />
                    <span>Pilih dalam {countdown} dtk</span>
                  </div>
                </div>

                <h3 className="font-display text-lg font-bold">
                  Pilih Jenis Sampah yang Akan Dibuang:
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => handleChooseBin('Organik')}
                    className="min-h-[128px] p-5 rounded-2xl bg-emerald-700 hover:bg-emerald-600 text-white text-left flex flex-col justify-between transition-colors cursor-pointer"
                  >
                    <Leaf className="w-7 h-7" />
                    <div>
                      <div className="font-display text-lg font-bold">Kompos</div>
                      <div className="text-xs text-emerald-100 mt-0.5">
                        Tong Hijau · Sisa makanan, daun, kulit buah
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleChooseBin('Anorganik')}
                    className="min-h-[128px] p-5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white text-left flex flex-col justify-between transition-colors cursor-pointer"
                  >
                    <Recycle className="w-7 h-7" />
                    <div>
                      <div className="font-display text-lg font-bold">Daur Ulang</div>
                      <div className="text-xs text-amber-100 mt-0.5">
                        Tong Kuning · Botol plastik, kertas, kaleng
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleChooseBin('Residu')}
                    className="min-h-[128px] p-5 rounded-2xl bg-slate-700 hover:bg-slate-600 text-white text-left flex flex-col justify-between transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-7 h-7" />
                    <div>
                      <div className="font-display text-lg font-bold">Residu</div>
                      <div className="text-xs text-slate-200 mt-0.5">
                        Tong Abu-abu · Tisu kotor, styrofoam, sachet
                      </div>
                    </div>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={resetReader}
                  className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
                >
                  Batalkan &amp; Tap Kartu Lain
                </button>
              </div>
            )}

            {/* Step 3: Weigh & Deposit */}
            {step === 'weigh' && (
              <div className="space-y-5">
                <div className="p-4 rounded-xl bg-slate-800 border border-slate-700 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-xs text-slate-400">Penyetor · {activeUid}</div>
                    <div className="font-display font-bold text-white">
                      {previewClass
                        ? `Setoran Kolektif ${previewClass.Kelas}`
                        : `${previewUser?.Nama} (${previewUser?.Kelas})`}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-400">Kompartemen Terpilih</div>
                    <div className="font-display font-bold text-emerald-400">
                      {selectedBin === 'Organik'
                        ? 'Kompos (Hijau)'
                        : selectedBin === 'Anorganik'
                        ? 'Daur Ulang (Kuning)'
                        : 'Residu (Abu-abu)'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700 space-y-3">
                    <label className="block text-xs font-semibold text-slate-300">
                      Berat Sampah Timbangan (HX711 · min 0,02 kg)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="10"
                      value={weightKg}
                      onChange={(e) => setWeightKg(Number(e.target.value))}
                      className="w-full min-h-[46px] px-3.5 rounded-lg bg-slate-950 border border-slate-700 font-mono tabular-nums text-lg font-bold text-white"
                    />
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { label: '0.01 kg (Uji <20g)', val: 0.01 },
                        { label: '0.25 kg', val: 0.25 },
                        { label: '0.50 kg', val: 0.5 },
                        { label: '1.20 kg', val: 1.2 },
                      ].map((p) => (
                        <button
                          key={p.label}
                          type="button"
                          onClick={() => setWeightKg(p.val)}
                          className="px-2.5 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-[11px] font-mono text-slate-200 cursor-pointer"
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700 space-y-3">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                      <span>Simulasi Sensor Isi Tong</span>
                      <span
                        className={`font-mono font-bold ${
                          fillPct > 80 ? 'text-red-400' : 'text-emerald-400'
                        }`}
                      >
                        {fillPct}% {fillPct > 80 ? '(PICU ALERT >80%)' : ''}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="98"
                      value={fillPct}
                      onChange={(e) => setFillPct(Number(e.target.value))}
                      className="w-full accent-emerald-500"
                    />
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFillPct(55)}
                        className="px-2.5 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-[11px] text-slate-200 cursor-pointer"
                      >
                        Normal (55%)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFillPct(88)}
                        className="px-2.5 py-1.5 rounded-md bg-red-900/70 hover:bg-red-800 text-[11px] text-red-100 cursor-pointer"
                      >
                        Penuh (88% · Notifikasi Otomatis)
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setStep('choose_bin')}
                    className="min-h-[44px] px-4 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:bg-slate-800 cursor-pointer"
                  >
                    &larr; Ganti Jenis Sampah
                  </button>
                  <button
                    type="button"
                    disabled={submitting}
                    onClick={handleSubmitDeposit}
                    className="min-h-[48px] px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white font-semibold text-sm cursor-pointer"
                  >
                    {submitting ? 'Menimbang & Menyimpan...' : 'Kirim Setoran ke Station'}
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Success or Error Feedback */}
            {(step === 'done' || step === 'error') && resultInfo && (
              <div className="space-y-5">
                <div
                  className={`p-6 rounded-2xl border ${
                    step === 'done'
                      ? 'bg-emerald-950/70 border-emerald-600 text-emerald-50'
                      : 'bg-red-950/70 border-red-600 text-red-50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {step === 'done' ? (
                      station.MODE_JENJANG === 'TK_SD' ? (
                        <Sparkles className="w-7 h-7 text-amber-300 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-7 h-7 text-emerald-400 shrink-0" />
                      )
                    ) : (
                      <AlertTriangle className="w-7 h-7 text-red-400 shrink-0" />
                    )}
                    <div>
                      <h3 className="font-display text-xl font-bold">{resultInfo.title}</h3>
                      <p className="mt-1 text-sm opacity-90">{resultInfo.detail}</p>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={resetReader}
                  className="min-h-[46px] px-5 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Tap Kartu RFID Berikutnya</span>
                </button>
              </div>
            )}
          </section>

          {/* Right 5 cols: Preview + Quick-Tap RFID Cards per School Level */}
          <aside className="lg:col-span-5 space-y-5">
            {/* Selected / Scanned Card Visual Preview */}
            {previewUser && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-600">
                  Pratinjau Kartu RFID Terpindai
                </div>
                <StudentRfidCard
                  student={previewUser}
                  classCardUid={classes.find((c) => c.Kelas === previewUser.Kelas)?.Kartu_Kelas}
                  compact
                />
              </div>
            )}

            {/* Quick Tap Cards Gallery */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <div>
                <h3 className="font-display font-bold text-slate-900 text-base">
                  Pilih Kartu RFID untuk Di-Tap ({selectedJenjang === 'ALL' ? 'Semua Jenjang' : selectedJenjang})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Klik salah satu kartu siswa atau Kartu Kelas di bawah untuk langsung menempelkannya ke pembaca RFID.
                </p>
              </div>

              {visibleClassCards.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    Kartu Kelas Kolektif (TK &amp; SD Awal)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                    {visibleClassCards.map((cls) => (
                      <button
                        key={cls.Kelas}
                        type="button"
                        onClick={() => handleTapCard(cls.Kartu_Kelas!)}
                        className="p-3 rounded-xl border border-amber-200 bg-amber-50/70 hover:bg-amber-100/80 text-left flex items-center justify-between gap-2 transition-colors cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            Kartu Kelas {cls.Kelas} ({cls.Jenjang})
                          </div>
                          <div className="text-[11px] text-slate-600 truncate">
                            Wali: {cls.Wali_Kelas}
                          </div>
                        </div>
                        <span className="font-mono text-xs font-bold text-amber-800 shrink-0">
                          {cls.Kartu_Kelas}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {visibleStudents.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    Kartu RFID Pribadi Siswa
                  </div>
                  <div className="grid grid-cols-1 gap-2 max-h-72 overflow-y-auto pr-1">
                    {visibleStudents.map((stu) => (
                      <button
                        key={stu.ID_Pengguna}
                        type="button"
                        onClick={() => handleTapCard(stu.Kartu_RFID!)}
                        className="p-3 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 text-left flex items-center justify-between gap-2 transition-colors cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {stu.Nama}
                            {!stu.Persetujuan_Ortu && (
                              <span className="ml-1.5 text-[11px] font-medium text-red-700">
                                (Belum Aktif)
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {stu.Jenjang} · {stu.Kelas}
                          </div>
                        </div>
                        <span className="font-mono text-xs font-bold text-emerald-800 shrink-0">
                          {stu.Kartu_RFID}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => handleTapCard('DEADBEEF')}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-dashed border-slate-300 hover:border-red-400 hover:bg-red-50/50 text-xs font-medium text-slate-600 hover:text-red-800 flex items-center justify-between cursor-pointer"
              >
                <span>Uji Tap Kartu Tidak Terdaftar</span>
                <span className="font-mono font-bold">DEADBEEF</span>
              </button>
            </div>

            {/* Recent IoT Taps */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <h4 className="font-display font-semibold text-slate-900 text-sm">
                Riwayat Tap RFID Terbaru
              </h4>
              {recentIot.length === 0 ? (
                <p className="text-xs text-slate-500">Belum ada transaksi tap RFID di jenjang ini.</p>
              ) : (
                <div className="divide-y divide-slate-100 text-xs">
                  {recentIot.map((item) => (
                    <div key={item.ID} className="py-2 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900 truncate">
                          {item.Nama_Penyetor} · {item.Jenis}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {item.Jenjang} · {item.Kelas} · {item.Station_ID} · {formatTimeAgo(item.Tanggal)}
                        </div>
                      </div>
                      <div className="text-right font-mono tabular-nums shrink-0">
                        <div className="font-bold text-slate-900">{item.Berat_kg} kg</div>
                        <div className="text-[11px] text-emerald-700">+{item.Poin} poin</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};
