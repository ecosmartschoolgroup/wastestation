import React, { useState } from 'react';
import {
  Wifi,
  CreditCard,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Radio,
} from 'lucide-react';
import type { Kelas, Pengguna, Station } from '../types.ts';
import { playBuzzerPattern } from '../utils/audio.ts';
import { formatTimeAgo } from '../utils/wasteStyles.ts';

interface WasteStationKioskViewProps {
  stations: Station[];
  users: Pengguna[];
  classes: Kelas[];
  onRefresh: () => void;
}

export const WasteStationKioskView: React.FC<WasteStationKioskViewProps> = ({
  stations,
  users,
  classes,
  onRefresh,
}) => {
  const [selectedStationId, setSelectedStationId] = useState(
    stations[0]?.Station_ID || 'WS-SMK-01'
  );
  const station =
    stations.find((s) => s.Station_ID === selectedStationId) || stations[0];

  const [rfidInput, setRfidInput] = useState('04A1B2C3');
  const [selectedBin, setSelectedBin] = useState<'Organik' | 'Anorganik' | 'Residu'>('Anorganik');
  const [weightKg, setWeightKg] = useState(0.35);
  const [simFillPct, setSimFillPct] = useState(65);
  const [ledState, setLedState] = useState<'hijau' | 'biru' | 'merah' | 'oranye'>('hijau');
  const [statusBanner, setStatusBanner] = useState<{
    type: 'idle' | 'success' | 'error';
    title: string;
    detail: string;
  }>({
    type: 'idle',
    title: 'Tempelkan Kartu Pelajar / Kartu Kelas pada Pembaca RC522',
    detail: 'Setelah bunyi buzzer 80 ms, pilih jenis sampah lalu masukkan sampah ke kompartemen.',
  });
  const [sending, setSending] = useState(false);

  const rfidPresets = [
    ...users
      .filter((u) => Boolean(u.Kartu_RFID))
      .map((u) => ({
        uid: u.Kartu_RFID!,
        label: `${u.Nama} (${u.Kelas})${!u.Persetujuan_Ortu ? ' - Belum Persetujuan Ortu' : ''}`,
      })),
    ...classes
      .filter((c) => Boolean(c.Kartu_Kelas))
      .map((c) => ({
        uid: c.Kartu_Kelas!,
        label: `Kartu Kelas ${c.Kelas} (${c.Jenjang})`,
      })),
    { uid: 'DEADBEEF', label: 'Kartu Tidak Terdaftar (Uji G-01)' },
  ];

  const handleTapAndSend = async () => {
    if (!station || sending) return;
    setSending(true);
    playBuzzerPattern('card_read', station.MODE_JENJANG);
    setLedState('biru');

    // Simulate 8s weighing window compacted to 450ms for interactive usability
    await new Promise((r) => setTimeout(r, 450));

    if (weightKg < 0.02) {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setLedState(station.MODE_JENJANG === 'TK_SD' ? 'oranye' : 'merah');
      setStatusBanner({
        type: 'error',
        title: 'Sampah di Bawah Batas Minimum (< 20 g)',
        detail:
          station.MODE_JENJANG === 'TK_SD'
            ? 'Kedip oranye & nada ramah: Ayo coba masukkan sampah lebih banyak lagi.'
            : 'Buzzer 600 ms: Berat di bawah 0,02 kg, data tidak dikirim ke server (BR-05).',
      });
      setSending(false);
      return;
    }

    try {
      const res = await fetch('/api/iot/setoran', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: station.Token,
          station: station.Station_ID,
          kartu: rfidInput,
          jenis: selectedBin,
          berat_kg: weightKg,
          isi_persen: simFillPct,
        }),
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        playBuzzerPattern('error', station.MODE_JENJANG);
        setLedState(station.MODE_JENJANG === 'TK_SD' ? 'oranye' : 'merah');
        setStatusBanner({
          type: 'error',
          title: `Ditolak Server: ${data.pesan || 'Gagal mengirim'}`,
          detail: `Perbaikan G-01 aktif: meskipun respons selesai, ok=false tidak membunyikan sukses.`,
        });
      } else {
        playBuzzerPattern('success', station.MODE_JENJANG);
        setLedState(simFillPct > 80 ? 'merah' : 'hijau');
        setStatusBanner({
          type: 'success',
          title: `Tersimpan untuk ${data.kelas} (+${data.poin} poin)`,
          detail: data.alert
            ? `Notifikasi tong penuh (>80%) otomatis dikirim ke Eco Ranger!`
            : `Status otomatis Terverifikasi (Sumber IoT · ${station.Station_ID}).`,
        });
        onRefresh();
      }
    } catch {
      playBuzzerPattern('error', station.MODE_JENJANG);
      setStatusBanner({
        type: 'error',
        title: 'Koneksi Wi-Fi Terputus',
        detail: 'Transaksi masuk antrean flash ESP32 untuk dikirim ulang otomatis (G-06).',
      });
    } finally {
      setSending(false);
    }
  };

  if (!station) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Layar Waste Station &amp; Simulator IoT ESP32
          </h2>
          <p className="text-sm text-slate-600">
            Tampilan tablet kiosk station (FR-WS-01..05) sekaligus simulator uji payload IoT langsung ke backend.
          </p>
        </div>

        <select
          aria-label="Pilih Station"
          value={selectedStationId}
          onChange={(e) => setSelectedStationId(e.target.value)}
          className="min-h-[42px] px-3.5 rounded-lg border border-slate-300 bg-white text-sm font-semibold"
        >
          {stations.map((st) => (
            <option key={st.Station_ID} value={st.Station_ID}>
              {st.Station_ID} · {st.Lokasi} ({st.MODE_JENJANG})
            </option>
          ))}
        </select>
      </div>

      {/* Tablet Kiosk Display Frame (FR-WS-01..04) */}
      <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <Cpu className="w-6 h-6 text-emerald-400" />
            <div>
              <h3 className="font-display text-xl font-bold">{station.Station_ID}</h3>
              <p className="text-xs text-slate-400">
                {station.Lokasi} · Mode {station.MODE_JENJANG}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-300">
            <span className="flex items-center gap-1.5">
              <Wifi className="w-4 h-4 text-emerald-400" />
              {station.WiFi_SSID}
            </span>
            <span>Sinkron {formatTimeAgo(station.Last_Heartbeat)}</span>
          </div>
        </div>

        {/* Status Banner on Kiosk */}
        <div
          className={`p-5 rounded-xl border ${
            statusBanner.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-600 text-emerald-100'
              : statusBanner.type === 'error'
              ? 'bg-red-950/70 border-red-600 text-red-100'
              : 'bg-slate-800 border-slate-700 text-slate-100'
          }`}
        >
          <div className="flex items-start gap-3">
            {statusBanner.type === 'success' ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            ) : statusBanner.type === 'error' ? (
              <AlertTriangle className="w-6 h-6 text-red-400 shrink-0" />
            ) : (
              <CreditCard className="w-6 h-6 text-sky-400 shrink-0" />
            )}
            <div>
              <div className="font-display text-lg font-bold">{statusBanner.title}</div>
              <p className="text-sm opacity-90 mt-0.5">{statusBanner.detail}</p>
            </div>
          </div>
        </div>

        {/* 3 Compartment Tiles (FR-WS-03) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {station.Kompartemen.map((comp) => {
            const isPicked = selectedBin === comp.jenis;
            const isFull = comp.isi_persen > 80;
            return (
              <div
                key={comp.jenis}
                className={`p-5 rounded-xl border transition-colors ${
                  isPicked
                    ? 'bg-slate-800 border-sky-400 ring-1 ring-sky-400'
                    : 'bg-slate-800/50 border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display font-bold text-lg">{comp.label}</span>
                  <span
                    className={`text-xs font-semibold ${
                      isFull ? 'text-red-400' : 'text-emerald-400'
                    }`}
                  >
                    {isFull ? 'PERLU DIKOSONGKAN' : isPicked ? 'DIPILIH' : 'SIAP'}
                  </span>
                </div>

                <div className="mt-4 flex items-baseline justify-between">
                  <span className="font-mono tabular-nums text-3xl font-bold">
                    {comp.isi_persen}%
                  </span>
                  <span className="font-mono tabular-nums text-xs text-slate-400">
                    Hari ini: {comp.berat_hari_ini.toFixed(2)} kg
                  </span>
                </div>

                <div className="mt-3 h-2.5 rounded-full bg-slate-700 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      isFull
                        ? 'bg-red-500'
                        : comp.jenis === 'Organik'
                        ? 'bg-emerald-500'
                        : comp.jenis === 'Anorganik'
                        ? 'bg-amber-400'
                        : 'bg-slate-400'
                    }`}
                    style={{ width: `${comp.isi_persen}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* WS2812 9-LED Strip visual */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4" />
            <span>Indikator LED WS2812 (GPIO 2):</span>
            <div className="flex items-center gap-1.5 ml-1">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className={`w-3 h-3 rounded-full ${
                    ledState === 'biru'
                      ? 'bg-sky-400'
                      : ledState === 'merah'
                      ? 'bg-red-500'
                      : ledState === 'oranye'
                      ? 'bg-orange-400'
                      : 'bg-emerald-400'
                  }`}
                />
              ))}
            </div>
          </div>
          <span className="font-mono">POST /api/iot/setoran · HX711 + HC-SR04</span>
        </div>
      </section>

      {/* Interactive Hardware Simulator Controls */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-semibold text-slate-900">
            Panel Simulasi Sensor ESP32 (Uji Alur IoT &amp; Notifikasi Tong Penuh)
          </h3>
          <span className="text-xs text-slate-500 flex items-center gap-1">
            <Volume2 className="w-4 h-4" /> Audio Buzzer Aktif
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Kartu RFID (RC522)
            </label>
            <select
              value={rfidInput}
              onChange={(e) => setRfidInput(e.target.value)}
              className="w-full min-h-[42px] px-3 rounded-lg border border-slate-300 text-xs"
            >
              {rfidPresets.map((p) => (
                <option key={p.uid} value={p.uid}>
                  {p.uid} — {p.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Tombol Kompartemen (ADC GPIO 39)
            </label>
            <select
              value={selectedBin}
              onChange={(e) =>
                setSelectedBin(e.target.value as 'Organik' | 'Anorganik' | 'Residu')
              }
              className="w-full min-h-[42px] px-3 rounded-lg border border-slate-300 text-xs"
            >
              <option value="Organik">Kompos (Organik)</option>
              <option value="Anorganik">Daur Ulang (Anorganik)</option>
              <option value="Residu">Residu</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Berat Terukur HX711 (kg)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              max="10"
              value={weightKg}
              onChange={(e) => setWeightKg(Number(e.target.value))}
              className="w-full min-h-[42px] px-3 rounded-lg border border-slate-300 font-mono tabular-nums text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Isi Tong HC-SR04 ({simFillPct}% — &gt;80% Picu Alert)
            </label>
            <input
              type="range"
              min="10"
              max="98"
              value={simFillPct}
              onChange={(e) => setSimFillPct(Number(e.target.value))}
              className="w-full mt-2 accent-emerald-700"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <p className="text-xs text-slate-500">
            Coba geser isi tong ke <strong>88%</strong> lalu tekan tombol kirim untuk menguji notifikasi otomatis real-time ke Eco Ranger &amp; Dashboard!
          </p>
          <button
            type="button"
            disabled={sending}
            onClick={handleTapAndSend}
            className="min-h-[44px] px-5 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer"
          >
            {sending ? 'Menimbang & Mengirim...' : 'Simulasikan Tap RFID & Buang Sampah'}
          </button>
        </div>
      </section>
    </div>
  );
};
