import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Volume2,
  BookOpen,
  HelpCircle,
} from 'lucide-react';
import type { Jenjang, JenisSampah, KuisSoal, PanduanItem, Pengguna } from '../types.ts';
import { WASTE_META, getJenisLabel } from '../utils/wasteStyles.ts';
import { speakIndonesian } from '../utils/audio.ts';

interface PanduanKuisViewProps {
  user: Pengguna;
  panduan: PanduanItem[];
  kuisSoal: KuisSoal[];
  jenisSampah: JenisSampah[];
  onQuizSaved: () => void;
}

export const PanduanKuisView: React.FC<PanduanKuisViewProps> = ({
  user,
  panduan,
  kuisSoal,
  jenisSampah,
  onQuizSaved,
}) => {
  const [tab, setTab] = useState<'panduan' | 'kuis'>('panduan');
  const [searchItem, setSearchItem] = useState('');
  const [jenjangFilter, setJenjangFilter] = useState<Jenjang>(user.Jenjang);

  // Quiz state
  const [quizStarted, setQuizStarted] = useState(false);
  const [sessionQuestions, setSessionQuestions] = useState<KuisSoal[]>([]);
  const [qIdx, setQIdx] = useState(0);
  const [selectedAns, setSelectedAns] = useState<'A' | 'B' | 'C' | 'D' | null>(null);
  const [score, setScore] = useState(0);
  const [wrongTypes, setWrongTypes] = useState<string[]>([]);
  const [quizFinished, setQuizFinished] = useState(false);

  const filteredPanduan = panduan.filter((p) => {
    if (!searchItem.trim()) return true;
    const q = searchItem.toLowerCase();
    return (
      p.Item.toLowerCase().includes(q) ||
      p.Keterangan.toLowerCase().includes(q) ||
      p.Salah_Kaprah.toLowerCase().includes(q) ||
      p.Contoh_Masuk.some((c) => c.toLowerCase().includes(q)) ||
      p.Jangan_Masuk.some((c) => c.toLowerCase().includes(q))
    );
  });

  const startQuiz = () => {
    const pool = kuisSoal.filter((q) => q.Jenjang === jenjangFilter);
    const source = pool.length >= 5 ? pool : kuisSoal;
    const shuffled = [...source].sort(() => Math.random() - 0.5).slice(0, 5);
    setSessionQuestions(shuffled);
    setQIdx(0);
    setSelectedAns(null);
    setScore(0);
    setWrongTypes([]);
    setQuizFinished(false);
    setQuizStarted(true);
  };

  const handleAnswer = (opt: 'A' | 'B' | 'C' | 'D') => {
    if (selectedAns) return;
    setSelectedAns(opt);
    const current = sessionQuestions[qIdx];
    if (opt === current.Jawaban) {
      setScore((s) => s + 1);
    } else {
      setWrongTypes((prev) => [...prev, getJenisLabel(current.Jenis_Terkait, jenisSampah)]);
    }
  };

  const nextQuestion = async () => {
    if (qIdx + 1 < sessionQuestions.length) {
      setQIdx((i) => i + 1);
      setSelectedAns(null);
    } else {
      setQuizFinished(true);
      try {
        await fetch('/api/kuis/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            idPengguna: user.ID_Pengguna,
            email: user.Email,
            nama: user.Nama,
            kelas: user.Kelas || '-',
            jenjang: jenjangFilter,
            skor: score,
            total: sessionQuestions.length,
          }),
        });
        onQuizSaved();
      } catch {
        // ignore offline quiz save error
      }
    }
  };

  const currentQ = sessionQuestions[qIdx];

  // Most frequent wrong type
  const mostWrong =
    wrongTypes.length > 0
      ? wrongTypes.sort(
          (a, b) =>
            wrongTypes.filter((v) => v === b).length -
            wrongTypes.filter((v) => v === a).length
        )[0]
      : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Panduan Pilah Sampah & Kuis Edukasi
          </h2>
          <p className="text-sm text-slate-600">
            Pelajari aturan pemilahan per warna & ikon tong, cari contoh barang, lalu uji pemahaman lewat kuis.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setTab('panduan')}
            className={`min-h-[38px] px-4 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              tab === 'panduan' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Panduan Pilah</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('kuis')}
            className={`min-h-[38px] px-4 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              tab === 'kuis' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Kuis ({jenjangFilter})</span>
          </button>
        </div>
      </div>

      {tab === 'panduan' ? (
        <div className="space-y-5">
          {/* Search item (FR-PK-02) */}
          <div className="relative max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchItem}
              onChange={(e) => setSearchItem(e.target.value)}
              placeholder="Cari nama barang (mis. styrofoam, baterai, botol)..."
              className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPanduan.map((item) => {
              const meta = WASTE_META[item.Jenis];
              return (
                <article
                  key={item.ID}
                  className="bg-white border border-slate-200 rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className={`text-xs font-semibold ${meta.colorText}`}>
                        {getJenisLabel(item.Jenis, jenisSampah)} · {meta.shapeLabel}
                      </span>
                      <h3 className="font-display font-bold text-slate-900 text-lg mt-0.5">
                        {item.Item}
                      </h3>
                    </div>
                    <button
                      type="button"
                      aria-label="Bacakan panduan"
                      onClick={() =>
                        speakIndonesian(
                          `${getJenisLabel(item.Jenis, jenisSampah)}. ${item.Keterangan} ${item.Salah_Kaprah}`
                        )
                      }
                      className="min-h-[40px] min-w-[40px] rounded-lg border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer shrink-0"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-sm text-slate-700">{item.Keterangan}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200">
                      <span className="text-xs font-semibold text-emerald-900 block mb-1.5">
                        Boleh Masuk
                      </span>
                      <ul className="space-y-1 text-xs text-emerald-900">
                        {item.Contoh_Masuk.map((c) => (
                          <li key={c}>· {c}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50/70 border border-red-200">
                      <span className="text-xs font-semibold text-red-900 block mb-1.5">
                        Jangan Masuk
                      </span>
                      <ul className="space-y-1 text-xs text-red-900">
                        {item.Jangan_Masuk.map((c) => (
                          <li key={c}>· {c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 pt-1">
                    <strong>Perhatian:</strong> {item.Salah_Kaprah}
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      ) : (
        /* Quiz View (FR-PK-03..06) */
        <div className="max-w-2xl bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
          {!quizStarted ? (
            <div className="space-y-5">
              <div>
                <h3 className="font-display text-xl font-bold text-slate-900">
                  Kuis Pemilahan Sampah (5 Soal Acak)
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Soal dipilih acak dari bank soal sesuai jenjang. Setiap jawaban langsung menampilkan penjelasan.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Pilih Bank Soal Jenjang
                </label>
                <div className="flex flex-wrap gap-2">
                  {(['TK', 'SD', 'SMP', 'SMA/SMK'] as Jenjang[]).map((j) => (
                    <button
                      key={j}
                      type="button"
                      onClick={() => setJenjangFilter(j)}
                      className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-semibold border cursor-pointer ${
                        jenjangFilter === j
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      Jenjang {j}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={startQuiz}
                className="min-h-[44px] px-6 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
              >
                Mulai Kuis Sekarang
              </button>
            </div>
          ) : quizFinished ? (
            <div className="space-y-5 text-center py-4">
              <div className="font-mono tabular-nums text-4xl font-bold text-emerald-700">
                {score} / {sessionQuestions.length}
              </div>
              <h3 className="font-display text-xl font-bold text-slate-900">
                Kuis Selesai!
              </h3>
              <p className="text-sm text-slate-600">
                {mostWrong
                  ? `Jenis yang paling perlu kamu pelajari ulang: ${mostWrong}.`
                  : 'Luar biasa! Semua soal terjawab dengan tepat.'}
              </p>
              <button
                type="button"
                onClick={startQuiz}
                className="min-h-[44px] px-5 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ulangi Kuis</span>
              </button>
            </div>
          ) : (
            currentQ && (
              <div className="space-y-5">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>
                    Soal {qIdx + 1} dari {sessionQuestions.length} · Jenjang {currentQ.Jenjang}
                  </span>
                  <button
                    type="button"
                    onClick={() => speakIndonesian(currentQ.Pertanyaan)}
                    className="flex items-center gap-1 text-emerald-700 font-semibold cursor-pointer"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>Bacakan</span>
                  </button>
                </div>

                <h3 className="font-display text-lg font-bold text-slate-900">
                  {currentQ.Pertanyaan}
                </h3>

                <div className="space-y-2.5">
                  {(['A', 'B', 'C', 'D'] as const).map((opt) => {
                    const text =
                      opt === 'A'
                        ? currentQ.Opsi_A
                        : opt === 'B'
                        ? currentQ.Opsi_B
                        : opt === 'C'
                        ? currentQ.Opsi_C
                        : currentQ.Opsi_D;
                    const isPicked = selectedAns === opt;
                    const isCorrect = currentQ.Jawaban === opt;

                    let style = 'border-slate-200 bg-white hover:bg-slate-50 text-slate-800';
                    if (selectedAns) {
                      if (isCorrect) style = 'border-emerald-600 bg-emerald-50 text-emerald-900';
                      else if (isPicked) style = 'border-red-500 bg-red-50 text-red-900';
                      else style = 'border-slate-200 bg-slate-50 text-slate-400';
                    }

                    return (
                      <button
                        key={opt}
                        type="button"
                        disabled={Boolean(selectedAns)}
                        onClick={() => handleAnswer(opt)}
                        className={`w-full min-h-[48px] px-4 py-3 rounded-xl border text-left text-sm font-medium flex items-center justify-between gap-3 transition-colors cursor-pointer ${style}`}
                      >
                        <span>
                          <strong className="mr-2">{opt}.</strong>
                          {text}
                        </span>
                        {selectedAns && isCorrect && (
                          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
                        )}
                        {selectedAns && isPicked && !isCorrect && (
                          <XCircle className="w-5 h-5 text-red-600 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {selectedAns && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                    <p className="text-sm text-slate-800">
                      <strong>Penjelasan: </strong>
                      {currentQ.Penjelasan}
                    </p>
                    <button
                      type="button"
                      onClick={nextQuestion}
                      className="min-h-[44px] px-5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                    >
                      {qIdx + 1 < sessionQuestions.length ? 'Soal Berikutnya' : 'Lihat Hasil Akhir'}
                    </button>
                  </div>
                )}
              </div>
            )
          )}
        </div>
      )}
    </div>
  );
};
