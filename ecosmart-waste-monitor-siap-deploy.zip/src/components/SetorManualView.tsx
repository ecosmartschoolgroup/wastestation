import React, { useState, useEffect } from 'react';
import {
  Leaf,
  Recycle,
  Trash2,
  BatteryCharging,
  Minus,
  Plus,
  Camera,
  CheckCircle2,
  WifiOff,
  BookOpen,
} from 'lucide-react';
import type { JenisKey, JenisSampah, Pengguna } from '../types.ts';

interface SetorManualViewProps {
  user: Pengguna;
  jenisSampah: JenisSampah[];
  onSubmitted: () => void;
  onGoPanduan: () => void;
}

interface OfflineItem {
  idLocal: string;
  payload: Record<string, unknown>;
  createdAt: string;
}

const OFFLINE_KEY = 'ecosmart_offline_queue';

export const SetorManualView: React.FC<SetorManualViewProps> = ({
  user,
  jenisSampah,
  onSubmitted,
  onGoPanduan,
}) => {
  // BR-12: TK & SD students cannot deposit Elektronik/Baterai
  const allowedJenis = jenisSampah.filter(
    (j) =>
      !(
        j.Jenis === 'Elektronik' &&
        (user.Jenjang === 'TK' || user.Jenjang === 'SD') &&
        user.Peran === 'Siswa'
      )
  );

  const [selectedJenis, setSelectedJenis] = useState<JenisKey>('Anorganik');
  const [subjenis, setSubjenis] = useState<string>('Plastik');
  const [beratKg, setBeratKg] = useState<number>(0.5);
  const [jumlahItem, setJumlahItem] = useState<number>(2);
  const [fotoPreview, setFotoPreview] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [offlineQueue, setOfflineQueue] = useState<OfflineItem[]>([]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(OFFLINE_KEY) || '[]');
      if (Array.isArray(saved)) setOfflineQueue(saved);
    } catch {
      // ignore
    }
  }, []);

  const currentJenisObj =
    allowedJenis.find((j) => j.Jenis === selectedJenis) || allowedJenis[0];

  const handleSelectJenis = (j: JenisSampah) => {
    setSelectedJenis(j.Jenis);
    setSubjenis(j.Subjenis[0] || '');
    setSuccessMsg('');
    setError('');
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setFotoPreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const estimatedPoints =
    currentJenisObj.Satuan === 'item'
      ? Math.round(jumlahItem * currentJenisObj.Poin_per_satuan)
      : Math.round(beratKg * currentJenisObj.Poin_per_satuan);

  const flushOfflineQueue = async () => {
    if (offlineQueue.length === 0) return;
    const remaining: OfflineItem[] = [];
    for (const item of offlineQueue) {
      try {
        const res = await fetch('/api/setoran/manual', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item.payload),
        });
        if (!res.ok) remaining.push(item);
      } catch {
        remaining.push(item);
      }
    }
    setOfflineQueue(remaining);
    localStorage.setItem(OFFLINE_KEY, JSON.stringify(remaining));
    if (remaining.length < offlineQueue.length) {
      onSubmitted();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return; // Anti double submit (FR-ST-07)

    setError('');
    setSuccessMsg('');

    if (currentJenisObj.Satuan === 'kg' && (beratKg < 0.1 || beratKg > 20)) {
      setError('Berat harus antara 0,1 kg dan 20 kg.');
      return;
    }

    setSubmitting(true);
    const payload = {
      idPengguna: user.ID_Pengguna,
      tipePenyetor: 'Siswa',
      jenis: selectedJenis,
      subjenis,
      beratKg: currentJenisObj.Satuan === 'kg' ? Number(beratKg.toFixed(1)) : 0,
      jumlahItem: currentJenisObj.Satuan === 'item' ? jumlahItem : undefined,
      foto: fotoPreview || undefined,
    };

    try {
      const res = await fetch('/api/setoran/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.pesan || 'Gagal menyimpan setoran.');
        return;
      }
      setSuccessMsg(
        `Setoran ${currentJenisObj.Label_Aplikasi} (${
          currentJenisObj.Satuan === 'item' ? `${jumlahItem} item` : `${beratKg.toFixed(1)} kg`
        }) berhasil dikirim dengan status Menunggu. Poin kelas (+${estimatedPoints}) akan aktif setelah diverifikasi Eco Ranger.`
      );
      setFotoPreview('');
      onSubmitted();
    } catch {
      // Offline queue fallback (FR-ST-09)
      const next = [
        ...offlineQueue,
        { idLocal: String(Date.now()), payload, createdAt: new Date().toISOString() },
      ];
      setOfflineQueue(next);
      localStorage.setItem(OFFLINE_KEY, JSON.stringify(next));
      setSuccessMsg(
        'Koneksi terputus. Setoran disimpan ke antrean offline perangkat dan siap dikirim saat online.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const iconForJenis = (k: JenisKey) => {
    if (k === 'Organik') return <Leaf className="w-5 h-5 text-emerald-700" />;
    if (k === 'Anorganik') return <Recycle className="w-5 h-5 text-amber-700" />;
    if (k === 'Residu') return <Trash2 className="w-5 h-5 text-slate-700" />;
    return <BatteryCharging className="w-5 h-5 text-orange-700" />;
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Setor Sampah Manual
          </h2>
          <p className="text-sm text-slate-600">
            Catat setoran di luar Smart Waste Station. Poin masuk setelah diverifikasi Eco Ranger.
          </p>
        </div>
        <button
          type="button"
          onClick={onGoPanduan}
          className="min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 self-start cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
          <span>Cek Panduan Pilah</span>
        </button>
      </div>

      {offlineQueue.length > 0 && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm text-amber-900">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>{offlineQueue.length} setoran berada di antrean offline.</span>
          </div>
          <button
            type="button"
            onClick={flushOfflineQueue}
            className="min-h-[36px] px-3 py-1.5 rounded-lg bg-amber-700 text-white text-xs font-semibold hover:bg-amber-800 cursor-pointer"
          >
            Kirim Sekarang
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Pilih Jenis */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">
            1. Pilih Jenis Sampah
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {allowedJenis.map((j) => {
              const active = j.Jenis === selectedJenis;
              return (
                <button
                  key={j.Jenis}
                  type="button"
                  onClick={() => handleSelectJenis(j)}
                  className={`p-4 rounded-xl border text-left transition-colors cursor-pointer min-h-[44px] ${
                    active
                      ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-semibold text-slate-900 text-sm">
                      {iconForJenis(j.Jenis)}
                      <span>{j.Label_Aplikasi}</span>
                    </div>
                    <span className="font-mono tabular-nums text-xs font-semibold text-emerald-700">
                      {j.Poin_per_satuan} poin/{j.Satuan}
                    </span>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-600">
                    Tong {j.Warna_Tong} · {j.Contoh}
                  </p>
                </button>
              );
            })}
          </div>

          {currentJenisObj.Subjenis.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100">
              <span className="block text-xs font-medium text-slate-600 mb-2">
                Subjenis (opsional):
              </span>
              <div className="flex flex-wrap gap-2">
                {currentJenisObj.Subjenis.map((sub) => (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSubjenis(sub)}
                    className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      subjenis === sub
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Step 2: Berat / Jumlah Item + Pratinjau Poin */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">
            2. Masukkan {currentJenisObj.Satuan === 'item' ? 'Jumlah Item' : 'Berat Sampah (kg)'}
          </h3>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            {currentJenisObj.Satuan === 'kg' ? (
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  aria-label="Kurangi berat"
                  onClick={() => setBeratKg((v) => Math.max(0.1, Number((v - 0.1).toFixed(1))))}
                  className="w-11 h-11 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-800 cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  max="20"
                  value={beratKg}
                  onChange={(e) => setBeratKg(Number(e.target.value))}
                  className="w-28 min-h-[44px] text-center font-mono tabular-nums text-lg font-bold rounded-lg border border-slate-300 px-2"
                />
                <button
                  type="button"
                  aria-label="Tambah berat"
                  onClick={() => setBeratKg((v) => Math.min(20, Number((v + 0.1).toFixed(1))))}
                  className="w-11 h-11 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-800 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <span className="text-sm text-slate-500">kg (maks 20 kg)</span>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setJumlahItem((v) => Math.max(1, v - 1))}
                  className="w-11 h-11 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={jumlahItem}
                  onChange={(e) => setJumlahItem(Number(e.target.value))}
                  className="w-24 min-h-[44px] text-center font-mono tabular-nums text-lg font-bold rounded-lg border border-slate-300 px-2"
                />
                <button
                  type="button"
                  onClick={() => setJumlahItem((v) => Math.min(50, v + 1))}
                  className="w-11 h-11 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <span className="text-sm text-slate-500">item</span>
              </div>
            )}

            <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200">
              <span className="text-xs text-emerald-800 block">Estimasi Poin Kelas</span>
              <span className="font-mono tabular-nums text-xl font-bold text-emerald-800">
                +{estimatedPoints} poin
              </span>
            </div>
          </div>
        </section>

        {/* Step 3: Foto Opsional */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-2">
            3. Foto Bukti Sampah (Opsional)
          </h3>
          <p className="text-xs text-slate-500 mb-3">
            Membantu Eco Ranger memverifikasi jenis dan kebersihan sampah lebih cepat.
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <label className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 inline-flex items-center gap-2 cursor-pointer">
              <Camera className="w-4 h-4" />
              <span>Ambil / Pilih Foto</span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoChange}
                className="hidden"
              />
            </label>
            {fotoPreview && (
              <div className="flex items-center gap-3">
                <img
                  src={fotoPreview}
                  alt="Pratinjau foto sampah"
                  className="w-16 h-16 object-cover rounded-lg border border-slate-200"
                />
                <button
                  type="button"
                  onClick={() => setFotoPreview('')}
                  className="text-xs text-red-600 hover:underline cursor-pointer"
                >
                  Hapus foto
                </button>
              </div>
            )}
          </div>
        </section>

        {error && (
          <div role="alert" className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-900 flex items-start gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-semibold text-sm transition-colors cursor-pointer"
        >
          {submitting ? 'Menyimpan Setoran...' : 'Simpan Setoran Manual'}
        </button>
      </form>
    </div>
  );
};
