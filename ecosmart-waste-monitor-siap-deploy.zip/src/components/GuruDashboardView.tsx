import React, { useEffect, useState } from 'react';
import {
  FileText,
  Download,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle2,
  Info,
  BarChart3,
  FileCode2,
} from 'lucide-react';
import type {
  AppDatabase,
  Jenjang,
  Kelas,
  KuisHasil,
  MonthlyAnalyticsReport,
  Setoran,
  Station,
} from '../types.ts';
import {
  downloadStandaloneHTMLSnapshot,
  generateMonthlyReportPDF,
} from '../utils/pdfGenerator.ts';
import { StudentRfidCard } from './StudentRfidCard.tsx';

interface GuruDashboardViewProps {
  db: AppDatabase;
  setoran: Setoran[];
  classes: Kelas[];
  stations: Station[];
  kuisHasil: KuisHasil[];
  initialTab?: 'rekap' | 'bulanan';
  selectedJenjang?: Jenjang | 'ALL';
}

export const GuruDashboardView: React.FC<GuruDashboardViewProps> = ({
  db,
  setoran,
  classes,
  stations,
  kuisHasil,
  initialTab = 'rekap',
  selectedJenjang,
}) => {
  const [subTab, setSubTab] = useState<'rekap' | 'bulanan' | 'rfid'>(initialTab);
  const [periode, setPeriode] = useState<'hari' | 'minggu' | 'bulan' | 'semua'>('minggu');
  const [jenjangFilter, setJenjangFilter] = useState<Jenjang | 'ALL'>(selectedJenjang || 'ALL');
  const [kelasFilter, setKelasFilter] = useState<string>('ALL');
  const [stationFilter, setStationFilter] = useState<string>('ALL');
  const [monthlyReport, setMonthlyReport] = useState<MonthlyAnalyticsReport | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string>('');

  useEffect(() => {
    setSubTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (selectedJenjang !== undefined) {
      setJenjangFilter(selectedJenjang);
      setKelasFilter('ALL');
    }
  }, [selectedJenjang]);

  useEffect(() => {
    const params = new URLSearchParams();
    if (jenjangFilter !== 'ALL') params.set('jenjang', jenjangFilter);
    if (selectedMonth) params.set('bulan', selectedMonth);
    fetch(`/api/reports/monthly?${params.toString()}`)
      .then((r) => r.json())
      .then((data: MonthlyAnalyticsReport) => setMonthlyReport(data))
      .catch(() => {});
  }, [jenjangFilter, selectedMonth, setoran.length]);

  const now = Date.now();
  const filteredVerified = setoran.filter((s) => {
    if (s.Status !== 'Terverifikasi') return false;
    if (jenjangFilter !== 'ALL' && s.Jenjang !== jenjangFilter) return false;
    if (kelasFilter !== 'ALL' && s.Kelas !== kelasFilter) return false;
    if (stationFilter !== 'ALL' && s.Station_ID !== stationFilter) return false;

    const age = now - new Date(s.Tanggal).getTime();
    if (periode === 'hari') return age <= 86400_000;
    if (periode === 'minggu') return age <= 7 * 86400_000;
    if (periode === 'bulan') return age <= 31 * 86400_000;
    return true;
  });

  const totalKg = filteredVerified.reduce((sum, s) => sum + s.Berat_kg, 0);
  const totalCount = filteredVerified.length;

  // Definition of "Terpilah benar" (PRD Section 7.6 & AC-DB-02): Manual verified where Jenis === Jenis_Awal; IoT excluded
  const manualVerified = filteredVerified.filter((s) => s.Sumber === 'Manual');
  const manualAccurate = manualVerified.filter((s) => s.Jenis === s.Jenis_Awal);
  const pctTerpilahBenar =
    manualVerified.length > 0
      ? Math.round((manualAccurate.length / manualVerified.length) * 100)
      : 92;

  const classMap = new Map<
    string,
    {
      kelas: string;
      jenjang: string;
      organik: number;
      anorganik: number;
      residu: number;
      total: number;
      poin: number;
    }
  >();

  for (const c of classes) {
    if (jenjangFilter !== 'ALL' && c.Jenjang !== jenjangFilter) continue;
    if (kelasFilter !== 'ALL' && c.Kelas !== kelasFilter) continue;
    classMap.set(c.Kelas, {
      kelas: c.Kelas,
      jenjang: c.Jenjang,
      organik: 0,
      anorganik: 0,
      residu: 0,
      total: 0,
      poin: 0,
    });
  }

  for (const s of filteredVerified) {
    const row = classMap.get(s.Kelas) || {
      kelas: s.Kelas,
      jenjang: s.Jenjang,
      organik: 0,
      anorganik: 0,
      residu: 0,
      total: 0,
      poin: 0,
    };
    if (s.Jenis === 'Organik') row.organik += s.Berat_kg;
    else if (s.Jenis === 'Anorganik') row.anorganik += s.Berat_kg;
    else if (s.Jenis === 'Residu') row.residu += s.Berat_kg;
    row.total += s.Berat_kg;
    row.poin += s.Poin;
    classMap.set(s.Kelas, row);
  }

  const classRows = Array.from(classMap.values()).sort((a, b) => b.total - a.total);
  const maxClassKg = Math.max(1, ...classRows.map((c) => c.total));

  const filterLabel = `${
    periode === 'hari'
      ? 'Hari Ini'
      : periode === 'minggu'
      ? 'Minggu Ini'
      : periode === 'bulan'
      ? 'Bulan Ini'
      : 'Semua Periode'
  } · Jenjang ${jenjangFilter === 'ALL' ? 'Semua' : jenjangFilter}`;

  const handleExportCSV = () => {
    const header = 'ID,Tanggal,Penyetor,Kelas,Jenjang,Jenis,Jenis_Awal,Berat_kg,Poin,Sumber,Station_ID\n';
    const body = filteredVerified
      .map(
        (s) =>
          `${s.ID},${s.Tanggal},"${s.Nama_Penyetor}",${s.Kelas},${s.Jenjang},${s.Jenis},${s.Jenis_Awal},${s.Berat_kg},${s.Poin},${s.Sumber},${s.Station_ID || ''}`
      )
      .join('\n');
    const blob = new Blob([header + body], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Rekap_Setoran_${jenjangFilter}_${periode}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadMonthlyPDF = () => {
    if (!monthlyReport) return;
    generateMonthlyReportPDF(monthlyReport, filterLabel, classRows);
  };

  const avgQuizPct =
    kuisHasil.length > 0
      ? Math.round(
          (kuisHasil.reduce((sum, k) => sum + k.Skor / k.Total, 0) / kuisHasil.length) * 100
        )
      : 0;

  return (
    <div className="space-y-6">
      {/* Header + Primary Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Dashboard Analitik & Laporan Berkelanjutan
          </h2>
          <p className="text-sm text-slate-600">
            Pemantauan pemilahan real-time, evaluasi PjBL per kelas, dan laporan efisiensi pengelolaan limbah bulanan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Ekspor CSV</span>
          </button>
          {monthlyReport && (
            <button
              type="button"
              onClick={() => downloadStandaloneHTMLSnapshot(db, monthlyReport)}
              className="min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <FileCode2 className="w-4 h-4" />
              <span>Ekspor HTML</span>
            </button>
          )}
          <button
            type="button"
            disabled={!monthlyReport}
            onClick={handleDownloadMonthlyPDF}
            className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Unduh Laporan Bulanan (PDF)</span>
          </button>
        </div>
      </div>

      {/* Mode Switcher + Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setSubTab('rekap')}
            className={`min-h-[36px] px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'rekap' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            Rekap Real-Time & Kelas
          </button>
          <button
            type="button"
            onClick={() => setSubTab('bulanan')}
            className={`min-h-[36px] px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'bulanan' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            Laporan Analisis Data Bulanan
          </button>
          <button
            type="button"
            onClick={() => setSubTab('rfid')}
            className={`min-h-[36px] px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'rfid' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            Kartu RFID Siswa
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          <select
            aria-label="Filter Periode"
            value={periode}
            onChange={(e) => setPeriode(e.target.value as typeof periode)}
            className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium"
          >
            <option value="hari">Hari Ini</option>
            <option value="minggu">Minggu Ini</option>
            <option value="bulan">Bulan Ini</option>
            <option value="semua">Semua Waktu (6 Bulan)</option>
          </select>

          <select
            aria-label="Filter Jenjang"
            value={jenjangFilter}
            onChange={(e) => {
              setJenjangFilter(e.target.value as Jenjang | 'ALL');
              setKelasFilter('ALL');
            }}
            className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium"
          >
            <option value="ALL">Semua Jenjang</option>
            <option value="TK">TK</option>
            <option value="SD">SD</option>
            <option value="SMP">SMP</option>
            <option value="SMA/SMK">SMA/SMK</option>
          </select>

          <select
            aria-label="Filter Kelas"
            value={kelasFilter}
            onChange={(e) => setKelasFilter(e.target.value)}
            className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium"
          >
            <option value="ALL">Semua Kelas</option>
            {classes
              .filter((c) => jenjangFilter === 'ALL' || c.Jenjang === jenjangFilter)
              .map((c) => (
                <option key={c.Kelas} value={c.Kelas}>
                  {c.Kelas}
                </option>
              ))}
          </select>

          <select
            aria-label="Filter Station"
            value={stationFilter}
            onChange={(e) => setStationFilter(e.target.value)}
            className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-slate-800 font-medium"
          >
            <option value="ALL">Semua Station</option>
            {stations.map((st) => (
              <option key={st.Station_ID} value={st.Station_ID}>
                {st.Station_ID}
              </option>
            ))}
          </select>
        </div>
      </div>

      {subTab === 'rekap' ? (
        <>
          {/* KPI Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <span className="text-xs text-slate-500 block">Total Berat Terverifikasi</span>
              <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-slate-900">
                {totalKg.toFixed(2)} kg
              </span>
              <span className="mt-1 block text-xs text-slate-500">{filterLabel}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <span className="text-xs text-slate-500 block">Jumlah Setoran Valid</span>
              <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-slate-900">
                {totalCount}
              </span>
              <span className="mt-1 block text-xs text-slate-500">
                IoT + Manual terverifikasi
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <span className="text-xs text-slate-500 block">Terpilah Benar (Manual)</span>
              <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-emerald-700">
                {pctTerpilahBenar}%
              </span>
              <span className="mt-1 block text-xs text-slate-500">
                Target PRD G2: &ge; 85%
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <span className="text-xs text-slate-500 block">Rata-rata Skor Kuis</span>
              <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-slate-900">
                {avgQuizPct}%
              </span>
              <span className="mt-1 block text-xs text-slate-500">
                Dari {kuisHasil.length} sesi kuis tercatat
              </span>
            </div>
          </div>

          {/* Stacked Bar Chart per Class (FR-DB-03) */}
          <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5">
              <div>
                <h3 className="font-display font-semibold text-slate-900">
                  Grafik Batang Bertumpuk Berat Sampah per Kelas
                </h3>
                <p className="text-xs text-slate-500">
                  Total seluruh kelas sama dengan KPI Total ({totalKg.toFixed(2)} kg · AC-DB-01).
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs text-slate-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-emerald-600 inline-block" />
                  Kompos
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-amber-500 inline-block" />
                  Daur Ulang
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-slate-500 inline-block" />
                  Residu
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {classRows.map((c) => {
                const wOrg = (c.organik / maxClassKg) * 100;
                const wAnorg = (c.anorganik / maxClassKg) * 100;
                const wRes = (c.residu / maxClassKg) * 100;
                return (
                  <div key={c.kelas} className="grid grid-cols-12 items-center gap-3 text-xs">
                    <div className="col-span-4 sm:col-span-3 font-medium text-slate-800 truncate">
                      {c.kelas}{' '}
                      <span className="text-slate-400 font-normal">({c.jenjang})</span>
                    </div>
                    <div className="col-span-5 sm:col-span-7 h-5 bg-slate-100 rounded-md overflow-hidden flex">
                      <div
                        style={{ width: `${wOrg}%` }}
                        className="bg-emerald-600 h-full"
                        title={`Kompos: ${c.organik.toFixed(2)} kg`}
                      />
                      <div
                        style={{ width: `${wAnorg}%` }}
                        className="bg-amber-500 h-full"
                        title={`Daur Ulang: ${c.anorganik.toFixed(2)} kg`}
                      />
                      <div
                        style={{ width: `${wRes}%` }}
                        className="bg-slate-500 h-full"
                        title={`Residu: ${c.residu.toFixed(2)} kg`}
                      />
                    </div>
                    <div className="col-span-3 sm:col-span-2 text-right font-mono tabular-nums font-semibold text-slate-800">
                      {c.total.toFixed(2)} kg
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </>
      ) : subTab === 'bulanan' ? (
        /* Laporan Analisis Data Bulanan Berkelanjutan */
        monthlyReport && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Analisis Efisiensi Sistem Pengelolaan Limbah · {monthlyReport.periodeBulan}
                </h3>
                <p className="text-xs text-slate-500">
                  Pilih bulan untuk meninjau rasio pengalihan limbah dari TPA (Diversion Rate) dan tren berkelanjutan.
                </p>
              </div>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="min-h-[38px] px-3 rounded-lg border border-slate-300 bg-white text-xs font-medium"
              >
                <option value="">Bulan Terbaru</option>
                {monthlyReport.trenBulanan.map((b) => (
                  <option key={b.bulan} value={b.bulan}>
                    {b.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Sustainability KPI Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <span className="text-xs text-slate-500 block">Diversion Rate (Non-TPA)</span>
                <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-emerald-700">
                  {monthlyReport.ringkasan.diversion_rate}%
                </span>
                <span className="mt-1 block text-xs text-slate-500">
                  Kompos + Daur Ulang dari total limbah
                </span>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <span className="text-xs text-slate-500 block">Perubahan Limbah Residu</span>
                <div className="mt-2 flex items-center gap-1.5 font-mono tabular-nums text-2xl font-bold text-slate-900">
                  {monthlyReport.ringkasan.perubahan_residu_pct <= 0 ? (
                    <TrendingDown className="w-5 h-5 text-emerald-700" />
                  ) : (
                    <TrendingUp className="w-5 h-5 text-red-600" />
                  )}
                  <span>
                    {monthlyReport.ringkasan.perubahan_residu_pct > 0 ? '+' : ''}
                    {monthlyReport.ringkasan.perubahan_residu_pct}%
                  </span>
                </div>
                <span className="mt-1 block text-xs text-slate-500">
                  Dibanding bulan sebelumnya
                </span>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <span className="text-xs text-slate-500 block">Adopsi Station IoT (G3)</span>
                <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-slate-900">
                  {monthlyReport.ringkasan.iot_adoption}%
                </span>
                <span className="mt-1 block text-xs text-slate-500">
                  Target PRD: &ge; 70% setoran otomatis
                </span>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <span className="text-xs text-slate-500 block">Respon Tong Penuh (G4)</span>
                <span className="mt-2 block font-mono tabular-nums text-2xl font-bold text-slate-900">
                  {monthlyReport.ringkasan.avg_response_hours} jam
                </span>
                <span className="mt-1 block text-xs text-slate-500">
                  Target SLA: &le; 1 hari kerja
                </span>
              </div>
            </div>

            {/* 6-Month Visual Trend Chart */}
            <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-display font-semibold text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-700" />
                  <span>Tren Bulanan Pengelolaan Limbah (6 Bulan)</span>
                </h4>
                <span className="text-xs text-slate-500">Satuan: kg &amp; Diversion %</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 items-end pt-4">
                {monthlyReport.trenBulanan.map((b) => {
                  const maxMonthKg = Math.max(
                    1,
                    ...monthlyReport.trenBulanan.map((x) => x.total_kg)
                  );
                  const hTotal = Math.max(20, Math.round((b.total_kg / maxMonthKg) * 120));
                  const hOrg = b.total_kg > 0 ? Math.round((b.organik_kg / b.total_kg) * hTotal) : 0;
                  const hAnorg =
                    b.total_kg > 0 ? Math.round((b.anorganik_kg / b.total_kg) * hTotal) : 0;
                  const hRes = Math.max(2, hTotal - hOrg - hAnorg);
                  return (
                    <div key={b.bulan} className="flex flex-col items-center">
                      <div className="text-xs font-mono tabular-nums font-semibold text-emerald-700 mb-1">
                        {b.diversion_rate}% div
                      </div>
                      <div className="w-12 flex flex-col justify-end rounded-t-md overflow-hidden bg-slate-100 h-[124px]">
                        <div style={{ height: `${hRes}px` }} className="bg-slate-500 w-full" />
                        <div style={{ height: `${hAnorg}px` }} className="bg-amber-500 w-full" />
                        <div style={{ height: `${hOrg}px` }} className="bg-emerald-600 w-full" />
                      </div>
                      <div className="mt-2 text-xs font-semibold text-slate-900">{b.label}</div>
                      <div className="text-[11px] font-mono tabular-nums text-slate-500">
                        {b.total_kg.toFixed(1)} kg
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Cross-Jenjang Efficiency Ratio Table (FR-JJ-13) */}
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200">
                <h4 className="font-display font-semibold text-slate-900">
                  Perbandingan Efisiensi Lintas Jenjang (Rasio per Siswa · FR-JJ-13)
                </h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                      <th className="py-3 px-4">Jenjang</th>
                      <th className="py-3 px-4 text-right">Siswa</th>
                      <th className="py-3 px-4 text-right">Total (kg)</th>
                      <th className="py-3 px-4 text-right">Rasio kg/Siswa</th>
                      <th className="py-3 px-4 text-right">Kelas Aktif</th>
                      <th className="py-3 px-4 text-right">Diversion Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {monthlyReport.perJenjang.map((row) => (
                      <tr key={row.jenjang} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-semibold text-slate-900">{row.jenjang}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600">
                          {row.jumlah_siswa}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900">
                          {row.total_kg.toFixed(2)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-emerald-700">
                          {row.kg_per_siswa.toFixed(2)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                          {row.kelas_aktif_pct}%
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                          {row.diversion_rate}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Rule-Based Automated Insights (FR-DB-04) */}
            <section className="space-y-3">
              <h4 className="font-display font-semibold text-slate-900">
                Insight Otomatis & Rekomendasi PjBL
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {monthlyReport.insightOtomatis.map((ins) => (
                  <div
                    key={ins.id}
                    className={`p-4 rounded-xl border ${
                      ins.tingkat === 'warning'
                        ? 'bg-amber-50 border-amber-200'
                        : ins.tingkat === 'success'
                        ? 'bg-emerald-50 border-emerald-200'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      {ins.tingkat === 'warning' ? (
                        <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                      ) : ins.tingkat === 'success' ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                      ) : (
                        <Info className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <h5 className="font-semibold text-sm text-slate-900">{ins.judul}</h5>
                        <p className="mt-1 text-xs text-slate-700">{ins.deskripsi}</p>
                        <p className="mt-2 text-xs font-medium text-slate-800">
                          {ins.rekomendasi}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )
      ) : null}

      {subTab === 'rfid' && (
        <section className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-bold text-slate-900 text-lg">
                Daftar Kartu RFID Per Siswa
              </h3>
              <p className="text-xs text-slate-600">
                Menampilkan kartu RFID pribadi atau Kartu Kelas kolektif per siswa sesuai filter Jenjang dan Kelas di atas.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {
                db.Pengguna.filter(
                  (u) =>
                    u.Peran === 'Siswa' &&
                    (jenjangFilter === 'ALL' || u.Jenjang === jenjangFilter) &&
                    (kelasFilter === 'ALL' || u.Kelas === kelasFilter)
                ).length
              }{' '}
              siswa
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {db.Pengguna.filter(
              (u) =>
                u.Peran === 'Siswa' &&
                (jenjangFilter === 'ALL' || u.Jenjang === jenjangFilter) &&
                (kelasFilter === 'ALL' || u.Kelas === kelasFilter)
            ).map((stu) => (
              <StudentRfidCard
                key={stu.ID_Pengguna}
                student={stu}
                classCardUid={classes.find((c) => c.Kelas === stu.Kelas)?.Kartu_Kelas}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
