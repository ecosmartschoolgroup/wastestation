import React from 'react';
import {
  Award,
  PlusCircle,
  BookOpen,
  Leaf,
  Recycle,
  Trash2,
  Cpu,
  UserCheck,
  CreditCard,
  ShieldCheck,
  LogOut,
  CheckCircle2,
  Clock,
  XCircle,
} from 'lucide-react';
import type { JenisSampah, Kelas, Pengguna, Setoran } from '../types.ts';
import { formatJakartaDateTime, getJenisLabel } from '../utils/wasteStyles.ts';
import { StudentRfidCard } from './StudentRfidCard.tsx';

interface StudentHomeViewProps {
  user: Pengguna;
  setoran: Setoran[];
  classes: Kelas[];
  jenisSampah: JenisSampah[];
  activeTab: 'beranda' | 'peringkat' | 'akun';
  onGoSetor: () => void;
  onGoPanduan: () => void;
  onGrantConsent: (idPengguna: string) => void;
  onLogout: () => void;
}

export const StudentHomeView: React.FC<StudentHomeViewProps> = ({
  user,
  setoran,
  classes,
  jenisSampah,
  activeTab,
  onGoSetor,
  onGoPanduan,
  onGrantConsent,
  onLogout,
}) => {
  const now = Date.now();
  const oneWeekMs = 7 * 86400_000;

  // Weekly verified deposits
  const weeklyVerified = setoran.filter(
    (s) => s.Status === 'Terverifikasi' && now - new Date(s.Tanggal).getTime() <= oneWeekMs
  );

  // Class scores within the SAME jenjang (BR-08 / FR-JJ-09)
  const sameJenjangClasses = classes.filter((c) => {
    if (c.Jenjang !== user.Jenjang) return false;
    // SD 1-3 has no ranking; SD 4-6 ranks together
    if (user.Jenjang === 'SD') return Number(c.Tingkat) >= 4;
    return true;
  });

  const classScores = sameJenjangClasses
    .map((c) => {
      const clsDeposits = weeklyVerified.filter((s) => s.Kelas === c.Kelas);
      const poin = clsDeposits.reduce((sum, s) => sum + s.Poin, 0);
      const totalKg = clsDeposits.reduce((sum, s) => sum + s.Berat_kg, 0);
      return {
        kelas: c.Kelas,
        wali: c.Wali_Kelas,
        poin,
        totalKg: Number(totalKg.toFixed(2)),
      };
    })
    .sort((a, b) => b.poin - a.poin);

  const myRankIdx = classScores.findIndex((c) => c.kelas === user.Kelas);
  const myClassScore = classScores[myRankIdx]?.poin ?? 0;

  // My class weekly kg breakdown
  const myClassWeekly = weeklyVerified.filter((s) => s.Kelas === user.Kelas);
  const kgOrganik = myClassWeekly
    .filter((s) => s.Jenis === 'Organik')
    .reduce((a, b) => a + b.Berat_kg, 0);
  const kgAnorganik = myClassWeekly
    .filter((s) => s.Jenis === 'Anorganik')
    .reduce((a, b) => a + b.Berat_kg, 0);
  const kgResidu = myClassWeekly
    .filter((s) => s.Jenis === 'Residu')
    .reduce((a, b) => a + b.Berat_kg, 0);

  const myDeposits = setoran.filter(
    (s) => s.ID_Pengguna === user.ID_Pengguna || (s.Email && s.Email === user.Email)
  );

  if (activeTab === 'peringkat') {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
              Peringkat Kelas Jenjang {user.Jenjang}
            </h2>
            <p className="text-sm text-slate-600">
              Peringkat hanya membandingkan kelas di jenjang yang sama (Aturan BR-08). Hanya setoran Terverifikasi yang dihitung.
            </p>
          </div>
          <span className="text-xs font-medium text-slate-500">
            Periode: 7 hari terakhir
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4 w-16">Posisi</th>
                  <th className="py-3 px-4">Kelas</th>
                  <th className="py-3 px-4 hidden sm:table-cell">Wali Kelas</th>
                  <th className="py-3 px-4 text-right">Berat (kg)</th>
                  <th className="py-3 px-4 text-right">Poin Minggu Ini</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {classScores.map((row, idx) => {
                  const isMine = row.kelas === user.Kelas;
                  return (
                    <tr
                      key={row.kelas}
                      className={isMine ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'}
                    >
                      <td className="py-3.5 px-4 tabular-nums font-mono text-slate-700">
                        #{idx + 1}
                      </td>
                      <td className="py-3.5 px-4 text-slate-900">
                        {row.kelas}
                        {isMine && (
                          <span className="ml-2 text-xs text-emerald-700 font-medium">
                            (Kelas Saya)
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 hidden sm:table-cell">
                        {row.wali}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700">
                        {row.totalKg.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-emerald-700 font-bold">
                        {row.poin}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'akun') {
    return (
      <div className="max-w-2xl space-y-6">
        <div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
            Profil &amp; Kartu RFID Siswa
          </h2>
          <p className="text-sm text-slate-600">
            Kartu pelajar RFID untuk Smart Waste Station, status akun sekolah, dan persetujuan privasi.
          </p>
        </div>

        <StudentRfidCard
          student={user}
          classCardUid={classes.find((c) => c.Kelas === user.Kelas)?.Kartu_Kelas}
        />

        <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-100">
          <div className="p-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                {user.Nama.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">{user.Nama}</h3>
                <p className="text-xs text-slate-500">
                  {user.ID_Pengguna} · {user.Email || 'Tanpa Email'}
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-emerald-800">
              {user.Peran} · {user.Jenjang}
            </span>
          </div>

          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-xs text-slate-500 block">Kelas Aktif</span>
              <span className="font-medium text-slate-900">{user.Kelas || '-'}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Status Kartu RFID</span>
              <span className="font-medium text-slate-900 flex items-center gap-1.5 mt-0.5">
                <CreditCard className="w-4 h-4 text-slate-500" />
                {user.Kartu_RFID ? (
                  <span className="font-mono text-emerald-700">
                    Terdaftar ({user.Kartu_RFID})
                  </span>
                ) : (
                  <span className="text-amber-700">Belum Terdaftar (Hubungi Admin)</span>
                )}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Persetujuan Orang Tua (UU PDP)</span>
              {user.Persetujuan_Ortu ? (
                <span className="font-medium text-emerald-700 flex items-center gap-1.5 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                  Aktif sejak {user.Persetujuan_Ortu}
                </span>
              ) : (
                <div className="mt-1 space-y-2">
                  <span className="text-xs font-medium text-red-700 block">
                    Belum tercatat — setoran terkunci (BR-14)
                  </span>
                  <button
                    type="button"
                    onClick={() => onGrantConsent(user.ID_Pengguna)}
                    className="min-h-[40px] px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800 cursor-pointer"
                  >
                    Catat Persetujuan Orang Tua
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="p-5 flex justify-end">
            <button
              type="button"
              onClick={onLogout}
              className="min-h-[44px] px-4 py-2 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar dari Akun</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Greeting + Primary CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Halo, {user.Nama.split(' ')[0]} · Kelas {user.Kelas}
          </h2>
          <p className="text-sm text-slate-600">
            Jenjang {user.Jenjang} · Kartu RFID: {user.Kartu_RFID || 'Belum terdaftar'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onGoPanduan}
            className="min-h-[44px] px-4 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>Bingung Memilah?</span>
          </button>
          <button
            type="button"
            onClick={onGoSetor}
            className="min-h-[44px] px-5 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Setor Sampah</span>
          </button>
        </div>
      </div>

      {!user.Persetujuan_Ortu && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-sm text-amber-900">
            <strong>Persetujuan Orang Tua Belum Aktif (BR-14):</strong> Akun siswa memerlukan persetujuan wali sesuai UU PDP sebelum dapat menyetor di station atau aplikasi.
          </div>
          <button
            type="button"
            onClick={() => onGrantConsent(user.ID_Pengguna)}
            className="min-h-[40px] px-4 py-2 rounded-lg bg-amber-700 text-white text-xs font-semibold hover:bg-amber-800 shrink-0 cursor-pointer"
          >
            Simulasi Konfirmasi Wali
          </button>
        </div>
      )}

      {/* Class Score + Weekly kg Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-emerald-700 text-white rounded-xl p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-100 text-xs font-medium">
            <span>Poin Kelas Minggu Ini</span>
            <Award className="w-4 h-4" />
          </div>
          <div className="mt-3">
            <div className="font-mono tabular-nums text-3xl font-bold">
              {myClassScore} <span className="text-base font-normal">poin</span>
            </div>
            <div className="mt-1 text-xs text-emerald-100">
              Peringkat #{myRankIdx >= 0 ? myRankIdx + 1 : '-'} dari {classScores.length} kelas {user.Jenjang}
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs font-medium text-emerald-800">
            <span>{getJenisLabel('Organik', jenisSampah)}</span>
            <Leaf className="w-4 h-4" />
          </div>
          <div className="mt-3 font-mono tabular-nums text-2xl font-bold text-slate-900">
            {kgOrganik.toFixed(2)} kg
          </div>
          <div className="mt-1 text-xs text-slate-500">Tong Hijau · Minggu ini</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs font-medium text-amber-800">
            <span>{getJenisLabel('Anorganik', jenisSampah)}</span>
            <Recycle className="w-4 h-4" />
          </div>
          <div className="mt-3 font-mono tabular-nums text-2xl font-bold text-slate-900">
            {kgAnorganik.toFixed(2)} kg
          </div>
          <div className="mt-1 text-xs text-slate-500">Tong Kuning · Minggu ini</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-700">
            <span>{getJenisLabel('Residu', jenisSampah)}</span>
            <Trash2 className="w-4 h-4" />
          </div>
          <div className="mt-3 font-mono tabular-nums text-2xl font-bold text-slate-900">
            {kgResidu.toFixed(2)} kg
          </div>
          <div className="mt-1 text-xs text-slate-500">Tong Abu-abu · Minggu ini</div>
        </div>
      </div>

      {/* Tips Pilah & Kartu RFID Saya */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex items-start gap-3">
          <UserCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
          <div className="text-sm text-slate-700">
            <span className="font-semibold text-slate-900">Tips Pilah Hari Ini: </span>
            Kemasan kopi sachet berlapis foil dan wadah styrofoam tidak bisa didaur ulang di bank sampah sekolah—masukkan ke kompartemen <strong>Residu (Abu-abu)</strong> agar tidak mencemari sampah Daur Ulang.
          </div>
        </div>
        <div className="lg:col-span-5">
          <StudentRfidCard
            student={user}
            classCardUid={classes.find((c) => c.Kelas === user.Kelas)?.Kartu_Kelas}
            compact
          />
        </div>
      </div>

      {/* Recent Deposits (FR-BR-05 & FR-BR-10) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-display font-semibold text-slate-900">
            Setoran Terakhir Saya
          </h3>
          <span className="text-xs text-slate-500 tabular-nums">
            {myDeposits.length} catatan
          </span>
        </div>

        {myDeposits.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm text-slate-600 mb-4">
              Belum ada setoran tercatat atas namamu. Ayo mulai memilah sampah hari ini!
            </p>
            <button
              type="button"
              onClick={onGoSetor}
              className="min-h-[44px] px-4 py-2 rounded-lg bg-emerald-700 text-white text-sm font-semibold hover:bg-emerald-800 cursor-pointer"
            >
              Buat Setoran Pertama
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {myDeposits.slice(0, 8).map((item) => (
              <div
                key={item.ID}
                className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                    <span>{getJenisLabel(item.Jenis, jenisSampah)}</span>
                    {item.Subjenis && (
                      <span className="text-xs font-normal text-slate-500">
                        ({item.Subjenis})
                      </span>
                    )}
                    <span className="text-xs font-normal text-slate-400">·</span>
                    <span className="font-mono tabular-nums text-slate-700">
                      {item.Jumlah_item ? `${item.Jumlah_item} item` : `${item.Berat_kg.toFixed(2)} kg`}
                    </span>
                  </div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      {item.Sumber === 'IoT' && <Cpu className="w-3.5 h-3.5 text-emerald-700" />}
                      {item.Sumber === 'IoT' ? `Waste Station (${item.Station_ID})` : 'Setor Manual'}
                    </span>
                    <span>·</span>
                    <span>{formatJakartaDateTime(item.Tanggal)}</span>
                  </div>
                  {item.Status === 'Ditolak' && item.Alasan_Tolak && (
                    <p className="mt-1 text-xs text-red-700">
                      Alasan tolak: {item.Alasan_Tolak}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0 text-xs font-semibold">
                  {item.Status === 'Terverifikasi' && (
                    <span className="flex items-center gap-1 text-emerald-700 font-mono tabular-nums">
                      <CheckCircle2 className="w-4 h-4" />+{item.Poin} poin
                    </span>
                  )}
                  {item.Status === 'Menunggu' && (
                    <span className="flex items-center gap-1 text-amber-700">
                      <Clock className="w-4 h-4" />
                      Menunggu Verifikasi
                    </span>
                  )}
                  {item.Status === 'Ditolak' && (
                    <span className="flex items-center gap-1 text-red-700">
                      <XCircle className="w-4 h-4" />
                      Ditolak
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
