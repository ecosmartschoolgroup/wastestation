import React, { useState } from 'react';
import {
  Leaf,
  Recycle,
  Trash2,
  ShieldCheck,
  ArrowRight,
  MonitorSmartphone,
  Sparkles,
  Users,
  CreditCard,
  School,
} from 'lucide-react';
import type { Jenjang, Kelas, Pengguna } from '../types.ts';

interface LoginViewProps {
  users: Pengguna[];
  classes: Kelas[];
  selectedJenjang: Jenjang | 'ALL';
  onChangeJenjang: (jenjang: Jenjang | 'ALL') => void;
  onLoginSuccess: (user: Pengguna) => void;
  onOpenClassMode: (kelas: Kelas) => void;
  onOpenTapRfid: () => void;
}

const LEVEL_OPTIONS: {
  value: Jenjang | 'ALL';
  label: string;
  desc: string;
}[] = [
  {
    value: 'ALL',
    label: 'Semua Jenjang',
    desc: 'Pantau dan akses seluruh unit TK, SD, SMP, serta SMA/SMK YPIK PAM JAYA.',
  },
  {
    value: 'TK',
    label: 'TK',
    desc: 'Mode visual ramah anak tanpa angka poin · Kartu Kelas kolektif & Checklist Observasi Guru.',
  },
  {
    value: 'SD',
    label: 'SD',
    desc: 'Kelas 1–3 memakai Mode Kelas + PIN gambar; Kelas 4–6 memakai akun email & RFID pribadi.',
  },
  {
    value: 'SMP',
    label: 'SMP',
    desc: 'Akun email sekolah & kartu RFID pelajar pribadi · termasuk jalur baterai/elektronik.',
  },
  {
    value: 'SMA/SMK',
    label: 'SMA/SMK',
    desc: 'Akun email sekolah, kartu RFID pribadi, peran Eco Ranger, & analitik PjBL lengkap.',
  },
];

export const LoginView: React.FC<LoginViewProps> = ({
  users,
  classes,
  selectedJenjang,
  onChangeJenjang,
  onLoginSuccess,
  onOpenClassMode,
  onOpenTapRfid,
}) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showAccounts, setShowAccounts] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.pesan || 'Login gagal.');
        return;
      }
      onLoginSuccess(data.user);
    } catch {
      setError('Gagal terhubung ke server sekolah.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (targetEmail: string) => {
    setEmail(targetEmail);
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail }),
      });
      const data = await res.json();
      if (data.ok) onLoginSuccess(data.user);
      else setError(data.pesan || 'Gagal masuk.');
    } catch {
      setError('Gagal terhubung ke server.');
    } finally {
      setLoading(false);
    }
  };

  const tkSdClasses = classes.filter(
    (c) =>
      (c.Jenjang === 'TK' || (c.Jenjang === 'SD' && Number(c.Tingkat) <= 3)) &&
      (selectedJenjang === 'ALL' || c.Jenjang === selectedJenjang)
  );

  const emailUsers = users.filter(
    (u) =>
      Boolean(u.Email) &&
      (selectedJenjang === 'ALL' ||
        u.Jenjang === selectedJenjang ||
        u.Peran === 'Admin' ||
        u.Peran === 'Petugas')
  );

  const activeLevelInfo =
    LEVEL_OPTIONS.find((o) => o.value === selectedJenjang) || LEVEL_OPTIONS[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      {/* Top concise bar */}
      <header className="w-full border-b border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center">
              <Leaf className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-slate-900 text-lg tracking-tight whitespace-nowrap">
              Eco Smart School
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenTapRfid}
              className="min-h-[42px] px-4 py-2 text-sm font-semibold bg-emerald-700 text-white rounded-lg hover:bg-emerald-800 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer"
            >
              <CreditCard className="w-4 h-4 shrink-0" />
              <span>Layar Tap Kartu RFID</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main 2-column responsive layout */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 lg:py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Left: School identity, Level Selector & Overview */}
        <section className="lg:col-span-7 flex flex-col justify-between bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6">
          <div>
            <p className="text-sm font-medium text-emerald-700 mb-2">
              YPIK PAM JAYA · TK · SD · SMP · SMA/SMK
            </p>
            <h1 className="font-display text-2xl sm:text-4xl font-bold text-slate-900 tracking-tight leading-tight text-balance">
              Pemilahan Sampah Cerdas Terintegrasi Real-Time
            </h1>
            <p className="mt-3 text-slate-600 text-sm sm:text-base leading-relaxed max-w-2xl">
              Sistem pemantauan pemilahan sampah lintas jenjang yang menghubungkan Smart Waste Station berbasis RFID, verifikasi Eco Ranger, notifikasi otomatis tong penuh, dan laporan analisis berkelanjutan bulanan.
            </p>

            {/* School Level Selector */}
            <div className="mt-6 p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                  <School className="w-4 h-4 text-emerald-700" />
                  <span>Pilih Tingkat / Level Sekolah</span>
                </label>
                <span className="text-xs font-semibold text-emerald-700">
                  Aktif: {activeLevelInfo.label}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {LEVEL_OPTIONS.map((opt) => {
                  const active = selectedJenjang === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => onChangeJenjang(opt.value)}
                      className={`min-h-[42px] px-3 py-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                        active
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-500 hover:text-emerald-800'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                {activeLevelInfo.desc}
              </p>
            </div>

            {/* 3 Waste Compartment overview */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                <div className="flex items-center gap-2 text-emerald-800 font-semibold text-sm">
                  <Leaf className="w-4 h-4 shrink-0" />
                  <span>Kompos</span>
                </div>
                <p className="mt-1 text-xs text-emerald-900/80">
                  Tong Hijau · Sisa makanan, daun, kulit buah
                </p>
              </div>
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
                <div className="flex items-center gap-2 text-amber-800 font-semibold text-sm">
                  <Recycle className="w-4 h-4 shrink-0" />
                  <span>Daur Ulang</span>
                </div>
                <p className="mt-1 text-xs text-amber-900/80">
                  Tong Kuning · Botol plastik, kertas, kardus, kaleng
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-100 border border-slate-300">
                <div className="flex items-center gap-2 text-slate-800 font-semibold text-sm">
                  <Trash2 className="w-4 h-4 shrink-0" />
                  <span>Residu</span>
                </div>
                <p className="mt-1 text-xs text-slate-700">
                  Tong Abu-abu · Tisu kotor, styrofoam, sachet
                </p>
              </div>
            </div>
          </div>

          <div className="pt-5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <MonitorSmartphone className="w-4 h-4 text-slate-500 shrink-0" />
              <span>Mendukung Laptop, PC, Tablet Kiosk, iOS Safari &amp; Android Chrome</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Kepatuhan Privasi Anak &amp; UU PDP No. 27/2022</span>
            </div>
          </div>
        </section>

        {/* Right: Tap RFID Card, Login card & Class Mode */}
        <section className="lg:col-span-5 flex flex-col gap-5">
          {/* Quick Tap RFID Kiosk Launcher */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                <CreditCard className="w-4 h-4" />
                <span>Smart Waste Station · {activeLevelInfo.label}</span>
              </div>
              <h2 className="font-display text-lg font-bold">
                Layar Tap Kartu RFID
              </h2>
              <p className="text-xs text-slate-300">
                Tempelkan kartu RFID siswa atau Kartu Kelas langsung tanpa perlu login email.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenTapRfid}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shrink-0 cursor-pointer whitespace-nowrap"
            >
              <span>Buka Layar Tap</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* School Account Login */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-7">
            <h2 className="font-display text-xl font-bold text-slate-900">
              Masuk dengan Akun Sekolah
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Peran (Siswa, Eco Ranger, Guru, atau Admin) dideteksi otomatis dari email terdaftar.
            </p>

            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <label
                  htmlFor="school-email"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Email Google Sekolah
                </label>
                <input
                  id="school-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nama@ypikpamjaya.sch.id"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg border border-slate-300 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
                />
              </div>

              {error && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800"
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>{loading ? 'Memeriksa akun...' : 'Masuk Aplikasi'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Quick Login Directory filtered by chosen School Level */}
            <div className="mt-5 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowAccounts((v) => !v)}
                className="w-full min-h-[40px] flex items-center justify-between text-xs font-semibold text-slate-700 hover:text-emerald-700 cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Users className="w-4 h-4" />
                  <span>
                    Pilih Akun {selectedJenjang === 'ALL' ? 'Terdaftar' : `Jenjang ${selectedJenjang}`}
                  </span>
                </span>
                <span>{showAccounts ? 'Sembunyikan' : 'Tampilkan'}</span>
              </button>

              {showAccounts && (
                <div className="mt-3 grid grid-cols-1 gap-1.5 max-h-52 overflow-y-auto pr-1">
                  {emailUsers.map((u) => (
                    <button
                      key={u.ID_Pengguna}
                      type="button"
                      onClick={() => handleQuickLogin(u.Email!)}
                      className="text-left px-3 py-2 rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-900 truncate">
                          {u.Nama}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {u.Email}
                        </div>
                      </div>
                      <span className="text-[11px] font-medium text-emerald-800 shrink-0">
                        {u.Peran === 'Petugas' ? 'Eco Ranger' : u.Peran} · {u.Jenjang}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Mode Kelas TK & SD 1-3 Launcher (FR-JJ-04) */}
          {tkSdClasses.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Mode Kelas Tablet Guru (TK &amp; SD Kelas 1–3)</span>
              </div>
              <p className="mt-1 text-xs text-slate-600">
                Siswa TK dan SD awal tidak memerlukan email sekolah. Pilih kelas untuk membuka mode visual ramah anak.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {tkSdClasses.map((cls) => (
                  <button
                    key={cls.Kelas}
                    type="button"
                    onClick={() => onOpenClassMode(cls)}
                    className="min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-200 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-400 text-xs font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Buka {cls.Kelas} ({cls.Jenjang})
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-4 px-4 sm:px-6 text-center text-xs text-slate-500">
        Eco Smart School · YPIK PAM JAYA · Tingkat TK, SD, SMP &amp; SMA/SMK · Integrasi RFID &amp; Analitik Berkelanjutan
      </footer>
    </div>
  );
};
