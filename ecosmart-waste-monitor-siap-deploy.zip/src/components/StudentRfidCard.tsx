import React from 'react';
import { Leaf, Wifi, ShieldCheck, AlertCircle, CreditCard } from 'lucide-react';
import type { Pengguna } from '../types.ts';

interface StudentRfidCardProps {
  student: Pengguna;
  classCardUid?: string;
  compact?: boolean;
  onAssignClick?: (student: Pengguna) => void;
}

export const StudentRfidCard: React.FC<StudentRfidCardProps> = ({
  student,
  classCardUid,
  compact = false,
  onAssignClick,
}) => {
  const usesClassCard =
    student.Jenjang === 'TK' ||
    (student.Jenjang === 'SD' && Number(student.Tingkat) <= 3);

  const effectiveUid = student.Kartu_RFID || (usesClassCard ? classCardUid : undefined);
  const hasConsent = Boolean(student.Persetujuan_Ortu);

  const jenjangHeaderBg: Record<string, string> = {
    'SMA/SMK': 'bg-emerald-800',
    SMP: 'bg-teal-800',
    SD: 'bg-sky-800',
    TK: 'bg-amber-700',
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col justify-between">
      {/* Card Top Strip */}
      <div
        className={`${
          jenjangHeaderBg[student.Jenjang] || 'bg-emerald-800'
        } text-white px-4 py-3 flex items-center justify-between gap-2`}
      >
        <div className="flex items-center gap-2 min-w-0">
          <Leaf className="w-4 h-4 shrink-0" />
          <div className="min-w-0">
            <div className="text-[11px] font-medium text-white/80 truncate">
              YPIK PAM JAYA · Eco Smart School
            </div>
            <div className="font-display text-xs font-bold tracking-wide truncate">
              KARTU RFID {usesClassCard ? 'KOLEKTIF KELAS' : 'PELAJAR'}
            </div>
          </div>
        </div>
        <Wifi className="w-4 h-4 rotate-90 text-white/80 shrink-0" aria-hidden="true" />
      </div>

      {/* Card Body */}
      <div className={compact ? 'p-4 space-y-3' : 'p-5 space-y-4'}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 font-display font-bold text-sm flex items-center justify-center shrink-0">
              {student.Nama.split(' ')
                .slice(0, 2)
                .map((n) => n[0])
                .join('')
                .toUpperCase()}
            </div>
            <div className="min-w-0">
              <h4 className="font-display font-bold text-slate-900 text-sm truncate">
                {student.Nama}
              </h4>
              <p className="text-xs text-slate-600 truncate">
                {student.Jenjang} {student.Kelas ? `· ${student.Kelas}` : ''}
              </p>
              <p className="font-mono text-[11px] text-slate-500 mt-0.5">
                ID: {student.ID_Pengguna}
              </p>
            </div>
          </div>

          {/* EMV / RFID Chip Graphic */}
          <svg
            viewBox="0 0 36 28"
            className="w-9 h-7 shrink-0 text-amber-500"
            aria-hidden="true"
          >
            <rect
              x="1"
              y="1"
              width="34"
              height="26"
              rx="4"
              fill="#fef3c7"
              stroke="#d97706"
              strokeWidth="1.5"
            />
            <line x1="12" y1="1" x2="12" y2="27" stroke="#d97706" strokeWidth="1" />
            <line x1="24" y1="1" x2="24" y2="27" stroke="#d97706" strokeWidth="1" />
            <line x1="1" y1="10" x2="35" y2="10" stroke="#d97706" strokeWidth="1" />
            <line x1="1" y1="18" x2="35" y2="18" stroke="#d97706" strokeWidth="1" />
          </svg>
        </div>

        {/* UID Box */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
          <div>
            <span className="text-[11px] text-slate-500 block">
              {student.Kartu_RFID
                ? 'UID Kartu RFID Pribadi'
                : usesClassCard
                ? 'UID Kartu Kelas'
                : 'UID Kartu RFID'}
            </span>
            {effectiveUid ? (
              <span className="font-mono tabular-nums text-base font-bold tracking-wider text-slate-900">
                {effectiveUid}
              </span>
            ) : (
              <span className="text-xs font-semibold text-amber-700">
                Belum Terdaftar
              </span>
            )}
          </div>
          <CreditCard className="w-5 h-5 text-slate-400 shrink-0" />
        </div>

        {/* Footer Status & Optional Action */}
        <div className="flex items-center justify-between gap-2 pt-1 text-xs">
          {hasConsent ? (
            <span className="text-emerald-700 font-medium flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Persetujuan Ortu Aktif</span>
            </span>
          ) : (
            <span className="text-red-700 font-medium flex items-center gap-1">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Menunggu Persetujuan Ortu</span>
            </span>
          )}

          {onAssignClick && (
            <button
              type="button"
              onClick={() => onAssignClick(student)}
              className="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer shrink-0"
            >
              {student.Kartu_RFID ? 'Ubah UID' : 'Daftarkan UID'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
