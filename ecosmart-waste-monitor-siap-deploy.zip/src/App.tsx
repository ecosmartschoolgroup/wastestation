import React, { useEffect, useState, useCallback } from 'react';
import {
  Leaf,
  Home,
  PlusCircle,
  Trophy,
  BookOpen,
  User,
  CheckSquare,
  BarChart3,
  FileSpreadsheet,
  Cpu,
  Settings,
  LogOut,
  AlertTriangle,
  CreditCard,
  X,
} from 'lucide-react';
import type { AppDatabase, Jenjang, Kelas, Pengguna } from './types.ts';
import { LoginView } from './components/LoginView.tsx';
import { StudentHomeView } from './components/StudentHomeView.tsx';
import { SetorManualView } from './components/SetorManualView.tsx';
import { EcoRangerView } from './components/EcoRangerView.tsx';
import { GuruDashboardView } from './components/GuruDashboardView.tsx';
import { PanduanKuisView } from './components/PanduanKuisView.tsx';
import { ClassModeView } from './components/ClassModeView.tsx';
import { WasteStationKioskView } from './components/WasteStationKioskView.tsx';
import { AdminView } from './components/AdminView.tsx';
import { TapRfidView } from './components/TapRfidView.tsx';
import { playBuzzerPattern } from './utils/audio.ts';

type NavTab =
  | 'beranda'
  | 'setor'
  | 'peringkat'
  | 'panduan'
  | 'akun'
  | 'verifikasi'
  | 'dashboard'
  | 'bulanan'
  | 'station'
  | 'tap-rfid'
  | 'admin';

export default function App() {
  const [db, setDb] = useState<AppDatabase | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<Pengguna | null>(null);
  const [classModeKelas, setClassModeKelas] = useState<Kelas | null>(null);
  const [tapRfidStandalone, setTapRfidStandalone] = useState(false);
  const [selectedJenjang, setSelectedJenjang] = useState<Jenjang | 'ALL'>('ALL');
  const [activeTab, setActiveTab] = useState<NavTab>('beranda');
  const [liveToast, setLiveToast] = useState<{
    id: string;
    title: string;
    message: string;
    urgent: boolean;
  } | null>(null);

  const fetchBootstrap = useCallback(async () => {
    try {
      const res = await fetch('/api/bootstrap');
      if (!res.ok) return;
      const data: AppDatabase = await res.json();
      setDb(data);
      // Sync currentUser if logged in
      setCurrentUser((prev) => {
        if (!prev) return null;
        return data.Pengguna.find((u) => u.ID_Pengguna === prev.ID_Pengguna) || prev;
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBootstrap();
  }, [fetchBootstrap]);

  // Real-Time Server-Sent Events subscription
  useEffect(() => {
    const es = new EventSource('/api/events');
    es.addEventListener('update', (ev) => {
      try {
        const parsed = JSON.parse((ev as MessageEvent).data) as {
          type: string;
          payload: { alert?: { Station_ID: string; Kompartemen: string; Isi_Persen: number; Pesan: string } };
        };
        fetchBootstrap();

        if (parsed.type === 'iot_setoran' && parsed.payload?.alert) {
          const al = parsed.payload.alert;
          playBuzzerPattern('alert_full', 'UMUM');
          setLiveToast({
            id: String(Date.now()),
            title: `Tong Penuh Otomatis: ${al.Station_ID}`,
            message: al.Pesan,
            urgent: true,
          });
        } else if (parsed.type === 'iot_setoran') {
          setLiveToast({
            id: String(Date.now()),
            title: 'Setoran IoT Diterima Real-Time',
            message: 'Data Smart Waste Station berhasil disinkronkan ke dashboard.',
            urgent: false,
          });
        }
      } catch {
        fetchBootstrap();
      }
    });
    return () => es.close();
  }, [fetchBootstrap]);

  const handleLoginSuccess = (user: Pengguna) => {
    setCurrentUser(user);
    setClassModeKelas(null);
    setTapRfidStandalone(false);
    if (user.Peran === 'Siswa') {
      setSelectedJenjang(user.Jenjang);
      setActiveTab('beranda');
    } else if (user.Peran === 'Petugas') {
      setActiveTab('verifikasi');
    } else if (user.Peran === 'Guru') {
      setActiveTab('dashboard');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleGrantConsent = async (idPengguna: string) => {
    const res = await fetch('/api/auth/consent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idPengguna }),
    });
    const data = await res.json();
    if (data.ok) {
      setCurrentUser(data.user);
      fetchBootstrap();
    }
  };

  if (loading || !db) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center mx-auto">
            <Leaf className="w-5 h-5" />
          </div>
          <p className="text-sm font-medium text-slate-600">
            Memuat sistem Eco Smart School...
          </p>
        </div>
      </div>
    );
  }

  // Mode Kelas TK / SD 1-3 view
  if (classModeKelas) {
    return (
      <ClassModeView
        kelas={classModeKelas}
        users={db.Pengguna}
        setoran={db.Setoran}
        observasiTK={db.Observasi_TK}
        onRefresh={fetchBootstrap}
        onExit={() => setClassModeKelas(null)}
      />
    );
  }

  // Standalone Tap RFID screen (accessible without login)
  if (!currentUser && tapRfidStandalone) {
    return (
      <TapRfidView
        stations={db.Stations}
        users={db.Pengguna}
        classes={db.Kelas}
        setoran={db.Setoran}
        selectedJenjang={selectedJenjang}
        onChangeJenjang={setSelectedJenjang}
        onRefresh={fetchBootstrap}
        onBackToLogin={() => setTapRfidStandalone(false)}
      />
    );
  }

  // Unauthenticated Login screen
  if (!currentUser) {
    return (
      <LoginView
        users={db.Pengguna}
        classes={db.Kelas}
        selectedJenjang={selectedJenjang}
        onChangeJenjang={setSelectedJenjang}
        onLoginSuccess={handleLoginSuccess}
        onOpenClassMode={(cls) => setClassModeKelas(cls)}
        onOpenTapRfid={() => setTapRfidStandalone(true)}
      />
    );
  }

  // Role-based navigation items
  const navItems: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] =
    currentUser.Peran === 'Siswa'
      ? [
          { id: 'beranda', label: 'Beranda', icon: Home },
          { id: 'setor', label: 'Setor', icon: PlusCircle },
          { id: 'panduan', label: 'Panduan', icon: BookOpen },
          { id: 'peringkat', label: 'Peringkat', icon: Trophy },
          { id: 'akun', label: 'Akun', icon: User },
        ]
      : currentUser.Peran === 'Petugas'
      ? [
          { id: 'verifikasi', label: 'Verifikasi', icon: CheckSquare },
          { id: 'tap-rfid', label: 'Tap RFID', icon: CreditCard },
          { id: 'station', label: 'Station', icon: Cpu },
          { id: 'bulanan', label: 'Laporan', icon: FileSpreadsheet },
        ]
      : currentUser.Peran === 'Guru'
      ? [
          { id: 'dashboard', label: 'Rekap Kelas', icon: BarChart3 },
          { id: 'bulanan', label: 'Bulanan', icon: FileSpreadsheet },
          { id: 'tap-rfid', label: 'Tap RFID', icon: CreditCard },
          { id: 'panduan', label: 'Panduan & Kuis', icon: BookOpen },
          { id: 'station', label: 'Station', icon: Cpu },
        ]
      : [
          { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'bulanan', label: 'Bulanan', icon: FileSpreadsheet },
          { id: 'tap-rfid', label: 'Tap RFID', icon: CreditCard },
          { id: 'verifikasi', label: 'Verifikasi', icon: CheckSquare },
          { id: 'admin', label: 'Admin', icon: Settings },
        ];

  const activeFullBins = db.Notifikasi_Log.filter((n) => n.Status === 'Aktif');
  const pendingVerifyCount = db.Setoran.filter(
    (s) => s.Status === 'Menunggu' && s.Sumber === 'Manual'
  ).length;
  const roleLabel =
    currentUser.Peran === 'Petugas' ? 'Eco Ranger' : currentUser.Peran;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Desktop Left Sidebar (Laptop & PC) */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white border-r border-slate-200 z-30">
        <div className="h-16 px-5 border-b border-slate-200 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
            <Leaf className="w-4 h-4" />
          </div>
          <span className="font-display font-bold text-slate-900 tracking-tight truncate">
            Eco Smart School
          </span>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full min-h-[42px] px-3.5 py-2.5 rounded-lg text-sm font-medium flex items-center justify-between transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2.5 whitespace-nowrap">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </span>
                {item.id === 'verifikasi' && pendingVerifyCount > 0 && (
                  <span className="font-mono tabular-nums text-xs font-bold text-amber-700">
                    {pendingVerifyCount}
                  </span>
                )}
              </button>
            );
          })}

          {currentUser.Peran === 'Admin' && (
            <button
              type="button"
              onClick={() => setActiveTab('station')}
              className={`w-full min-h-[42px] px-3.5 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
                activeTab === 'station'
                  ? 'bg-emerald-50 text-emerald-800 font-semibold'
                  : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Cpu className="w-4 h-4 shrink-0" />
              <span>Station IoT</span>
            </button>
          )}

          {/* TK/SD Mode Kelas shortcut for Guru/Admin */}
          {(currentUser.Peran === 'Guru' || currentUser.Peran === 'Admin') && (
            <div className="pt-4 mt-4 border-t border-slate-200 space-y-1">
              <span className="px-3.5 text-[11px] font-semibold text-slate-400 block">
                Mode Kelas TK &amp; SD 1–3
              </span>
              {db.Kelas.filter(
                (c) => c.Jenjang === 'TK' || (c.Jenjang === 'SD' && Number(c.Tingkat) <= 3)
              ).map((cls) => (
                <button
                  key={cls.Kelas}
                  type="button"
                  onClick={() => setClassModeKelas(cls)}
                  className="w-full min-h-[38px] px-3.5 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 text-left cursor-pointer"
                >
                  Buka {cls.Kelas} ({cls.Jenjang})
                </button>
              ))}
            </div>
          )}
        </nav>

        {/* Bottom User Info & Logout */}
        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-900 truncate">
                {currentUser.Nama}
              </div>
              <div className="text-[11px] text-slate-500 truncate">
                {roleLabel} · {currentUser.Jenjang}
              </div>
            </div>
            <button
              type="button"
              aria-label="Keluar"
              onClick={() => setCurrentUser(null)}
              className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-700 flex items-center justify-center cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Top Context Header (Mobile/Tablet + Desktop) */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-xs border-b border-slate-200 h-14 px-4 sm:px-6 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className="lg:hidden w-7 h-7 rounded-md bg-emerald-700 text-white flex items-center justify-center shrink-0">
              <Leaf className="w-4 h-4" />
            </span>
            <span className="text-sm font-semibold text-slate-900 truncate">
              {activeTab === 'tap-rfid'
                ? 'Tap Kartu RFID'
                : navItems.find((n) => n.id === activeTab)?.label || 'Beranda'}
            </span>
            <span className="text-slate-300 hidden sm:inline">·</span>
            <span className="text-xs text-slate-500 hidden sm:inline truncate">
              {currentUser.Nama} ({roleLabel})
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* School Level Switcher in Header */}
            {currentUser.Peran !== 'Siswa' && (
              <select
                aria-label="Pilih Tingkat Sekolah"
                value={selectedJenjang}
                onChange={(e) => setSelectedJenjang(e.target.value as Jenjang | 'ALL')}
                className="min-h-[36px] px-2.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800"
              >
                <option value="ALL">Semua Level</option>
                <option value="TK">Level TK</option>
                <option value="SD">Level SD</option>
                <option value="SMP">Level SMP</option>
                <option value="SMA/SMK">Level SMA/SMK</option>
              </select>
            )}

            <button
              type="button"
              onClick={() => setActiveTab('tap-rfid')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'tap-rfid'
                  ? 'bg-emerald-700 border-emerald-700 text-white'
                  : 'border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Tap Kartu RFID</span>
              <span className="sm:hidden">RFID</span>
            </button>

            <button
              type="button"
              aria-label="Keluar"
              onClick={() => setCurrentUser(null)}
              className="lg:hidden min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </header>

        {/* Global Full-Bin Real-Time Notification Strip for Eco Ranger / Admin / Guru */}
        {activeFullBins.length > 0 && currentUser.Peran !== 'Siswa' && (
          <div className="bg-red-700 text-white px-4 sm:px-6 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                <strong>Notifikasi Tong Penuh (&gt;80%):</strong>{' '}
                {activeFullBins
                  .map((b) => `${b.Station_ID} ${b.Kompartemen} (${b.Isi_Persen}%)`)
                  .join(' · ')}
              </span>
            </div>
            {(currentUser.Peran === 'Petugas' || currentUser.Peran === 'Admin') && (
              <button
                type="button"
                onClick={() => setActiveTab('verifikasi')}
                className="underline font-semibold cursor-pointer whitespace-nowrap"
              >
                Kelola Pengosongan &rarr;
              </button>
            )}
          </div>
        )}

        {/* Live SSE Toast */}
        {liveToast && (
          <div className="fixed top-16 right-4 z-40 max-w-sm w-[calc(100%-2rem)] bg-white border border-slate-200 shadow-lg rounded-xl p-4 flex items-start gap-3">
            <AlertTriangle
              className={`w-5 h-5 shrink-0 mt-0.5 ${
                liveToast.urgent ? 'text-red-600' : 'text-emerald-700'
              }`}
            />
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-slate-900">{liveToast.title}</div>
              <div className="text-xs text-slate-600 mt-0.5">{liveToast.message}</div>
            </div>
            <button
              type="button"
              aria-label="Tutup notifikasi"
              onClick={() => setLiveToast(null)}
              className="text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Active View Content */}
        {activeTab === 'tap-rfid' ? (
          <TapRfidView
            stations={db.Stations}
            users={db.Pengguna}
            classes={db.Kelas}
            setoran={db.Setoran}
            selectedJenjang={selectedJenjang}
            onChangeJenjang={setSelectedJenjang}
            onRefresh={fetchBootstrap}
          />
        ) : (
          <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 lg:pb-10">
            {currentUser.Peran === 'Siswa' &&
              (activeTab === 'beranda' || activeTab === 'peringkat' || activeTab === 'akun') && (
                <StudentHomeView
                  user={currentUser}
                  setoran={db.Setoran}
                  classes={db.Kelas}
                  jenisSampah={db.JenisSampah}
                  activeTab={activeTab}
                  onGoSetor={() => setActiveTab('setor')}
                  onGoPanduan={() => setActiveTab('panduan')}
                  onGrantConsent={handleGrantConsent}
                  onLogout={() => setCurrentUser(null)}
                />
              )}

            {activeTab === 'setor' && currentUser.Peran === 'Siswa' && (
              <SetorManualView
                user={currentUser}
                jenisSampah={db.JenisSampah}
                onSubmitted={fetchBootstrap}
                onGoPanduan={() => setActiveTab('panduan')}
              />
            )}

            {activeTab === 'panduan' && (
              <PanduanKuisView
                user={currentUser}
                panduan={db.Panduan}
                kuisSoal={db.Kuis_Soal}
                jenisSampah={db.JenisSampah}
                onQuizSaved={fetchBootstrap}
              />
            )}

            {activeTab === 'verifikasi' &&
              (currentUser.Peran === 'Petugas' || currentUser.Peran === 'Admin') && (
                <EcoRangerView
                  user={currentUser}
                  setoran={db.Setoran}
                  stations={db.Stations}
                  jenisSampah={db.JenisSampah}
                  notifikasiLog={db.Notifikasi_Log}
                  onRefresh={fetchBootstrap}
                />
              )}

            {(activeTab === 'dashboard' || activeTab === 'bulanan') &&
              currentUser.Peran !== 'Siswa' && (
                <GuruDashboardView
                  db={db}
                  setoran={db.Setoran}
                  classes={db.Kelas}
                  stations={db.Stations}
                  kuisHasil={db.Kuis_Hasil}
                  initialTab={activeTab === 'bulanan' ? 'bulanan' : 'rekap'}
                  selectedJenjang={selectedJenjang}
                />
              )}

            {activeTab === 'station' && currentUser.Peran !== 'Siswa' && (
              <WasteStationKioskView
                stations={db.Stations}
                users={db.Pengguna}
                classes={db.Kelas}
                onRefresh={fetchBootstrap}
              />
            )}

            {activeTab === 'admin' && currentUser.Peran === 'Admin' && (
              <AdminView
                db={db}
                onRefresh={fetchBootstrap}
                selectedJenjang={selectedJenjang}
              />
            )}
          </main>
        )}
      </div>

      {/* Mobile / iOS / Android Thumb-Zone Bottom Tab Bar (< 15% viewport height) */}
      <nav
        aria-label="Navigasi Utama"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div
          className="grid h-15 items-center"
          style={{ gridTemplateColumns: `repeat(${navItems.length}, minmax(0, 1fr))` }}
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium cursor-pointer ${
                  active ? 'text-emerald-700 font-semibold' : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="truncate max-w-full px-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
