import type { JenisKey, JenisSampah } from '../types.ts';

export const WASTE_META: Record<
  JenisKey,
  {
    colorBg: string;
    colorText: string;
    colorBorder: string;
    barColor: string;
    shapeLabel: string;
    tongLabel: string;
  }
> = {
  Organik: {
    colorBg: 'bg-emerald-50',
    colorText: 'text-emerald-800',
    colorBorder: 'border-emerald-200',
    barColor: '#16a34a',
    shapeLabel: 'Lingkaran · Tong Hijau',
    tongLabel: 'Hijau',
  },
  Anorganik: {
    colorBg: 'bg-amber-50',
    colorText: 'text-amber-800',
    colorBorder: 'border-amber-200',
    barColor: '#d97706',
    shapeLabel: 'Segitiga · Tong Kuning',
    tongLabel: 'Kuning',
  },
  Residu: {
    colorBg: 'bg-slate-100',
    colorText: 'text-slate-700',
    colorBorder: 'border-slate-300',
    barColor: '#64748b',
    shapeLabel: 'Persegi · Tong Abu-abu',
    tongLabel: 'Abu-abu',
  },
  Elektronik: {
    colorBg: 'bg-orange-50',
    colorText: 'text-orange-800',
    colorBorder: 'border-orange-200',
    barColor: '#ea580c',
    shapeLabel: 'Petir B3 · Wadah Khusus',
    tongLabel: 'Oranye (Terkunci)',
  },
};

export function getJenisLabel(jenis: JenisKey, list: JenisSampah[]): string {
  return list.find((j) => j.Jenis === jenis)?.Label_Aplikasi || jenis;
}

export function formatTimeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.round(diffMs / 60_000));
  if (mins < 1) return 'baru saja';
  if (mins < 60) return `${mins} mnt lalu`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} jam lalu`;
  const days = Math.round(hrs / 24);
  return `${days} hari lalu`;
}

export function formatJakartaDateTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}
