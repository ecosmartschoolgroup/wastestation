// Web Audio API synthesizer for ESP32 Smart Waste Station buzzer patterns (PRD 5.3 & FR-JJ-10)

let audioCtx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtx) audioCtx = new Ctx();
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playTone(freq: number, durationMs: number, type: OscillatorType = 'sine', volume = 0.14) {
  const ctx = getCtx();
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ctx.currentTime);
  gain.gain.setValueAtTime(volume, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + durationMs / 1000);
}

export function playBuzzerPattern(
  pattern: 'card_read' | 'success' | 'timeout' | 'error' | 'alert_full',
  modeJenjang: 'UMUM' | 'TK_SD' = 'UMUM'
) {
  if (modeJenjang === 'TK_SD') {
    if (pattern === 'card_read') {
      playTone(660, 90, 'triangle', 0.12);
      return;
    }
    if (pattern === 'success') {
      // Friendly ascending chime (FR-JJ-10)
      playTone(523.25, 110, 'triangle', 0.14);
      setTimeout(() => playTone(659.25, 110, 'triangle', 0.14), 110);
      setTimeout(() => playTone(783.99, 180, 'triangle', 0.14), 220);
      return;
    }
    if (pattern === 'error' || pattern === 'timeout') {
      // Gentle soft double tone instead of harsh 600ms buzz (AC-JJ-08)
      playTone(440, 120, 'sine', 0.1);
      setTimeout(() => playTone(493.88, 120, 'sine', 0.1), 150);
      return;
    }
  }

  switch (pattern) {
    case 'card_read':
      playTone(1200, 80, 'square', 0.08);
      break;
    case 'success':
      playTone(1500, 150, 'square', 0.09);
      break;
    case 'timeout':
      playTone(600, 400, 'sawtooth', 0.08);
      break;
    case 'error':
      playTone(350, 600, 'sawtooth', 0.1);
      break;
    case 'alert_full':
      playTone(880, 140, 'triangle', 0.12);
      setTimeout(() => playTone(880, 140, 'triangle', 0.12), 200);
      break;
  }
}

export function speakIndonesian(text: string) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'id-ID';
    utter.rate = 0.95;
    utter.pitch = 1.05;
    window.speechSynthesis.speak(utter);
  } catch {
    // Ignore if speech synthesis blocked
  }
}
