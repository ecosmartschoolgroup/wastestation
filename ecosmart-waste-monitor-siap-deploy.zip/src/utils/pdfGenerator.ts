import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { AppDatabase, MonthlyAnalyticsReport } from '../types.ts';

function addHeaderFooter(doc: jsPDF, title: string) {
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();

    // Top thin rule on pages >= 2
    if (i > 1) {
      doc.setDrawColor(226, 232, 240);
      doc.line(14, 14, pageW - 14, 14);
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(title, 14, 11);
      doc.text('Eco Smart School · YPIK PAM JAYA', pageW - 14, 11, { align: 'right' });
    }

    // Footer
    doc.setDrawColor(226, 232, 240);
    doc.line(14, pageH - 14, pageW - 14, pageH - 14);
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Dokumen Resmi Eco Smart School · Lintas Jenjang TK, SD, SMP, SMA/SMK', 14, pageH - 9);
    doc.text(`Halaman ${i} dari ${pageCount}`, pageW - 14, pageH - 9, { align: 'right' });
  }
}

export function generateMonthlyReportPDF(
  report: MonthlyAnalyticsReport,
  filterLabel: string,
  classRows: {
    kelas: string;
    jenjang: string;
    organik: number;
    anorganik: number;
    residu: number;
    total: number;
    poin: number;
  }[]
): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();

  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageW, 38, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('LAPORAN ANALISIS DATA BULANAN PENGELOLAAN LIMBAH', 14, 17);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Eco Smart School · YPIK PAM JAYA · Filter Aktif: ${filterLabel}`, 14, 25);
  doc.text(
    `Periode Fokus: ${report.periodeBulan} · Dicetak: ${new Date().toLocaleString('id-ID')}`,
    14,
    31
  );

  // Summary KPIs
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('1. Ringkasan Indikator Efisiensi Berkelanjutan', 14, 48);

  autoTable(doc, {
    startY: 52,
    head: [['Indikator Kinerja', 'Nilai Saat Ini', 'Target / Keterangan PRD']],
    body: [
      ['Total Sampah Terkumpul (Periode Aktif)', `${report.ringkasan.total_kg} kg`, 'Akumulasi setoran terverifikasi'],
      ['Diversion Rate (Kompos + Daur Ulang)', `${report.ringkasan.diversion_rate}%`, 'Persentase limbah berhasil dialihkan dari TPA'],
      ['Akurasi Pemilahan Siswa (Terpilah Benar)', `${report.ringkasan.akurasi_pilah}%`, 'Target G2: >= 85% (Setoran Manual Jenis = Jenis_Awal)'],
      ['Adopsi Smart Waste Station (IoT)', `${report.ringkasan.iot_adoption}%`, 'Target G3: >= 70% setoran berasal dari station'],
      ['Rata-rata Respon Pengosongan Tong', `${report.ringkasan.avg_response_hours} jam`, 'Target G4: <= 1 hari kerja sejak isi > 80%'],
      ['Efisiensi Beban Sampah per Siswa', `${report.ringkasan.efisiensi_per_siswa_kg} kg/siswa`, 'Metrik rasio adil lintas jenjang (FR-JJ-13)'],
    ],
    styles: { fontSize: 9, cellPadding: 3 },
    headStyles: { fillColor: [21, 128, 61], textColor: 255 },
    margin: { left: 14, right: 14 },
  });

  // Monthly Trend Table
  const y1 = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 9;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('2. Tren Data Bulanan (6 Bulan Terakhir)', 14, y1);

  autoTable(doc, {
    startY: y1 + 4,
    head: [['Bulan', 'Kompos (kg)', 'Daur Ulang (kg)', 'Residu (kg)', 'Total (kg)', 'Diversion %', 'IoT / Manual']],
    body: report.trenBulanan.map((b) => [
      b.label,
      b.organik_kg.toFixed(1),
      b.anorganik_kg.toFixed(1),
      b.residu_kg.toFixed(1),
      b.total_kg.toFixed(1),
      `${b.diversion_rate}%`,
      `${b.iot_count} / ${b.manual_count}`,
    ]),
    styles: { fontSize: 8.5, cellPadding: 2.5 },
    headStyles: { fillColor: [15, 23, 42], textColor: 255 },
    margin: { left: 14, right: 14 },
  });

  // Class Breakdown
  const y2 = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 9;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('3. Rekapitulasi Per Kelas (Filter Aktif)', 14, y2);

  autoTable(doc, {
    startY: y2 + 4,
    head: [['Kelas', 'Jenjang', 'Kompos (kg)', 'Daur Ulang (kg)', 'Residu (kg)', 'Total (kg)', 'Poin']],
    body: classRows.map((c) => [
      c.kelas,
      c.jenjang,
      c.organik.toFixed(2),
      c.anorganik.toFixed(2),
      c.residu.toFixed(2),
      c.total.toFixed(2),
      String(c.poin),
    ]),
    styles: { fontSize: 8.5, cellPadding: 2.5 },
    headStyles: { fillColor: [21, 128, 61], textColor: 255 },
    margin: { left: 14, right: 14 },
  });

  // Insights
  const y3 = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 9;
  if (y3 < 250) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('4. Rekomendasi & Insight Otomatis', 14, y3);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    let iy = y3 + 6;
    for (const ins of report.insightOtomatis.slice(0, 4)) {
      const txt = `• ${ins.judul}: ${ins.deskripsi} Saran: ${ins.rekomendasi}`;
      const lines = doc.splitTextToSize(txt, pageW - 28);
      if (iy + lines.length * 4.5 > 275) break;
      doc.text(lines, 14, iy);
      iy += lines.length * 4.5 + 2;
    }
  }

  addHeaderFooter(doc, `Laporan Analisis Bulanan — ${report.periodeBulan}`);
  doc.save(`Laporan_Bulanan_EcoSmartSchool_${report.periodeBulan}.pdf`);
}

export function downloadStandaloneHTMLSnapshot(
  db: AppDatabase,
  report: MonthlyAnalyticsReport
): void {
  const rowsHtml = report.trenBulanan
    .map(
      (b) => `<tr>
        <td>${b.label}</td>
        <td>${b.organik_kg.toFixed(2)} kg</td>
        <td>${b.anorganik_kg.toFixed(2)} kg</td>
        <td>${b.residu_kg.toFixed(2)} kg</td>
        <td><strong>${b.total_kg.toFixed(2)} kg</strong></td>
        <td>${b.diversion_rate}%</td>
        <td>${b.accuracy_rate}%</td>
      </tr>`
    )
    .join('');

  const html = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Ringkasan Ekspor Eco Smart School — ${report.periodeBulan}</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; margin: 24px; color: #0f172a; background: #f8fafc; }
  .wrap { max-width: 960px; margin: auto; background: #fff; padding: 28px; border: 1px solid #e2e8f0; border-radius: 12px; }
  h1 { color: #15803d; margin-top: 0; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin: 20px 0; }
  .kpi { border: 1px solid #e2e8f0; padding: 14px; border-radius: 8px; }
  .kpi small { color: #64748b; display: block; }
  .kpi strong { font-size: 22px; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 14px; }
  th, td { border-bottom: 1px solid #e2e8f0; padding: 10px 8px; text-align: left; }
  th { background: #f1f5f9; }
</style>
</head>
<body>
<div class="wrap">
  <h1>Eco Smart School — Ringkasan Data Bulanan</h1>
  <p>YPIK PAM JAYA · Periode ${report.periodeBulan} · Total Pengguna: ${db.Pengguna.length} · Total Station: ${db.Stations.length}</p>
  <div class="grid">
    <div class="kpi"><small>Total Berat</small><strong>${report.ringkasan.total_kg} kg</strong></div>
    <div class="kpi"><small>Diversion Rate</small><strong>${report.ringkasan.diversion_rate}%</strong></div>
    <div class="kpi"><small>Terpilah Benar</small><strong>${report.ringkasan.akurasi_pilah}%</strong></div>
    <div class="kpi"><small>Adopsi IoT</small><strong>${report.ringkasan.iot_adoption}%</strong></div>
  </div>
  <h2>Tren Bulanan Pengelolaan Limbah</h2>
  <table>
    <thead><tr><th>Bulan</th><th>Kompos</th><th>Daur Ulang</th><th>Residu</th><th>Total</th><th>Diversion</th><th>Akurasi</th></tr></thead>
    <tbody>${rowsHtml}</tbody>
  </table>
</div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `EcoSmartSchool_Ringkasan_${report.periodeBulan}.html`;
  a.click();
  URL.revokeObjectURL(url);
}
