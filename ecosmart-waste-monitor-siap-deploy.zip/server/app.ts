import express, { type Express, type Request, type Response } from 'express';
import crypto from 'crypto';
import { loadDb, saveDb, computeMonthlyReport } from './store.js';
import type { Jenjang, JenisKey, Peran, Setoran } from '../src/types.js';

// SSE client registry for real-time updates across Laptop, Tablet, PC, iOS & Android
const sseClients = new Set<Response>();

function broadcastEvent(type: string, payload: unknown) {
  const data = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
  for (const res of sseClients) {
    try {
      res.write(`event: update\ndata: ${data}\n\n`);
    } catch {
      sseClients.delete(res);
    }
  }
}

function genShortId(prefix: string): string {
  return `${prefix}${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
}

export function createApiApp(): Express {
  const app = express();
  app.use(express.json({ limit: '5mb' }));

  // Healthcheck endpoint for deployment verification
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, service: 'eco-smart-school', timestamp: new Date().toISOString() });
  });

  // SSE endpoint for real-time dashboard & full-bin notification alerts
  app.get('/api/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    sseClients.add(res);
    res.write(`retry: 5000\nevent: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);

    const keepAlive = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAlive);
        sseClients.delete(res);
      }
    }, 20000);

    // Close gracefully on Vercel serverless before function timeout
    const serverlessTimer = process.env.VERCEL
      ? setTimeout(() => {
          clearInterval(keepAlive);
          sseClients.delete(res);
          res.end();
        }, 12000)
      : null;

    req.on('close', () => {
      clearInterval(keepAlive);
      if (serverlessTimer) clearTimeout(serverlessTimer);
      sseClients.delete(res);
    });
  });

  // Full bootstrap state
  app.get('/api/bootstrap', (_req: Request, res: Response) => {
    const db = loadDb();
    res.json({
      ...db,
      Stations: db.Stations,
    });
  });

  // Login by school email (FR-LG-01..03: auto-detect role from Pengguna table, reject unknown)
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email } = (req.body || {}) as { email?: string };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!cleanEmail) {
      res.status(400).json({ ok: false, pesan: 'Masukkan email sekolah terlebih dahulu.' });
      return;
    }

    const db = loadDb();
    const user = db.Pengguna.find((u) => (u.Email || '').toLowerCase() === cleanEmail);
    if (!user) {
      res.status(403).json({
        ok: false,
        pesan: 'Email tidak terdaftar di database sekolah. Hubungi Admin untuk pendaftaran.',
      });
      return;
    }

    res.json({ ok: true, user });
  });

  // Update parental consent date (FR-JJ-12 / UU PDP)
  app.post('/api/auth/consent', (req: Request, res: Response) => {
    const { idPengguna } = (req.body || {}) as { idPengguna?: string };
    if (typeof idPengguna !== 'string' || !idPengguna.trim()) {
      res.status(400).json({ ok: false, pesan: 'ID pengguna wajib diisi.' });
      return;
    }
    const db = loadDb();
    const user = db.Pengguna.find((u) => u.ID_Pengguna === idPengguna);
    if (!user) {
      res.status(404).json({ ok: false, pesan: 'Pengguna tidak ditemukan.' });
      return;
    }
    if (!user.Persetujuan_Ortu) {
      user.Persetujuan_Ortu = new Date().toISOString().slice(0, 10);
      saveDb(db);
      broadcastEvent('user_updated', user);
    }
    res.json({ ok: true, user });
  });

  // Manual waste deposit (FR-ST-01..08, BR-03, BR-12, BR-14)
  app.post('/api/setoran/manual', (req: Request, res: Response) => {
    const {
      idPengguna,
      tipePenyetor,
      kelasOverride,
      jenis,
      subjenis,
      beratKg,
      jumlahItem,
      foto,
    } = (req.body || {}) as {
      idPengguna?: string;
      tipePenyetor?: 'Siswa' | 'Kelas';
      kelasOverride?: string;
      jenis?: JenisKey;
      subjenis?: string;
      beratKg?: number;
      jumlahItem?: number;
      foto?: string;
    };

    const db = loadDb();
    const user = db.Pengguna.find((u) => u.ID_Pengguna === idPengguna);
    const kelasObj = db.Kelas.find(
      (k) => k.Kelas === (kelasOverride || user?.Kelas)
    );

    if (!user && !kelasObj) {
      res.status(404).json({ ok: false, pesan: 'Penyetor tidak dikenali.' });
      return;
    }

    // BR-14: Reject student deposit without parental consent
    if (user && user.Peran === 'Siswa' && !user.Persetujuan_Ortu) {
      res.status(403).json({
        ok: false,
        pesan: 'Data siswa belum aktif (menunggu persetujuan orang tua/wali).',
      });
      return;
    }

    // BR-12: TK & SD cannot deposit Elektronik/Baterai
    const targetJenjang: Jenjang = kelasObj?.Jenjang || user?.Jenjang || 'SMA/SMK';
    if (
      jenis === 'Elektronik' &&
      (targetJenjang === 'TK' || targetJenjang === 'SD') &&
      user?.Peran === 'Siswa'
    ) {
      res.status(403).json({
        ok: false,
        pesan: 'Jalur Elektronik/Baterai hanya untuk Guru, Eco Ranger, atau siswa SMP/SMA/SMK.',
      });
      return;
    }

    const jenisInfo = db.JenisSampah.find((j) => j.Jenis === jenis);
    if (!jenisInfo) {
      res.status(400).json({ ok: false, pesan: 'Jenis sampah tidak valid.' });
      return;
    }

    const weight = Number(beratKg || 0);
    const items = Number(jumlahItem || 0);

    if (jenisInfo.Satuan === 'item') {
      if (!Number.isFinite(items) || items < 1 || items > 50) {
        res.status(400).json({ ok: false, pesan: 'Jumlah item harus antara 1 sampai 50.' });
        return;
      }
    } else {
      if (!Number.isFinite(weight) || weight < 0.1 || weight > 20) {
        res.status(400).json({ ok: false, pesan: 'Berat setoran manual harus antara 0,1 kg sampai 20 kg.' });
        return;
      }
    }

    const poin =
      jenisInfo.Satuan === 'item'
        ? Math.round(items * jenisInfo.Poin_per_satuan)
        : Math.round(weight * jenisInfo.Poin_per_satuan);

    const record: Setoran = {
      ID: genShortId('STR'),
      Tanggal: new Date().toISOString(),
      ID_Pengguna: tipePenyetor === 'Kelas' ? kelasObj?.Kelas || '' : user!.ID_Pengguna,
      Tipe_Penyetor: tipePenyetor || 'Siswa',
      Email: user?.Email,
      Nama_Penyetor:
        tipePenyetor === 'Kelas'
          ? `Setoran Kolektif ${kelasObj?.Kelas}`
          : user?.Nama || 'Siswa',
      Kelas: kelasObj?.Kelas || user?.Kelas || '-',
      Jenjang: targetJenjang,
      Jenis: jenis!,
      Jenis_Awal: jenis!,
      Subjenis: subjenis,
      Berat_kg: jenisInfo.Satuan === 'item' ? Number((items * 0.05).toFixed(2)) : Number(weight.toFixed(2)),
      Jumlah_item: jenisInfo.Satuan === 'item' ? items : undefined,
      Foto: foto,
      Status: 'Menunggu',
      Poin: poin,
      Sumber: 'Manual',
    };

    db.Setoran.unshift(record);
    saveDb(db);
    broadcastEvent('setoran_baru', record);
    res.json({ ok: true, setoran: record });
  });

  // IoT Smart Waste Station endpoint (PRD Section 6.2 + G-01, G-02, G-05, G-09, BR-05, BR-14)
  app.post('/api/iot/setoran', (req: Request, res: Response) => {
    try {
      const { token, station, kartu, jenis, berat_kg, isi_persen, enforceCooldown } = (req.body || {}) as {
        token?: string;
        station?: string;
        kartu?: string;
        jenis?: string;
        berat_kg?: number;
        isi_persen?: number;
        enforceCooldown?: boolean;
      };

      const db = loadDb();
      const stationObj = db.Stations.find((s) => s.Station_ID === station);

      if (!stationObj || !token || stationObj.Token !== token) {
        res.status(401).json({ ok: false, pesan: 'token salah' });
        return;
      }

      stationObj.Last_Heartbeat = new Date().toISOString();

      const uid = typeof kartu === 'string' ? kartu.trim().toUpperCase() : '';
      if (!uid) {
        res.status(400).json({ ok: false, pesan: 'kartu belum terdaftar' });
        return;
      }

      // Search personal RFID first, then Class Card (Bab 13.3)
      const user = db.Pengguna.find((u) => (u.Kartu_RFID || '').toUpperCase() === uid);
      const kelasCard = db.Kelas.find((k) => (k.Kartu_Kelas || '').toUpperCase() === uid);

      if (!user && !kelasCard) {
        res.status(404).json({ ok: false, pesan: 'kartu belum terdaftar' });
        return;
      }

      // BR-14 / AC-JJ-07: Check parental consent for personal card
      if (user && user.Peran === 'Siswa' && !user.Persetujuan_Ortu) {
        res.status(403).json({ ok: false, pesan: 'data belum aktif (belum ada persetujuan orang tua)' });
        return;
      }

      // G-02: Validate waste type and numeric weight
      const jenisObj = db.JenisSampah.find((j) => j.Jenis === jenis);
      if (!jenisObj || jenisObj.Jalur_Input !== 'IoT + Manual') {
        res.status(400).json({ ok: false, pesan: 'jenis sampah tidak dikenal oleh station' });
        return;
      }

      const berat = Number(berat_kg);
      if (!Number.isFinite(berat) || berat < 0.02) {
        res.status(400).json({ ok: false, pesan: 'berat di bawah batas minimum 20 g (0.02 kg)' });
        return;
      }

      // G-09: Rate limit / anti-anomaly check
      const maxBerat = kelasCard ? 5.0 : 3.0;
      const anomali = berat > maxBerat ? `Berat melebihi batas wajar (${maxBerat} kg)` : undefined;

      const penyetorId = kelasCard ? kelasCard.Kelas : user!.ID_Pengguna;
      const lastRecent = db.Setoran.find(
        (s) =>
          s.Sumber === 'IoT' &&
          s.ID_Pengguna === penyetorId &&
          Date.now() - new Date(s.Tanggal).getTime() < 5000
      );
      if (lastRecent && enforceCooldown) {
        res.status(429).json({ ok: false, pesan: 'jeda antar tap terlalu cepat (tunggu beberapa detik)' });
        return;
      }

      const poin = Math.round(berat * jenisObj.Poin_per_satuan);
      const targetKelas = kelasCard ? kelasCard.Kelas : user!.Kelas;
      const targetJenjang = kelasCard ? kelasCard.Jenjang : user!.Jenjang;

      const record: Setoran = {
        ID: genShortId('IOT'),
        Tanggal: new Date().toISOString(),
        ID_Pengguna: penyetorId,
        Tipe_Penyetor: kelasCard ? 'Kelas' : 'Siswa',
        Email: user?.Email,
        Nama_Penyetor: kelasCard ? `Setoran Kolektif ${kelasCard.Kelas}` : user!.Nama,
        Kelas: targetKelas,
        Jenjang: targetJenjang,
        Jenis: jenisObj.Jenis,
        Jenis_Awal: jenisObj.Jenis,
        Berat_kg: Number(berat.toFixed(2)),
        Status: 'Terverifikasi',
        Poin: poin,
        Sumber: 'IoT',
        Station_ID: stationObj.Station_ID,
        Diverifikasi_Oleh: 'Sistem IoT',
        Waktu_Verifikasi: new Date().toISOString(),
        Anomali: anomali,
      };

      db.Setoran.unshift(record);

      // Update compartment fill % and trigger G-05 single notification per full episode
      const comp = stationObj.Kompartemen.find((c) => c.jenis === jenisObj.Jenis);
      let newAlertTriggered = null;
      if (comp) {
        const pct = Number(isi_persen);
        if (pct === -1) {
          comp.sensor_error = true;
        } else if (Number.isFinite(pct)) {
          comp.sensor_error = false;
          comp.isi_persen = Math.max(0, Math.min(100, Math.round(pct)));
          comp.berat_hari_ini = Number((comp.berat_hari_ini + berat).toFixed(2));

          if (comp.isi_persen > 80 && !comp.episode_penuh) {
            comp.episode_penuh = true;
            comp.waktu_penuh = new Date().toISOString();
            const petugasEmails = db.Pengguna.filter((u) => u.Peran === 'Petugas' && u.Email).map(
              (u) => u.Email as string
            );
            const notif = {
              ID: genShortId('NTF'),
              Waktu: new Date().toISOString(),
              Station_ID: stationObj.Station_ID,
              Kompartemen: comp.jenis,
              Isi_Persen: comp.isi_persen,
              Penerima: petugasEmails.length ? petugasEmails : ['ecoranger@ypikpamjaya.sch.id'],
              Pesan: `Tong ${comp.label} (${comp.jenis}) ${stationObj.Station_ID} penuh ${comp.isi_persen}%, segera kosongkan.`,
              Status: 'Aktif' as const,
            };
            db.Notifikasi_Log.unshift(notif);
            newAlertTriggered = notif;
          }
        }
      }

      saveDb(db);
      broadcastEvent('iot_setoran', { setoran: record, station: stationObj, alert: newAlertTriggered });

      res.json({
        ok: true,
        kelas: targetKelas,
        poin,
        jenjang: targetJenjang,
        tipe: kelasCard ? 'Kelas' : 'Siswa',
        alert: newAlertTriggered,
      });
    } catch {
      res.status(500).json({ ok: false, pesan: 'kesalahan server internal' });
    }
  });

  // Eco Ranger: Verify / Correct Weight & Type (FR-VF-01..06)
  app.post('/api/setoran/:id/verify', (req: Request, res: Response) => {
    const { id } = req.params;
    const { beratBaru, jenisBaru, petugasNama } = (req.body || {}) as {
      beratBaru?: number;
      jenisBaru?: JenisKey;
      petugasNama?: string;
    };

    const db = loadDb();
    const item = db.Setoran.find((s) => s.ID === id);
    if (!item) {
      res.status(404).json({ ok: false, pesan: 'Setoran tidak ditemukan.' });
      return;
    }

    const oldWeight = item.Berat_kg;
    const oldJenis = item.Jenis;

    if (typeof beratBaru === 'number' && Number.isFinite(beratBaru) && beratBaru > 0 && item.Berat_kg !== beratBaru) {
      if (item.Berat_Awal_kg === undefined) {
        item.Berat_Awal_kg = item.Berat_kg;
      }
      item.Berat_kg = Number(beratBaru.toFixed(2));
    }

    if (jenisBaru && jenisBaru !== item.Jenis) {
      item.Jenis = jenisBaru;
    }

    const jenisInfo = db.JenisSampah.find((j) => j.Jenis === item.Jenis);
    if (jenisInfo) {
      item.Poin =
        jenisInfo.Satuan === 'item'
          ? Math.round((item.Jumlah_item || 1) * jenisInfo.Poin_per_satuan)
          : Math.round(item.Berat_kg * jenisInfo.Poin_per_satuan);
    }

    item.Status = 'Terverifikasi';
    item.Diverifikasi_Oleh = typeof petugasNama === 'string' && petugasNama.trim() ? petugasNama.trim() : 'Eco Ranger';
    item.Waktu_Verifikasi = new Date().toISOString();

    if (oldWeight !== item.Berat_kg || oldJenis !== item.Jenis) {
      db.Audit_Log.unshift({
        ID: genShortId('AUD'),
        Waktu: new Date().toISOString(),
        Aktor: item.Diverifikasi_Oleh,
        Aksi: 'Verifikasi dengan Koreksi',
        Detail: `${item.ID} (${item.Nama_Penyetor}): jenis ${oldJenis}->${item.Jenis}, berat ${oldWeight}->${item.Berat_kg} kg`,
      });
    }

    saveDb(db);
    broadcastEvent('setoran_verified', item);
    res.json({ ok: true, setoran: item });
  });

  // Eco Ranger: Reject with mandatory reason (FR-VF-05)
  app.post('/api/setoran/:id/reject', (req: Request, res: Response) => {
    const { id } = req.params;
    const { alasan, petugasNama } = (req.body || {}) as { alasan?: string; petugasNama?: string };
    if (typeof alasan !== 'string' || !alasan.trim()) {
      res.status(400).json({ ok: false, pesan: 'Alasan penolakan wajib diisi.' });
      return;
    }

    const db = loadDb();
    const item = db.Setoran.find((s) => s.ID === id);
    if (!item) {
      res.status(404).json({ ok: false, pesan: 'Setoran tidak ditemukan.' });
      return;
    }

    item.Status = 'Ditolak';
    item.Alasan_Tolak = alasan.trim();
    item.Poin = 0;
    item.Diverifikasi_Oleh = typeof petugasNama === 'string' && petugasNama.trim() ? petugasNama.trim() : 'Eco Ranger';
    item.Waktu_Verifikasi = new Date().toISOString();

    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: new Date().toISOString(),
      Aktor: item.Diverifikasi_Oleh,
      Aksi: 'Tolak Setoran',
      Detail: `${item.ID} (${item.Nama_Penyetor}) ditolak: ${item.Alasan_Tolak}`,
    });

    saveDb(db);
    broadcastEvent('setoran_rejected', item);
    res.json({ ok: true, setoran: item });
  });

  // Eco Ranger: Empty full compartment (FR-VF-08 & G-05 reset)
  app.post('/api/station/:id/empty', (req: Request, res: Response) => {
    const { id } = req.params;
    const { kompartemen, petugasNama } = (req.body || {}) as {
      kompartemen?: 'Organik' | 'Anorganik' | 'Residu';
      petugasNama?: string;
    };

    const db = loadDb();
    const station = db.Stations.find((s) => s.Station_ID === id);
    if (!station) {
      res.status(404).json({ ok: false, pesan: 'Station tidak ditemukan.' });
      return;
    }

    const comp = station.Kompartemen.find((c) => c.jenis === kompartemen);
    if (!comp) {
      res.status(404).json({ ok: false, pesan: 'Kompartemen tidak ditemukan.' });
      return;
    }

    const nowIso = new Date().toISOString();
    comp.isi_persen = 5;
    comp.episode_penuh = false;
    comp.terakhir_dikosongkan = nowIso;
    comp.sensor_error = false;

    const actorName = typeof petugasNama === 'string' && petugasNama.trim() ? petugasNama.trim() : 'Eco Ranger';

    for (const notif of db.Notifikasi_Log) {
      if (
        notif.Station_ID === id &&
        notif.Kompartemen === kompartemen &&
        notif.Status === 'Aktif'
      ) {
        notif.Status = 'Dikosongkan';
        notif.Waktu_Kosong = nowIso;
        notif.Dikosongkan_Oleh = actorName;
        const diffMs = new Date(nowIso).getTime() - new Date(notif.Waktu).getTime();
        notif.Durasi_Respon_Menit = Math.max(1, Math.round(diffMs / 60_000));
      }
    }

    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: nowIso,
      Aktor: actorName,
      Aksi: 'Pengosongan Tong',
      Detail: `${id} kompartemen ${kompartemen} dikosongkan dan episode penuh direset.`,
    });

    saveDb(db);
    broadcastEvent('station_emptied', { stationId: id, kompartemen, station });
    res.json({ ok: true, station });
  });

  // Update station heartbeat
  app.post('/api/station/:id/heartbeat', (req: Request, res: Response) => {
    const { id } = req.params;
    const db = loadDb();
    const station = db.Stations.find((s) => s.Station_ID === id);
    if (!station) {
      res.status(404).json({ ok: false, pesan: 'Station tidak ditemukan.' });
      return;
    }
    station.Last_Heartbeat = new Date().toISOString();
    saveDb(db);
    broadcastEvent('station_heartbeat', station);
    res.json({ ok: true, station });
  });

  // Quiz submission (FR-PK-06)
  app.post('/api/kuis/submit', (req: Request, res: Response) => {
    const { idPengguna, email, nama, kelas, jenjang, skor, total } = (req.body || {}) as {
      idPengguna: string;
      email?: string;
      nama: string;
      kelas: string;
      jenjang: Jenjang;
      skor: number;
      total: number;
    };
    const db = loadDb();
    const result = {
      ID: genShortId('KH'),
      ID_Pengguna: idPengguna,
      Email: email,
      Nama: nama,
      Kelas: kelas,
      Jenjang: jenjang,
      Tanggal: new Date().toISOString(),
      Skor: Number(skor) || 0,
      Total: Number(total) || 5,
    };
    db.Kuis_Hasil.unshift(result);
    saveDb(db);
    broadcastEvent('kuis_submitted', result);
    res.json({ ok: true, result });
  });

  // TK Teacher Observation Checklist (FR-JJ-11)
  app.post('/api/observasi-tk', (req: Request, res: Response) => {
    const {
      idPengguna,
      namaSiswa,
      kelas,
      mandiriMemilah,
      kenalWarnaTong,
      bantuTeman,
      catatan,
      guru,
    } = (req.body || {}) as {
      idPengguna: string;
      namaSiswa: string;
      kelas: string;
      mandiriMemilah: boolean;
      kenalWarnaTong: boolean;
      bantuTeman: boolean;
      catatan: string;
      guru: string;
    };
    const db = loadDb();
    const obs = {
      ID: genShortId('OBS'),
      Tanggal: new Date().toISOString(),
      ID_Pengguna: idPengguna,
      Nama_Siswa: namaSiswa,
      Kelas: kelas,
      Mandiri_Memilah: Boolean(mandiriMemilah),
      Kenal_Warna_Tong: Boolean(kenalWarnaTong),
      Bantu_Teman: Boolean(bantuTeman),
      Catatan: catatan || '',
      Guru: guru || 'Guru TK',
    };
    db.Observasi_TK.unshift(obs);
    saveDb(db);
    broadcastEvent('observasi_tk', obs);
    res.json({ ok: true, observasi: obs });
  });

  // Monthly Sustainability Report API
  app.get('/api/reports/monthly', (req: Request, res: Response) => {
    const jenjang = (req.query.jenjang as Jenjang | 'ALL') || 'ALL';
    const bulan = req.query.bulan as string | undefined;
    const db = loadDb();
    const report = computeMonthlyReport(db, jenjang, bulan);
    res.json(report);
  });

  // Admin: Create User (FR-AD-01, AC-JJ-01)
  app.post('/api/admin/users', (req: Request, res: Response) => {
    const {
      ID_Pengguna,
      Email,
      Nama,
      Peran,
      Kelas,
      Jenjang,
      Tingkat,
      Kartu_RFID,
      Persetujuan_Ortu,
    } = (req.body || {}) as {
      ID_Pengguna?: string;
      Email?: string;
      Nama: string;
      Peran: Peran;
      Kelas: string;
      Jenjang: Jenjang;
      Tingkat: string;
      Kartu_RFID?: string;
      Persetujuan_Ortu?: string;
    };

    if (typeof Nama !== 'string' || !Nama.trim()) {
      res.status(400).json({ ok: false, pesan: 'Nama pengguna wajib diisi.' });
      return;
    }

    const db = loadDb();
    const newId = (ID_Pengguna || genShortId('USR')).trim();

    if (db.Pengguna.some((u) => u.ID_Pengguna === newId)) {
      res.status(409).json({ ok: false, pesan: 'ID_Pengguna sudah terdaftar.' });
      return;
    }

    const cleanEmail = Email?.trim().toLowerCase();
    if (cleanEmail && db.Pengguna.some((u) => (u.Email || '').toLowerCase() === cleanEmail)) {
      res.status(409).json({ ok: false, pesan: 'Email sudah dipakai pengguna lain.' });
      return;
    }

    const cleanRfid = Kartu_RFID?.trim().toUpperCase();
    if (
      cleanRfid &&
      (db.Pengguna.some((u) => (u.Kartu_RFID || '').toUpperCase() === cleanRfid) ||
        db.Kelas.some((k) => (k.Kartu_Kelas || '').toUpperCase() === cleanRfid))
    ) {
      res.status(409).json({ ok: false, pesan: 'UID kartu RFID sudah terdaftar.' });
      return;
    }

    const user = {
      ID_Pengguna: newId,
      Email: cleanEmail || undefined,
      Nama: Nama.trim(),
      Peran,
      Kelas: Kelas || '',
      Jenjang,
      Tingkat: Tingkat || '10',
      Kartu_RFID: cleanRfid || undefined,
      Persetujuan_Ortu: Persetujuan_Ortu || '',
    };

    db.Pengguna.push(user);
    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: new Date().toISOString(),
      Aktor: 'Admin',
      Aksi: 'Tambah Pengguna',
      Detail: `${user.ID_Pengguna} - ${user.Nama} (${user.Peran} · ${user.Jenjang})`,
    });
    saveDb(db);
    broadcastEvent('user_created', user);
    res.json({ ok: true, user });
  });

  // Admin: Bulk CSV Import (FR-AD-01 / AC-AD-01)
  app.post('/api/admin/users/import', (req: Request, res: Response) => {
    const { rows } = (req.body || {}) as {
      rows: {
        ID_Pengguna?: string;
        Email?: string;
        Nama: string;
        Peran: Peran;
        Kelas: string;
        Jenjang: Jenjang;
        Tingkat?: string;
      }[];
    };

    const db = loadDb();
    let inserted = 0;
    const rejected: string[] = [];

    for (const r of rows || []) {
      if (!r || typeof r.Nama !== 'string' || !r.Nama.trim()) continue;
      const email = r.Email?.trim().toLowerCase();
      const id = (r.ID_Pengguna || genShortId('CSV')).trim();
      if (
        db.Pengguna.some((u) => u.ID_Pengguna === id) ||
        (email && db.Pengguna.some((u) => (u.Email || '').toLowerCase() === email))
      ) {
        rejected.push(`${r.Nama} (${email || id}): duplikat`);
        continue;
      }
      db.Pengguna.push({
        ID_Pengguna: id,
        Email: email || undefined,
        Nama: r.Nama.trim(),
        Peran: r.Peran || 'Siswa',
        Kelas: r.Kelas || '',
        Jenjang: r.Jenjang || 'SMA/SMK',
        Tingkat: r.Tingkat || '10',
        Persetujuan_Ortu: new Date().toISOString().slice(0, 10),
      });
      inserted++;
    }

    saveDb(db);
    broadcastEvent('users_imported', { inserted, rejectedCount: rejected.length });
    res.json({ ok: true, inserted, rejected });
  });

  // Admin: Register RFID Card to User or Class (FR-AD-02, AC-AD-02)
  app.post('/api/admin/rfid', (req: Request, res: Response) => {
    const { targetType, targetId, uid } = (req.body || {}) as {
      targetType: 'Siswa' | 'Kelas';
      targetId: string;
      uid: string;
    };

    const cleanUid = (uid || '').trim().toUpperCase().replace(/[^A-F0-9]/g, '');
    if (!cleanUid || cleanUid.length < 4) {
      res.status(400).json({ ok: false, pesan: 'UID harus heksadesimal minimal 4 karakter.' });
      return;
    }

    const db = loadDb();
    const usedByUser = db.Pengguna.find(
      (u) =>
        (u.Kartu_RFID || '').toUpperCase() === cleanUid &&
        !(targetType === 'Siswa' && u.ID_Pengguna === targetId)
    );
    const usedByClass = db.Kelas.find(
      (k) =>
        (k.Kartu_Kelas || '').toUpperCase() === cleanUid &&
        !(targetType === 'Kelas' && k.Kelas === targetId)
    );
    if (usedByUser || usedByClass) {
      res.status(409).json({
        ok: false,
        pesan: `UID ${cleanUid} sudah terdaftar pada ${usedByUser ? usedByUser.Nama : usedByClass?.Kelas}.`,
      });
      return;
    }

    if (targetType === 'Kelas') {
      const cls = db.Kelas.find((k) => k.Kelas === targetId);
      if (!cls) {
        res.status(404).json({ ok: false, pesan: 'Kelas tidak ditemukan.' });
        return;
      }
      cls.Kartu_Kelas = cleanUid;
    } else {
      const usr = db.Pengguna.find((u) => u.ID_Pengguna === targetId);
      if (!usr) {
        res.status(404).json({ ok: false, pesan: 'Pengguna tidak ditemukan.' });
        return;
      }
      usr.Kartu_RFID = cleanUid;
    }

    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: new Date().toISOString(),
      Aktor: 'Admin',
      Aksi: 'Registrasi RFID',
      Detail: `UID ${cleanUid} dihubungkan ke ${targetType} ${targetId}`,
    });

    saveDb(db);
    broadcastEvent('rfid_registered', { targetType, targetId, uid: cleanUid });
    res.json({ ok: true, uid: cleanUid });
  });

  // Admin: Update JenisSampah label & points (FR-AD-04, AC-AD-03)
  app.put('/api/admin/jenis/:key', (req: Request, res: Response) => {
    const { key } = req.params;
    const { Label_Aplikasi, Poin_per_satuan, Contoh } = (req.body || {}) as {
      Label_Aplikasi?: string;
      Poin_per_satuan?: number;
      Contoh?: string;
    };

    const db = loadDb();
    const j = db.JenisSampah.find((x) => x.Jenis === key);
    if (!j) {
      res.status(404).json({ ok: false, pesan: 'Jenis sampah tidak ditemukan.' });
      return;
    }

    if (Label_Aplikasi) j.Label_Aplikasi = Label_Aplikasi.trim();
    if (typeof Poin_per_satuan === 'number' && Number.isFinite(Poin_per_satuan) && Poin_per_satuan >= 0) {
      j.Poin_per_satuan = Poin_per_satuan;
    }
    if (Contoh) j.Contoh = Contoh.trim();

    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: new Date().toISOString(),
      Aktor: 'Admin',
      Aksi: 'Ubah Konfigurasi Jenis Sampah',
      Detail: `${j.Jenis}: label="${j.Label_Aplikasi}", poin=${j.Poin_per_satuan}/${j.Satuan}`,
    });

    saveDb(db);
    broadcastEvent('jenis_updated', j);
    res.json({ ok: true, jenis: j });
  });

  // Admin: Rotate Station Token (FR-AD-05)
  app.post('/api/admin/stations/rotate-token', (req: Request, res: Response) => {
    const { stationId } = (req.body || {}) as { stationId?: string };
    const db = loadDb();
    const st = db.Stations.find((s) => s.Station_ID === stationId);
    if (!st) {
      res.status(404).json({ ok: false, pesan: 'Station tidak ditemukan.' });
      return;
    }
    st.Token = `tok-${crypto.randomBytes(4).toString('hex')}`;
    db.Audit_Log.unshift({
      ID: genShortId('AUD'),
      Waktu: new Date().toISOString(),
      Aktor: 'Admin',
      Aksi: 'Rotasi Token Station',
      Detail: `Token ${st.Station_ID} dirotasi.`,
    });
    saveDb(db);
    broadcastEvent('station_updated', st);
    res.json({ ok: true, station: st });
  });

  // Admin: Add Quiz Question (FR-PK-07)
  app.post('/api/admin/kuis', (req: Request, res: Response) => {
    const {
      Jenjang: soalJenjang,
      Pertanyaan,
      Opsi_A,
      Opsi_B,
      Opsi_C,
      Opsi_D,
      Jawaban,
      Penjelasan,
      Jenis_Terkait,
    } = (req.body || {}) as {
      Jenjang?: Jenjang;
      Pertanyaan?: string;
      Opsi_A?: string;
      Opsi_B?: string;
      Opsi_C?: string;
      Opsi_D?: string;
      Jawaban?: 'A' | 'B' | 'C' | 'D';
      Penjelasan?: string;
      Jenis_Terkait?: JenisKey;
    };

    if (!Pertanyaan?.trim() || !Opsi_A || !Opsi_B || !Opsi_C || !Opsi_D || !Jawaban) {
      res.status(400).json({ ok: false, pesan: 'Data soal kuis belum lengkap.' });
      return;
    }

    const db = loadDb();
    const soal = {
      ID: genShortId('Q-'),
      Jenjang: soalJenjang || 'SMA/SMK',
      Pertanyaan: Pertanyaan.trim(),
      Opsi_A,
      Opsi_B,
      Opsi_C,
      Opsi_D,
      Jawaban,
      Penjelasan: Penjelasan || '',
      Jenis_Terkait: Jenis_Terkait || 'Anorganik',
    };
    db.Kuis_Soal.unshift(soal);
    saveDb(db);
    broadcastEvent('kuis_updated', soal);
    res.json({ ok: true, soal });
  });

  return app;
}
