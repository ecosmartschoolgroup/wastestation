import fs from 'fs';
import path from 'path';
import type {
  AppDatabase,
  Jenjang,
  JenisKey,
  MonthlyAnalyticsReport,
  MonthlyBucket,
  Setoran,
} from '../src/types.js';

const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : process.env.VERCEL
  ? path.join('/tmp', 'eco-smart-school-data')
  : path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

function createInitialData(): AppDatabase {
  const now = new Date('2026-11-22T10:30:00+07:00');
  const isoAgo = (minutesAgo: number) =>
    new Date(now.getTime() - minutesAgo * 60_000).toISOString();
  const daysAgo = (d: number, hour = 9) => {
    const dt = new Date(now);
    dt.setDate(dt.getDate() - d);
    dt.setHours(hour, 15, 0, 0);
    return dt.toISOString();
  };

  const Pengguna: AppDatabase['Pengguna'] = [
    {
      ID_Pengguna: 'SMK-2026-001',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama: 'Raka Pratama',
      Peran: 'Siswa',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '11',
      Kartu_RFID: '04A1B2C3',
      Persetujuan_Ortu: '2026-07-15',
    },
    {
      ID_Pengguna: 'SMK-2026-002',
      Email: 'nadia.putri@ypikpamjaya.sch.id',
      Nama: 'Nadia Putri',
      Peran: 'Siswa',
      Kelas: 'XI TKJ 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '11',
      Kartu_RFID: '04D5E6F7',
      Persetujuan_Ortu: '2026-07-15',
    },
    {
      ID_Pengguna: 'SMK-2026-003',
      Email: 'bagas.wijaya@ypikpamjaya.sch.id',
      Nama: 'Bagas Wijaya',
      Peran: 'Siswa',
      Kelas: 'X DKV 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '10',
      Kartu_RFID: '04B9C8D7',
      Persetujuan_Ortu: '', // Belum ada persetujuan ortu (untuk uji BR-14 / AC-JJ-07)
    },
    {
      ID_Pengguna: 'SMA-2026-004',
      Email: 'siti.aisyah@ypikpamjaya.sch.id',
      Nama: 'Siti Aisyah',
      Peran: 'Siswa',
      Kelas: 'X IPA 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '10',
      Kartu_RFID: '04E1F2A3',
      Persetujuan_Ortu: '2026-07-15',
    },
    {
      ID_Pengguna: 'SMP-2026-011',
      Email: 'alya.azzahra@ypikpamjaya.sch.id',
      Nama: 'Alya Azzahra',
      Peran: 'Siswa',
      Kelas: 'VIII A',
      Jenjang: 'SMP',
      Tingkat: '8',
      Kartu_RFID: '14AA22BB',
      Persetujuan_Ortu: '2026-07-16',
    },
    {
      ID_Pengguna: 'SMP-2026-012',
      Email: 'dimas.saputra@ypikpamjaya.sch.id',
      Nama: 'Dimas Saputra',
      Peran: 'Siswa',
      Kelas: 'VII B',
      Jenjang: 'SMP',
      Tingkat: '7',
      Kartu_RFID: '14CC33DD',
      Persetujuan_Ortu: '2026-07-16',
    },
    {
      ID_Pengguna: 'SD-2026-041',
      Email: 'farhan.kamil@ypikpamjaya.sch.id',
      Nama: 'Farhan Kamil',
      Peran: 'Siswa',
      Kelas: 'SD 5A',
      Jenjang: 'SD',
      Tingkat: '5',
      Kartu_RFID: '24EE44FF',
      Avatar: 'rubah',
      PIN_Gambar: ['daun', 'air', 'daun', 'matahari'],
      Persetujuan_Ortu: '2026-07-18',
    },
    {
      ID_Pengguna: 'SD-2026-021',
      Nama: 'Kirana Dewi',
      Peran: 'Siswa',
      Kelas: 'SD 2A',
      Jenjang: 'SD',
      Tingkat: '2',
      Avatar: 'kelinci',
      PIN_Gambar: ['apel', 'daun', 'bintang', 'air'],
      Persetujuan_Ortu: '2026-07-18',
    },
    {
      ID_Pengguna: 'SD-2026-022',
      Nama: 'Bima Sakti',
      Peran: 'Siswa',
      Kelas: 'SD 2A',
      Jenjang: 'SD',
      Tingkat: '2',
      Avatar: 'kura',
      PIN_Gambar: ['matahari', 'matahari', 'daun', 'bintang'],
      Persetujuan_Ortu: '2026-07-18',
    },
    {
      ID_Pengguna: 'TK-2026-001',
      Nama: 'Zara Aulia',
      Peran: 'Siswa',
      Kelas: 'TK-B',
      Jenjang: 'TK',
      Tingkat: 'TK-B',
      Avatar: 'kupu',
      Persetujuan_Ortu: '2026-07-20',
    },
    {
      ID_Pengguna: 'TK-2026-002',
      Nama: 'Kenzo Alvaro',
      Peran: 'Siswa',
      Kelas: 'TK-B',
      Jenjang: 'TK',
      Tingkat: 'TK-B',
      Avatar: 'singa',
      Persetujuan_Ortu: '2026-07-20',
    },
    {
      ID_Pengguna: 'TK-2026-003',
      Nama: 'Mikael Putra',
      Peran: 'Siswa',
      Kelas: 'TK-A',
      Jenjang: 'TK',
      Tingkat: 'TK-A',
      Avatar: 'gajah',
      Persetujuan_Ortu: '2026-07-20',
    },
    {
      ID_Pengguna: 'PET-2026-001',
      Email: 'ecoranger@ypikpamjaya.sch.id',
      Nama: 'Siti Rahma (Eco Ranger)',
      Peran: 'Petugas',
      Kelas: 'XI TKJ 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '11',
      Kartu_RFID: '99AA1122',
      Persetujuan_Ortu: '2026-07-14',
    },
    {
      ID_Pengguna: 'GRU-2026-001',
      Email: 'guru.budi@ypikpamjaya.sch.id',
      Nama: 'Budi Santoso, S.Pd',
      Peran: 'Guru',
      Kelas: '',
      Jenjang: 'SMA/SMK',
      Tingkat: 'Guru',
      Persetujuan_Ortu: '2026-07-01',
    },
    {
      ID_Pengguna: 'GRU-2026-002',
      Email: 'ibu.sari.tk@ypikpamjaya.sch.id',
      Nama: 'Sari Wulandari, S.Pd.AUD',
      Peran: 'Guru',
      Kelas: 'TK-B',
      Jenjang: 'TK',
      Tingkat: 'Guru',
      Persetujuan_Ortu: '2026-07-01',
    },
    {
      ID_Pengguna: 'ADM-2026-001',
      Email: 'admin@ypikpamjaya.sch.id',
      Nama: 'Hendra Kusuma (Admin)',
      Peran: 'Admin',
      Kelas: '',
      Jenjang: 'SMA/SMK',
      Tingkat: 'Admin',
      Persetujuan_Ortu: '2026-07-01',
    },
  ];

  const Kelas: AppDatabase['Kelas'] = [
    { Kelas: 'XI RPL 1', Jenjang: 'SMA/SMK', Tingkat: '11', Wali_Kelas: 'Budi Santoso, S.Pd', Jumlah_Siswa: 32 },
    { Kelas: 'XI TKJ 1', Jenjang: 'SMA/SMK', Tingkat: '11', Wali_Kelas: 'Dewi Lestari, S.Kom', Jumlah_Siswa: 30 },
    { Kelas: 'X DKV 1', Jenjang: 'SMA/SMK', Tingkat: '10', Wali_Kelas: 'Andi Wijaya, S.Sn', Jumlah_Siswa: 28 },
    { Kelas: 'X IPA 1', Jenjang: 'SMA/SMK', Tingkat: '10', Wali_Kelas: 'Novi Handayani, M.Pd', Jumlah_Siswa: 30 },
    { Kelas: 'XII RPL 2', Jenjang: 'SMA/SMK', Tingkat: '12', Wali_Kelas: 'Rina Marlina, M.Pd', Jumlah_Siswa: 31 },
    { Kelas: 'VIII A', Jenjang: 'SMP', Tingkat: '8', Wali_Kelas: 'Agus Salim, S.Pd', Jumlah_Siswa: 29 },
    { Kelas: 'VII B', Jenjang: 'SMP', Tingkat: '7', Wali_Kelas: 'Fitri Handayani, S.Pd', Jumlah_Siswa: 28 },
    { Kelas: 'IX A', Jenjang: 'SMP', Tingkat: '9', Wali_Kelas: 'Taufik Hidayat, S.Si', Jumlah_Siswa: 30 },
    { Kelas: 'SD 5A', Jenjang: 'SD', Tingkat: '5', Wali_Kelas: 'Novianti, S.Pd', Jumlah_Siswa: 26 },
    { Kelas: 'SD 4B', Jenjang: 'SD', Tingkat: '4', Wali_Kelas: 'Yusuf Maulana, S.Pd', Jumlah_Siswa: 25 },
    { Kelas: 'SD 2A', Jenjang: 'SD', Tingkat: '2', Wali_Kelas: 'Ratna Juwita, S.Pd', Kartu_Kelas: 'CCSD002A', Jumlah_Siswa: 24 },
    { Kelas: 'TK-B', Jenjang: 'TK', Tingkat: 'TK-B', Wali_Kelas: 'Sari Wulandari, S.Pd.AUD', Kartu_Kelas: 'CCTK000B', Jumlah_Siswa: 18 },
    { Kelas: 'TK-A', Jenjang: 'TK', Tingkat: 'TK-A', Wali_Kelas: 'Maya Puspita, S.Pd', Kartu_Kelas: 'CCTK000A', Jumlah_Siswa: 16 },
  ];

  const JenisSampah: AppDatabase['JenisSampah'] = [
    {
      Jenis: 'Organik',
      Label_Aplikasi: 'Kompos',
      Contoh: 'Sisa makanan layak kompos, daun kering, kulit buah',
      Satuan: 'kg',
      Poin_per_satuan: 5,
      Warna_Tong: 'Hijau',
      Subjenis: ['Sisa Makanan', 'Daun & Ranting', 'Kulit Buah'],
      Jalur_Input: 'IoT + Manual',
    },
    {
      Jenis: 'Anorganik',
      Label_Aplikasi: 'Daur Ulang',
      Contoh: 'Botol & gelas plastik bersih, kertas, kardus, kaleng',
      Satuan: 'kg',
      Poin_per_satuan: 10,
      Warna_Tong: 'Kuning',
      Subjenis: ['Plastik', 'Kertas/Kardus', 'Logam/Kaleng'],
      Jalur_Input: 'IoT + Manual',
    },
    {
      Jenis: 'Residu',
      Label_Aplikasi: 'Residu',
      Contoh: 'Tisu kotor, styrofoam, sachet kemasan multilapis',
      Satuan: 'kg',
      Poin_per_satuan: 2,
      Warna_Tong: 'Abu-abu',
      Subjenis: ['Kemasan Multilapis', 'Styrofoam', 'Tisu/Lainnya'],
      Jalur_Input: 'IoT + Manual',
    },
    {
      Jenis: 'Elektronik',
      Label_Aplikasi: 'Elektronik/Baterai',
      Contoh: 'Baterai bekas, kabel rusak, charger (khusus Guru & Eco Ranger)',
      Satuan: 'item',
      Poin_per_satuan: 15,
      Warna_Tong: 'Oranye',
      Subjenis: ['Baterai Bekas', 'Kabel/Charger', 'Lampu/Komponen'],
      Jalur_Input: 'Manual saja',
    },
  ];

  const Stations: AppDatabase['Stations'] = [
    {
      Station_ID: 'WS-SMK-01',
      Nama: 'Station Kantin SMA/SMK',
      Lokasi: 'Kantin Utama SMA/SMK',
      Jenjang_Target: 'SMA/SMK',
      MODE_JENJANG: 'UMUM',
      Token: 'rahasia-ecosmart-123',
      Last_Heartbeat: isoAgo(1),
      WiFi_SSID: 'YPIK-SMART-IOT',
      Kompartemen: [
        {
          jenis: 'Organik',
          label: 'Kompos',
          isi_persen: 85,
          berat_hari_ini: 14.8,
          episode_penuh: true,
          waktu_penuh: isoAgo(18),
          terakhir_dikosongkan: daysAgo(1, 15),
        },
        {
          jenis: 'Anorganik',
          label: 'Daur Ulang',
          isi_persen: 62,
          berat_hari_ini: 11.2,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 15),
        },
        {
          jenis: 'Residu',
          label: 'Residu',
          isi_persen: 44,
          berat_hari_ini: 5.4,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(2, 14),
        },
      ],
    },
    {
      Station_ID: 'WS-SMP-01',
      Nama: 'Station Koridor SMP',
      Lokasi: 'Gedung B Lantai 1 SMP',
      Jenjang_Target: 'SMP',
      MODE_JENJANG: 'UMUM',
      Token: 'smp-ecosmart-456',
      Last_Heartbeat: isoAgo(3),
      WiFi_SSID: 'YPIK-SMART-IOT',
      Kompartemen: [
        {
          jenis: 'Organik',
          label: 'Kompos',
          isi_persen: 51,
          berat_hari_ini: 8.6,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 15),
        },
        {
          jenis: 'Anorganik',
          label: 'Daur Ulang',
          isi_persen: 74,
          berat_hari_ini: 9.8,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 15),
        },
        {
          jenis: 'Residu',
          label: 'Residu',
          isi_persen: 38,
          berat_hari_ini: 3.9,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(2, 16),
        },
      ],
    },
    {
      Station_ID: 'WS-SD-01',
      Nama: 'Station Taman SD',
      Lokasi: 'Selasar SD Ramah Anak (70cm)',
      Jenjang_Target: 'SD',
      MODE_JENJANG: 'TK_SD',
      Token: 'sd-ecosmart-789',
      Last_Heartbeat: isoAgo(2),
      WiFi_SSID: 'YPIK-SMART-IOT',
      Kompartemen: [
        {
          jenis: 'Organik',
          label: 'Kompos',
          isi_persen: 46,
          berat_hari_ini: 6.2,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 13),
        },
        {
          jenis: 'Anorganik',
          label: 'Daur Ulang',
          isi_persen: 58,
          berat_hari_ini: 7.4,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 13),
        },
        {
          jenis: 'Residu',
          label: 'Residu',
          isi_persen: 29,
          berat_hari_ini: 2.1,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(2, 13),
        },
      ],
    },
    {
      Station_ID: 'WS-TK-01',
      Nama: 'Station Teras TK',
      Lokasi: 'Teras Bermain TK (70cm)',
      Jenjang_Target: 'TK',
      MODE_JENJANG: 'TK_SD',
      Token: 'tk-ecosmart-101',
      Last_Heartbeat: isoAgo(4),
      WiFi_SSID: 'YPIK-SMART-IOT',
      Kompartemen: [
        {
          jenis: 'Organik',
          label: 'Kompos',
          isi_persen: 35,
          berat_hari_ini: 3.4,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 12),
        },
        {
          jenis: 'Anorganik',
          label: 'Daur Ulang',
          isi_persen: 42,
          berat_hari_ini: 4.1,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(1, 12),
        },
        {
          jenis: 'Residu',
          label: 'Residu',
          isi_persen: 18,
          berat_hari_ini: 1.2,
          episode_penuh: false,
          terakhir_dikosongkan: daysAgo(2, 12),
        },
      ],
    },
  ];

  // Consistent historical + current month deposits across 6 months (Jun 2026 - Nov 2026)
  const Setoran: Setoran[] = [
    // Today / Current Week (Nov 2026)
    {
      ID: 'STR10001',
      Tanggal: isoAgo(18),
      ID_Pengguna: 'SMK-2026-001',
      Tipe_Penyetor: 'Siswa',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Raka Pratama',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Organik',
      Jenis_Awal: 'Organik',
      Subjenis: 'Sisa Makanan',
      Berat_kg: 1.25,
      Status: 'Terverifikasi',
      Poin: 6,
      Sumber: 'IoT',
      Station_ID: 'WS-SMK-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: isoAgo(18),
    },
    {
      ID: 'STR10002',
      Tanggal: isoAgo(42),
      ID_Pengguna: 'SMK-2026-001',
      Tipe_Penyetor: 'Siswa',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Raka Pratama',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Plastik',
      Berat_kg: 0.8,
      Status: 'Menunggu',
      Poin: 8,
      Sumber: 'Manual',
    },
    {
      ID: 'STR10003',
      Tanggal: isoAgo(65),
      ID_Pengguna: 'SMK-2026-002',
      Tipe_Penyetor: 'Siswa',
      Email: 'nadia.putri@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Nadia Putri',
      Kelas: 'XI TKJ 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Kertas/Kardus',
      Berat_kg: 1.5,
      Status: 'Menunggu',
      Poin: 15,
      Sumber: 'Manual',
    },
    {
      ID: 'STR10004',
      Tanggal: isoAgo(95),
      ID_Pengguna: 'SMP-2026-011',
      Tipe_Penyetor: 'Siswa',
      Email: 'alya.azzahra@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Alya Azzahra',
      Kelas: 'VIII A',
      Jenjang: 'SMP',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Plastik',
      Berat_kg: 0.95,
      Status: 'Terverifikasi',
      Poin: 10,
      Sumber: 'IoT',
      Station_ID: 'WS-SMP-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: isoAgo(95),
    },
    {
      ID: 'STR10005',
      Tanggal: isoAgo(130),
      ID_Pengguna: 'TK-B',
      Tipe_Penyetor: 'Kelas',
      Nama_Penyetor: 'Setoran Kolektif TK-B',
      Kelas: 'TK-B',
      Jenjang: 'TK',
      Jenis: 'Organik',
      Jenis_Awal: 'Organik',
      Subjenis: 'Kulit Buah',
      Berat_kg: 0.6,
      Status: 'Terverifikasi',
      Poin: 3,
      Sumber: 'IoT',
      Station_ID: 'WS-TK-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: isoAgo(130),
    },
    {
      ID: 'STR10006',
      Tanggal: isoAgo(180),
      ID_Pengguna: 'SD-2026-041',
      Tipe_Penyetor: 'Siswa',
      Email: 'farhan.kamil@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Farhan Kamil',
      Kelas: 'SD 5A',
      Jenjang: 'SD',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Logam/Kaleng',
      Berat_kg: 0.5,
      Status: 'Menunggu',
      Poin: 5,
      Sumber: 'Manual',
    },
    {
      ID: 'STR10007',
      Tanggal: isoAgo(210),
      ID_Pengguna: 'GRU-2026-001',
      Tipe_Penyetor: 'Siswa',
      Email: 'guru.budi@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Budi Santoso, S.Pd',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Elektronik',
      Jenis_Awal: 'Elektronik',
      Subjenis: 'Baterai Bekas',
      Berat_kg: 0.25,
      Jumlah_item: 4,
      Status: 'Menunggu',
      Poin: 60,
      Sumber: 'Manual',
    },
    // Earlier this week (Nov 2026)
    {
      ID: 'STR10008',
      Tanggal: daysAgo(1, 10),
      ID_Pengguna: 'SMK-2026-001',
      Tipe_Penyetor: 'Siswa',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Raka Pratama',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Plastik',
      Berat_kg: 2.4,
      Status: 'Terverifikasi',
      Poin: 24,
      Sumber: 'IoT',
      Station_ID: 'WS-SMK-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: daysAgo(1, 10),
    },
    {
      ID: 'STR10009',
      Tanggal: daysAgo(1, 11),
      ID_Pengguna: 'SMK-2026-002',
      Tipe_Penyetor: 'Siswa',
      Email: 'nadia.putri@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Nadia Putri',
      Kelas: 'XI TKJ 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Organik',
      Jenis_Awal: 'Organik',
      Berat_kg: 3.1,
      Status: 'Terverifikasi',
      Poin: 16,
      Sumber: 'IoT',
      Station_ID: 'WS-SMK-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: daysAgo(1, 11),
    },
    {
      ID: 'STR10010',
      Tanggal: daysAgo(2, 13),
      ID_Pengguna: 'SMK-2026-001',
      Tipe_Penyetor: 'Siswa',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Raka Pratama',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Residu',
      Jenis_Awal: 'Anorganik', // Corrected by Eco Ranger (styrofoam was mis-sorted as Anorganik)
      Subjenis: 'Styrofoam',
      Berat_kg: 0.7,
      Berat_Awal_kg: 0.8,
      Status: 'Terverifikasi',
      Poin: 1,
      Sumber: 'Manual',
      Diverifikasi_Oleh: 'Siti Rahma (Eco Ranger)',
      Waktu_Verifikasi: daysAgo(2, 14),
    },
    {
      ID: 'STR10011',
      Tanggal: daysAgo(2, 9),
      ID_Pengguna: 'SMK-2026-003',
      Tipe_Penyetor: 'Siswa',
      Email: 'bagas.wijaya@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Bagas Wijaya',
      Kelas: 'X DKV 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Residu',
      Jenis_Awal: 'Residu',
      Berat_kg: 1.6,
      Status: 'Terverifikasi',
      Poin: 3,
      Sumber: 'Manual',
      Diverifikasi_Oleh: 'Siti Rahma (Eco Ranger)',
      Waktu_Verifikasi: daysAgo(2, 10),
    },
    {
      ID: 'STR10012',
      Tanggal: daysAgo(3, 10),
      ID_Pengguna: 'SMP-2026-011',
      Tipe_Penyetor: 'Siswa',
      Email: 'alya.azzahra@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Alya Azzahra',
      Kelas: 'VIII A',
      Jenjang: 'SMP',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Berat_kg: 2.8,
      Status: 'Terverifikasi',
      Poin: 28,
      Sumber: 'IoT',
      Station_ID: 'WS-SMP-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: daysAgo(3, 10),
    },
    {
      ID: 'STR10013',
      Tanggal: daysAgo(3, 11),
      ID_Pengguna: 'SMP-2026-012',
      Tipe_Penyetor: 'Siswa',
      Email: 'dimas.saputra@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Dimas Saputra',
      Kelas: 'VII B',
      Jenjang: 'SMP',
      Jenis: 'Residu',
      Jenis_Awal: 'Residu',
      Berat_kg: 1.9,
      Status: 'Terverifikasi',
      Poin: 4,
      Sumber: 'IoT',
      Station_ID: 'WS-SMP-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: daysAgo(3, 11),
    },
    {
      ID: 'STR10014',
      Tanggal: daysAgo(4, 9),
      ID_Pengguna: 'SD 2A',
      Tipe_Penyetor: 'Kelas',
      Nama_Penyetor: 'Setoran Kolektif SD 2A',
      Kelas: 'SD 2A',
      Jenjang: 'SD',
      Jenis: 'Organik',
      Jenis_Awal: 'Organik',
      Berat_kg: 1.4,
      Status: 'Terverifikasi',
      Poin: 7,
      Sumber: 'IoT',
      Station_ID: 'WS-SD-01',
      Diverifikasi_Oleh: 'Sistem IoT',
      Waktu_Verifikasi: daysAgo(4, 9),
    },
    {
      ID: 'STR10015',
      Tanggal: daysAgo(4, 12),
      ID_Pengguna: 'SD-2026-041',
      Tipe_Penyetor: 'Siswa',
      Email: 'farhan.kamil@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Farhan Kamil',
      Kelas: 'SD 5A',
      Jenjang: 'SD',
      Jenis: 'Anorganik',
      Jenis_Awal: 'Anorganik',
      Subjenis: 'Kertas/Kardus',
      Berat_kg: 1.9,
      Status: 'Terverifikasi',
      Poin: 19,
      Sumber: 'Manual',
      Diverifikasi_Oleh: 'Siti Rahma (Eco Ranger)',
      Waktu_Verifikasi: daysAgo(4, 14),
    },
    // Previous week in Nov 2026 (to trigger Rule-Based Insight FR-DB-04 on Residu rising for X DKV 1)
    {
      ID: 'STR10016',
      Tanggal: daysAgo(9, 10),
      ID_Pengguna: 'SMK-2026-003',
      Tipe_Penyetor: 'Siswa',
      Email: 'bagas.wijaya@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Bagas Wijaya',
      Kelas: 'X DKV 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Residu',
      Jenis_Awal: 'Residu',
      Berat_kg: 1.2,
      Status: 'Terverifikasi',
      Poin: 2,
      Sumber: 'Manual',
      Diverifikasi_Oleh: 'Siti Rahma (Eco Ranger)',
      Waktu_Verifikasi: daysAgo(9, 11),
    },
    {
      ID: 'STR10017',
      Tanggal: daysAgo(16, 10),
      ID_Pengguna: 'SMK-2026-003',
      Tipe_Penyetor: 'Siswa',
      Email: 'bagas.wijaya@ypikpamjaya.sch.id',
      Nama_Penyetor: 'Bagas Wijaya',
      Kelas: 'X DKV 1',
      Jenjang: 'SMA/SMK',
      Jenis: 'Residu',
      Jenis_Awal: 'Residu',
      Berat_kg: 0.7,
      Status: 'Terverifikasi',
      Poin: 1,
      Sumber: 'Manual',
      Diverifikasi_Oleh: 'Siti Rahma (Eco Ranger)',
      Waktu_Verifikasi: daysAgo(16, 11),
    },
  ];

  // Add rich monthly historical records (Jun - Oct 2026 + early Nov 2026) for Laporan Analisis Data Bulanan
  const monthlySeeds: {
    month: string;
    org: number;
    anorg: number;
    res: number;
    iotShare: number;
    accRate: number;
  }[] = [
    { month: '2026-06', org: 42, anorg: 36, res: 38, iotShare: 0.45, accRate: 0.76 },
    { month: '2026-07', org: 48, anorg: 44, res: 34, iotShare: 0.55, accRate: 0.81 },
    { month: '2026-08', org: 56, anorg: 52, res: 31, iotShare: 0.64, accRate: 0.85 },
    { month: '2026-09', org: 64, anorg: 61, res: 27, iotShare: 0.71, accRate: 0.88 },
    { month: '2026-10', org: 72, anorg: 70, res: 24, iotShare: 0.76, accRate: 0.91 },
    { month: '2026-11', org: 68, anorg: 69, res: 17, iotShare: 0.80, accRate: 0.93 },
  ];

  const sampleClasses: { kelas: string; jenjang: Jenjang; user: string; station: string }[] = [
    { kelas: 'XI RPL 1', jenjang: 'SMA/SMK', user: 'SMK-2026-001', station: 'WS-SMK-01' },
    { kelas: 'XI TKJ 1', jenjang: 'SMA/SMK', user: 'SMK-2026-002', station: 'WS-SMK-01' },
    { kelas: 'VIII A', jenjang: 'SMP', user: 'SMP-2026-011', station: 'WS-SMP-01' },
    { kelas: 'SD 5A', jenjang: 'SD', user: 'SD-2026-041', station: 'WS-SD-01' },
    { kelas: 'TK-B', jenjang: 'TK', user: 'TK-B', station: 'WS-TK-01' },
  ];

  let histCounter = 200;
  for (const m of monthlySeeds) {
    const entries: { jenis: JenisKey; total: number }[] = [
      { jenis: 'Organik', total: m.org },
      { jenis: 'Anorganik', total: m.anorg },
      { jenis: 'Residu', total: m.res },
    ];
    for (const e of entries) {
      const chunks = 4;
      const each = Number((e.total / chunks).toFixed(2));
      for (let i = 0; i < chunks; i++) {
        histCounter++;
        const cls = sampleClasses[(histCounter + i) % sampleClasses.length];
        const isIoT = i / chunks < m.iotShare;
        const isMisSorted = !isIoT && i === chunks - 1 && m.accRate < 0.89;
        const poinRate = e.jenis === 'Anorganik' ? 10 : e.jenis === 'Organik' ? 5 : 2;
        const day = 4 + i * 5;
        const dateStr = `${m.month}-${String(day).padStart(2, '0')}T09:${String(10 + i * 7).padStart(2, '0')}:00+07:00`;
        Setoran.push({
          ID: `HST${histCounter}`,
          Tanggal: new Date(dateStr).toISOString(),
          ID_Pengguna: cls.user,
          Tipe_Penyetor: cls.jenjang === 'TK' ? 'Kelas' : 'Siswa',
          Nama_Penyetor: cls.jenjang === 'TK' ? `Setoran Kolektif ${cls.kelas}` : `Siswa ${cls.kelas}`,
          Kelas: cls.kelas,
          Jenjang: cls.jenjang,
          Jenis: e.jenis,
          Jenis_Awal: isMisSorted ? (e.jenis === 'Residu' ? 'Anorganik' : 'Residu') : e.jenis,
          Berat_kg: each,
          Status: 'Terverifikasi',
          Poin: Math.round(each * poinRate),
          Sumber: isIoT ? 'IoT' : 'Manual',
          Station_ID: isIoT ? cls.station : undefined,
          Diverifikasi_Oleh: isIoT ? 'Sistem IoT' : 'Siti Rahma (Eco Ranger)',
          Waktu_Verifikasi: new Date(dateStr).toISOString(),
        });
      }
    }
  }

  const Panduan: AppDatabase['Panduan'] = [
    {
      ID: 'PND-01',
      Jenis: 'Organik',
      Item: 'Sisa Makanan, Daun & Kulit Buah',
      Keterangan: 'Sampah hayati yang dapat terurai alami menjadi kompos di komposter sekolah.',
      Salah_Kaprah: 'Jangan memasukkan sisa kuah berminyak berlebih, tulang keras, atau bungkus plastik makanan ke tong Kompos.',
      Contoh_Masuk: ['Kulit pisang & jeruk', 'Sisa nasi & sayur kering', 'Daun gugur halaman', 'Ampas teh tanpa kantong plastik'],
      Jangan_Masuk: ['Bungkus nasi kertas berlapis plastik', 'Tisu bekas makan', 'Sendok plastik'],
      Jenjang: ['TK', 'SD', 'SMP', 'SMA/SMK'],
    },
    {
      ID: 'PND-02',
      Jenis: 'Anorganik',
      Item: 'Botol Plastik, Kertas, Kardus & Kaleng',
      Keterangan: 'Material bersih dan kering yang bernilai ekonomi dan dapat didaur ulang di Bank Sampah.',
      Salah_Kaprah: 'Styrofoam dan kemasan sachet kopi/snack berlapis foil BUKAN Daur Ulang — keduanya masuk Residu.',
      Contoh_Masuk: ['Botol air mineral kosong', 'Gelas plastik bersih', 'Kertas HVS & buku bekas', 'Kardus kemasan & kaleng minuman'],
      Jangan_Masuk: ['Botol masih berisi penuh air', 'Kertas berminyak kotak pizza', 'Styrofoam & plastik sachet'],
      Jenjang: ['TK', 'SD', 'SMP', 'SMA/SMK'],
    },
    {
      ID: 'PND-03',
      Jenis: 'Residu',
      Item: 'Styrofoam, Sachet Multilapis & Tisu Kotor',
      Keterangan: 'Sampah sulit didaur ulang dan tidak dapat dikomposkan yang berakhir di pengangkutan residu.',
      Salah_Kaprah: 'Banyak siswa mengira tisu kertas bisa masuk Daur Ulang atau Kompos sekolah; tisu kotor/basah wajib masuk Residu.',
      Contoh_Masuk: ['Kemasan snack berlapis aluminium', 'Wadah styrofoam', 'Tisu kotor & masker sekali pakai', 'Sedotan & bungkus permen'],
      Jangan_Masuk: ['Baterai bekas (masuk B3 Elektronik)', 'Botol plastik utuh yang bersih'],
      Jenjang: ['TK', 'SD', 'SMP', 'SMA/SMK'],
    },
    {
      ID: 'PND-04',
      Jenis: 'Elektronik',
      Item: 'Baterai Bekas, Kabel & Charger Rusak',
      Keterangan: 'Limbah B3 berisiko panas atau korsleting. Disimpan di wadah terkunci khusus dan hanya dibuka Guru/Eco Ranger.',
      Salah_Kaprah: 'Jangan pernah membuang baterai litium atau powerbank ke tong Residu karena dapat memicu percikan api.',
      Contoh_Masuk: ['Baterai AA/AAA bekas', 'Kabel data putus', 'Charger/adaptor rusak', 'Flashdisk rusak'],
      Jangan_Masuk: ['Perangkat elektronik milik siswa TK/SD tanpa pendampingan Guru'],
      Jenjang: ['SMP', 'SMA/SMK'],
    },
  ];

  const Kuis_Soal: AppDatabase['Kuis_Soal'] = [
    // SMK (5+)
    {
      ID: 'Q-SMK-1',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Ke kompartemen mana kemasan kopi sachet berlapis aluminium foil harus dibuang?',
      Opsi_A: 'Kompos (Organik)',
      Opsi_B: 'Daur Ulang (Anorganik)',
      Opsi_C: 'Residu',
      Opsi_D: 'Elektronik/Baterai',
      Jawaban: 'C',
      Penjelasan: 'Kemasan sachet multilapis sulit dipisahkan materialnya sehingga masuk ke kategori Residu.',
      Jenis_Terkait: 'Residu',
    },
    {
      ID: 'Q-SMK-2',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Mengapa baterai bekas tidak boleh dibuang ke Smart Waste Station 3 kompartemen biasa?',
      Opsi_A: 'Karena beratnya terlalu ringan untuk sensor',
      Opsi_B: 'Berisiko panas, korsleting, dan termasuk limbah B3',
      Opsi_C: 'Agar poin kelas tidak berkurang',
      Opsi_D: 'Karena tidak terbaca sensor ultrasonik',
      Jawaban: 'B',
      Penjelasan: 'Baterai bekas (terutama litium) termasuk limbah B3 yang butuh wadah tertutup khusus terpisah.',
      Jenis_Terkait: 'Elektronik',
    },
    {
      ID: 'Q-SMK-3',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Sebuah botol plastik air mineral seberat 0,35 kg disetor ke tong Daur Ulang (10 poin/kg). Berapa poin yang didapat kelas?',
      Opsi_A: '3 poin',
      Opsi_B: '3,5 poin',
      Opsi_C: '4 poin',
      Opsi_D: '5 poin',
      Jawaban: 'C',
      Penjelasan: 'Sesuai aturan BR-01: 0,35 × 10 = 3,5 dibulatkan dengan Math.round menjadi 4 poin.',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-SMK-4',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Tisu bekas mengelap meja kantin yang berminyak sebaiknya dimasukkan ke tong mana?',
      Opsi_A: 'Daur Ulang karena berbahan kertas',
      Opsi_B: 'Kompos karena berasal dari serat kayu',
      Opsi_C: 'Residu karena sudah terkontaminasi minyak',
      Opsi_D: 'Bebas di tong mana saja',
      Jawaban: 'C',
      Penjelasan: 'Tisu kotor dan berminyak merusak kualitas kertas daur ulang dan kurang ideal untuk komposter cepat.',
      Jenis_Terkait: 'Residu',
    },
    {
      ID: 'Q-SMK-5',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Apa yang terjadi jika berat sampah di Waste Station kurang dari 20 gram (0,02 kg)?',
      Opsi_A: 'Tetap tercatat 1 poin',
      Opsi_B: 'Data tidak dikirim dan buzzer berbunyi 600 ms',
      Opsi_C: 'Otomatis masuk status Menunggu',
      Opsi_D: 'Tong langsung terkunci',
      Jawaban: 'B',
      Penjelasan: 'Batas minimum pembacaan akurat load cell (BR-05) adalah 20 gram.',
      Jenis_Terkait: 'Organik',
    },
    {
      ID: 'Q-SMK-6',
      Jenjang: 'SMA/SMK',
      Pertanyaan: 'Wadah kotak makanan berbahan styrofoam paling tepat dibuang ke kompartemen?',
      Opsi_A: 'Residu',
      Opsi_B: 'Daur Ulang',
      Opsi_C: 'Kompos',
      Opsi_D: 'Elektronik',
      Jawaban: 'A',
      Penjelasan: 'Styrofoam tidak layak daur ulang di bank sampah sekolah dan masuk Residu.',
      Jenis_Terkait: 'Residu',
    },
    // SMP (5+)
    {
      ID: 'Q-SMP-1',
      Jenjang: 'SMP',
      Pertanyaan: 'Apa dampak utama membuang sampah plastik ke lingkungan terbuka dalam jangka panjang?',
      Opsi_A: 'Menyuburkan tanah',
      Opsi_B: 'Terurai menjadi mikroplastik yang mencemari air',
      Opsi_C: 'Menambah kadar oksigen',
      Opsi_D: 'Hilang dalam 2 hari',
      Jawaban: 'B',
      Penjelasan: 'Plastik terpecah menjadi mikroplastik yang masuk ke rantai makanan dan perairan.',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-SMP-2',
      Jenjang: 'SMP',
      Pertanyaan: 'Kulit buah dan daun kering di halaman sekolah masuk ke tong berwarna?',
      Opsi_A: 'Kuning (Daur Ulang)',
      Opsi_B: 'Hijau (Kompos)',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Merah',
      Jawaban: 'B',
      Penjelasan: 'Tong Hijau dikhususkan untuk sampah Organik/Kompos.',
      Jenis_Terkait: 'Organik',
    },
    {
      ID: 'Q-SMP-3',
      Jenjang: 'SMP',
      Pertanyaan: 'Sebelum memasukkan botol plastik ke tong Daur Ulang (Kuning), langkah terbaik adalah?',
      Opsi_A: 'Mengisinya dengan tanah',
      Opsi_B: 'Mengosongkan sisa air dan meremasnya',
      Opsi_C: 'Membungkusnya dengan tisu basah',
      Opsi_D: 'Memasukkannya bersama sedotan kotor',
      Jawaban: 'B',
      Penjelasan: 'Botol yang kosong dan bersih menjaga kualitas daur ulang dan menghemat ruang tong.',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-SMP-4',
      Jenjang: 'SMP',
      Pertanyaan: 'Jika kelasmu ingin menurunkan persentase Residu sebesar 30% dalam 2 minggu, cara paling efektif adalah?',
      Opsi_A: 'Membawa tempat makan dan botol minum isi ulang dari rumah',
      Opsi_B: 'Membuang plastik sachet ke tong Kompos',
      Opsi_C: 'Tidak menimbang sampah',
      Opsi_D: 'Menumpuk sampah di laci meja',
      Jawaban: 'A',
      Penjelasan: 'Mengurangi kemasan sekali pakai (Reduce) langsung menekan jumlah sampah Residu.',
      Jenis_Terkait: 'Residu',
    },
    {
      ID: 'Q-SMP-5',
      Jenjang: 'SMP',
      Pertanyaan: 'Manakah kelompok sampah yang semuanya masuk tong Daur Ulang?',
      Opsi_A: 'Kaleng minuman, kardus kering, botol PET',
      Opsi_B: 'Styrofoam, daun kering, tisu',
      Opsi_C: 'Sisa roti, kertas HVS, kulit jeruk',
      Opsi_D: 'Bungkus permen, sedotan, sachet kopi',
      Jawaban: 'A',
      Penjelasan: 'Kaleng, kardus kering, dan botol PET bersih semuanya dapat didaur ulang.',
      Jenis_Terkait: 'Anorganik',
    },
    // SD (5+)
    {
      ID: 'Q-SD-1',
      Jenjang: 'SD',
      Pertanyaan: 'Kulit pisang dan sisa apel masuk ke tong warna apa?',
      Opsi_A: 'Hijau (Kompos)',
      Opsi_B: 'Kuning (Daur Ulang)',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Biru',
      Jawaban: 'A',
      Penjelasan: 'Sisa buah bisa diolah menjadi kompos di tong Hijau.',
      Jenis_Terkait: 'Organik',
    },
    {
      ID: 'Q-SD-2',
      Jenjang: 'SD',
      Pertanyaan: 'Botol minum plastik kosong masuk ke tong mana?',
      Opsi_A: 'Tong Hijau',
      Opsi_B: 'Tong Kuning (Daur Ulang)',
      Opsi_C: 'Tong Abu-abu',
      Opsi_D: 'Tong Merah',
      Jawaban: 'B',
      Penjelasan: 'Botol plastik bersih didaur ulang lewat tong Kuning.',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-SD-3',
      Jenjang: 'SD',
      Pertanyaan: 'Apa arti 3R dalam menjaga lingkungan sekolah?',
      Opsi_A: 'Rapi, Rajin, Ramah',
      Opsi_B: 'Kurangi, Pakai Ulang, Daur Ulang',
      Opsi_C: 'Rebus, Rendam, Rakit',
      Opsi_D: 'Ruang, Roda, Rantai',
      Jawaban: 'B',
      Penjelasan: '3R adalah Reduce (Kurangi), Reuse (Pakai Ulang), dan Recycle (Daur Ulang).',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-SD-4',
      Jenjang: 'SD',
      Pertanyaan: 'Bungkus permen dan tisu kotor masuk ke tong mana?',
      Opsi_A: 'Hijau (Kompos)',
      Opsi_B: 'Kuning (Daur Ulang)',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Laci meja',
      Jawaban: 'C',
      Penjelasan: 'Bungkus permen kecil dan tisu kotor masuk ke tong Abu-abu (Residu).',
      Jenis_Terkait: 'Residu',
    },
    {
      ID: 'Q-SD-5',
      Jenjang: 'SD',
      Pertanyaan: 'Kertas gambar bekas yang masih kering masuk ke tong?',
      Opsi_A: 'Kuning (Daur Ulang)',
      Opsi_B: 'Hijau (Kompos)',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Oranye',
      Jawaban: 'A',
      Penjelasan: 'Kertas kering dapat didaur ulang menjadi kertas baru.',
      Jenis_Terkait: 'Anorganik',
    },
    // TK (5+)
    {
      ID: 'Q-TK-1',
      Jenjang: 'TK',
      Pertanyaan: 'Kulit buah pisang masuk tong warna apa?',
      Opsi_A: 'Hijau (Daun & Kompos)',
      Opsi_B: 'Kuning (Botol & Kertas)',
      Opsi_C: 'Abu-abu (Tisu Kotor)',
      Opsi_D: 'Merah',
      Jawaban: 'A',
      Penjelasan: 'Hebat! Kulit buah masuk ke tong Hijau agar jadi kompos tanaman.',
      Jenis_Terkait: 'Organik',
    },
    {
      ID: 'Q-TK-2',
      Jenjang: 'TK',
      Pertanyaan: 'Botol minum plastik kosong masuk tong warna apa?',
      Opsi_A: 'Hijau (Kompos)',
      Opsi_B: 'Kuning (Daur Ulang)',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Ungu',
      Jawaban: 'B',
      Penjelasan: 'Pintar! Botol plastik masuk ke tong Kuning untuk didaur ulang.',
      Jenis_Terkait: 'Anorganik',
    },
    {
      ID: 'Q-TK-3',
      Jenjang: 'TK',
      Pertanyaan: 'Tisu kotor bekas mengelap mulut masuk tong warna apa?',
      Opsi_A: 'Hijau',
      Opsi_B: 'Kuning',
      Opsi_C: 'Abu-abu (Residu)',
      Opsi_D: 'Biru',
      Jawaban: 'C',
      Penjelasan: 'Betul! Tisu kotor masuk ke tong Abu-abu.',
      Jenis_Terkait: 'Residu',
    },
    {
      ID: 'Q-TK-4',
      Jenjang: 'TK',
      Pertanyaan: 'Daun kering yang jatuh di taman masuk tong warna apa?',
      Opsi_A: 'Hijau (Kompos)',
      Opsi_B: 'Kuning',
      Opsi_C: 'Abu-abu',
      Opsi_D: 'Hitam',
      Jawaban: 'A',
      Penjelasan: 'Keren! Daun kering jadi pupuk kompos di tong Hijau.',
      Jenis_Terkait: 'Organik',
    },
    {
      ID: 'Q-TK-5',
      Jenjang: 'TK',
      Pertanyaan: 'Kardus susu kecil yang sudah kosong masuk tong warna apa?',
      Opsi_A: 'Hijau',
      Opsi_B: 'Kuning (Daur Ulang)',
      Opsi_C: 'Abu-abu',
      Opsi_D: 'Putih',
      Jawaban: 'B',
      Penjelasan: 'Bagus! Kardus bersih masuk ke tong Kuning.',
      Jenis_Terkait: 'Anorganik',
    },
  ];

  const Kuis_Hasil: AppDatabase['Kuis_Hasil'] = [
    {
      ID: 'KH-01',
      ID_Pengguna: 'SMK-2026-001',
      Email: 'raka.pratama@ypikpamjaya.sch.id',
      Nama: 'Raka Pratama',
      Kelas: 'XI RPL 1',
      Jenjang: 'SMA/SMK',
      Tanggal: daysAgo(2, 11),
      Skor: 5,
      Total: 5,
    },
    {
      ID: 'KH-02',
      ID_Pengguna: 'SMP-2026-011',
      Email: 'alya.azzahra@ypikpamjaya.sch.id',
      Nama: 'Alya Azzahra',
      Kelas: 'VIII A',
      Jenjang: 'SMP',
      Tanggal: daysAgo(1, 10),
      Skor: 4,
      Total: 5,
    },
    {
      ID: 'KH-03',
      ID_Pengguna: 'SD-2026-041',
      Email: 'farhan.kamil@ypikpamjaya.sch.id',
      Nama: 'Farhan Kamil',
      Kelas: 'SD 5A',
      Jenjang: 'SD',
      Tanggal: daysAgo(3, 9),
      Skor: 5,
      Total: 5,
    },
  ];

  const Observasi_TK: AppDatabase['Observasi_TK'] = [
    {
      ID: 'OBS-01',
      Tanggal: daysAgo(0, 9),
      ID_Pengguna: 'TK-2026-001',
      Nama_Siswa: 'Zara Aulia',
      Kelas: 'TK-B',
      Mandiri_Memilah: true,
      Kenal_Warna_Tong: true,
      Bantu_Teman: true,
      Catatan: 'Membuang kulit pisang ke tong hijau tanpa dibantu.',
      Guru: 'Sari Wulandari, S.Pd.AUD',
    },
    {
      ID: 'OBS-02',
      Tanggal: daysAgo(0, 9),
      ID_Pengguna: 'TK-2026-002',
      Nama_Siswa: 'Kenzo Alvaro',
      Kelas: 'TK-B',
      Mandiri_Memilah: true,
      Kenal_Warna_Tong: false,
      Bantu_Teman: false,
      Catatan: 'Masih perlu diarahkan membedakan tong kuning dan abu-abu.',
      Guru: 'Sari Wulandari, S.Pd.AUD',
    },
  ];

  const Notifikasi_Log: AppDatabase['Notifikasi_Log'] = [
    {
      ID: 'NTF-001',
      Waktu: isoAgo(18),
      Station_ID: 'WS-SMK-01',
      Kompartemen: 'Organik',
      Isi_Persen: 85,
      Penerima: ['ecoranger@ypikpamjaya.sch.id'],
      Pesan: 'Tong Kompos (Organik) WS-SMK-01 penuh 85%, kosongkan ke komposter.',
      Status: 'Aktif',
    },
    {
      ID: 'NTF-000',
      Waktu: daysAgo(1, 13),
      Station_ID: 'WS-SMP-01',
      Kompartemen: 'Anorganik',
      Isi_Persen: 84,
      Penerima: ['ecoranger@ypikpamjaya.sch.id'],
      Pesan: 'Tong Daur Ulang (Anorganik) WS-SMP-01 penuh 84%, segera kosongkan.',
      Status: 'Dikosongkan',
      Waktu_Kosong: daysAgo(1, 14),
      Durasi_Respon_Menit: 52,
      Dikosongkan_Oleh: 'Siti Rahma (Eco Ranger)',
    },
  ];

  const Audit_Log: AppDatabase['Audit_Log'] = [
    {
      ID: 'AUD-001',
      Waktu: daysAgo(2, 14),
      Aktor: 'Siti Rahma (Eco Ranger)',
      Aksi: 'Koreksi Jenis & Berat',
      Detail: 'STR10010 (Raka Pratama): jenis diubah Anorganik -> Residu, berat 0.8 -> 0.7 kg',
    },
  ];

  return {
    Pengguna,
    Kelas,
    JenisSampah,
    Setoran,
    Stations,
    Panduan,
    Kuis_Soal,
    Kuis_Hasil,
    Observasi_TK,
    Notifikasi_Log,
    Audit_Log,
  };
}

let memoryDb: AppDatabase | null = null;

function normalizeLegacyJenjang(db: AppDatabase): boolean {
  let changed = false;
  const fixJ = (val: string): Jenjang => {
    if (val === 'SMK') {
      changed = true;
      return 'SMA/SMK';
    }
    return val as Jenjang;
  };

  for (const u of db.Pengguna) u.Jenjang = fixJ(u.Jenjang);
  for (const k of db.Kelas) k.Jenjang = fixJ(k.Jenjang);
  for (const s of db.Setoran) s.Jenjang = fixJ(s.Jenjang);
  for (const st of db.Stations) {
    if (st.Jenjang_Target !== 'UMUM') {
      st.Jenjang_Target = fixJ(st.Jenjang_Target);
    }
    if (st.Station_ID === 'WS-SMK-01' && st.Nama === 'Station Kantin SMK') {
      st.Nama = 'Station Kantin SMA/SMK';
      st.Lokasi = 'Kantin Utama SMA/SMK';
      changed = true;
    }
  }
  for (const p of db.Panduan) {
    p.Jenjang = p.Jenjang.map((j) => fixJ(j));
  }
  for (const q of db.Kuis_Soal) q.Jenjang = fixJ(q.Jenjang);
  for (const kh of db.Kuis_Hasil) kh.Jenjang = fixJ(kh.Jenjang);

  // Ensure SMA X IPA 1 sample class & student exist cleanly in migrated DBs
  if (!db.Kelas.some((k) => k.Kelas === 'X IPA 1')) {
    db.Kelas.splice(3, 0, {
      Kelas: 'X IPA 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '10',
      Wali_Kelas: 'Novi Handayani, M.Pd',
      Jumlah_Siswa: 30,
    });
    changed = true;
  }
  if (!db.Pengguna.some((u) => u.ID_Pengguna === 'SMA-2026-004')) {
    db.Pengguna.splice(3, 0, {
      ID_Pengguna: 'SMA-2026-004',
      Email: 'siti.aisyah@ypikpamjaya.sch.id',
      Nama: 'Siti Aisyah',
      Peran: 'Siswa',
      Kelas: 'X IPA 1',
      Jenjang: 'SMA/SMK',
      Tingkat: '10',
      Kartu_RFID: '04E1F2A3',
      Persetujuan_Ortu: '2026-07-15',
    });
    changed = true;
  }
  return changed;
}

export function loadDb(): AppDatabase {
  if (memoryDb) return memoryDb;
  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as AppDatabase;
      const migrated = normalizeLegacyJenjang(parsed);
      memoryDb = parsed;
      if (migrated) saveDb(memoryDb);
      return memoryDb;
    }
  } catch {
    // Fallback to initial data
  }
  memoryDb = createInitialData();
  saveDb(memoryDb);
  return memoryDb;
}

export function saveDb(db: AppDatabase): void {
  memoryDb = db;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch {
    // Keep in-memory state if disk write unavailable
  }
}

export function computeMonthlyReport(
  db: AppDatabase,
  jenjangFilter: Jenjang | 'ALL' = 'ALL',
  bulanTarget?: string
): MonthlyAnalyticsReport {
  const verified = db.Setoran.filter(
    (s) =>
      s.Status === 'Terverifikasi' &&
      (jenjangFilter === 'ALL' || s.Jenjang === jenjangFilter)
  );

  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
    'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des',
  ];

  const bucketsMap = new Map<string, Setoran[]>();
  for (const s of verified) {
    const dt = new Date(s.Tanggal);
    const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}`;
    const list = bucketsMap.get(key) || [];
    list.push(s);
    bucketsMap.set(key, list);
  }

  const sortedKeys = Array.from(bucketsMap.keys()).sort();
  const trenBulanan: MonthlyBucket[] = sortedKeys.map((key) => {
    const items = bucketsMap.get(key) || [];
    const [yr, mo] = key.split('-');
    const label = `${monthNames[Number(mo) - 1] || mo} ${yr}`;

    let org = 0;
    let anorg = 0;
    let res = 0;
    let elec = 0;
    let poin = 0;
    let iot = 0;
    let manual = 0;
    let manualAccurate = 0;

    for (const s of items) {
      if (s.Jenis === 'Organik') org += s.Berat_kg;
      else if (s.Jenis === 'Anorganik') anorg += s.Berat_kg;
      else if (s.Jenis === 'Residu') res += s.Berat_kg;
      else if (s.Jenis === 'Elektronik') elec += s.Jumlah_item || 1;

      poin += s.Poin;
      if (s.Sumber === 'IoT') iot++;
      else {
        manual++;
        if (s.Jenis === s.Jenis_Awal) manualAccurate++;
      }
    }

    const totalKg = Number((org + anorg + res).toFixed(2));
    const diversion = totalKg > 0 ? Math.round(((org + anorg) / totalKg) * 100) : 0;
    const accuracy = manual > 0 ? Math.round((manualAccurate / manual) * 100) : 92;

    const monthNotifs = db.Notifikasi_Log.filter(
      (n) => n.Status === 'Dikosongkan' && n.Durasi_Respon_Menit !== undefined
    );
    const avgResp =
      monthNotifs.length > 0
        ? Math.round(
            monthNotifs.reduce((acc, n) => acc + (n.Durasi_Respon_Menit || 0), 0) /
              monthNotifs.length
          )
        : 48;

    return {
      bulan: key,
      label,
      organik_kg: Number(org.toFixed(2)),
      anorganik_kg: Number(anorg.toFixed(2)),
      residu_kg: Number(res.toFixed(2)),
      elektronik_item: elec,
      total_kg: totalKg,
      total_poin: poin,
      setoran_count: items.length,
      iot_count: iot,
      manual_count: manual,
      diversion_rate: diversion,
      accuracy_rate: accuracy,
      avg_response_min: avgResp,
    };
  });

  const activeMonthKey =
    bulanTarget && bucketsMap.has(bulanTarget)
      ? bulanTarget
      : sortedKeys[sortedKeys.length - 1] || '2026-11';
  const currentBucket =
    trenBulanan.find((b) => b.bulan === activeMonthKey) ||
    trenBulanan[trenBulanan.length - 1] || {
      bulan: activeMonthKey,
      label: activeMonthKey,
      organik_kg: 0,
      anorganik_kg: 0,
      residu_kg: 0,
      elektronik_item: 0,
      total_kg: 0,
      total_poin: 0,
      setoran_count: 0,
      iot_count: 0,
      manual_count: 0,
      diversion_rate: 0,
      accuracy_rate: 0,
      avg_response_min: 0,
    };

  const prevIdx = trenBulanan.findIndex((b) => b.bulan === activeMonthKey) - 1;
  const prevBucket = prevIdx >= 0 ? trenBulanan[prevIdx] : undefined;

  const residuChange =
    prevBucket && prevBucket.residu_kg > 0
      ? Number(
          (((currentBucket.residu_kg - prevBucket.residu_kg) / prevBucket.residu_kg) * 100).toFixed(1)
        )
      : 0;

  const currentItems = bucketsMap.get(activeMonthKey) || [];
  const totalSiswaFiltered = db.Kelas.filter(
    (k) => jenjangFilter === 'ALL' || k.Jenjang === jenjangFilter
  ).reduce((sum, k) => sum + k.Jumlah_Siswa, 0);

  const jenjangList: Jenjang[] = ['TK', 'SD', 'SMP', 'SMA/SMK'];
  const perJenjang = jenjangList.map((j) => {
    const jClasses = db.Kelas.filter((k) => k.Jenjang === j);
    const jStudents = jClasses.reduce((sum, k) => sum + k.Jumlah_Siswa, 0);
    const jItems = currentItems.filter((s) => s.Jenjang === j);
    const jOrgAnorg = jItems
      .filter((s) => s.Jenis === 'Organik' || s.Jenis === 'Anorganik')
      .reduce((sum, s) => sum + s.Berat_kg, 0);
    const jKg = jItems.reduce((sum, s) => sum + s.Berat_kg, 0);
    const activeClasses = new Set(jItems.map((s) => s.Kelas)).size;

    return {
      jenjang: j,
      total_kg: Number(jKg.toFixed(2)),
      jumlah_siswa: jStudents,
      kg_per_siswa: jStudents > 0 ? Number((jKg / jStudents).toFixed(2)) : 0,
      kelas_aktif_pct: jClasses.length > 0 ? Math.round((activeClasses / jClasses.length) * 100) : 0,
      diversion_rate: jKg > 0 ? Math.round((jOrgAnorg / jKg) * 100) : 0,
    };
  });

  // Rule-based insights (FR-DB-04)
  const insightOtomatis: MonthlyAnalyticsReport['insightOtomatis'] = [];

  // Check classes with rising residu over 2 weeks
  const now = Date.now();
  const week1 = verified.filter((s) => now - new Date(s.Tanggal).getTime() <= 7 * 86400_000);
  const week2 = verified.filter((s) => {
    const diff = now - new Date(s.Tanggal).getTime();
    return diff > 7 * 86400_000 && diff <= 14 * 86400_000;
  });

  for (const cls of db.Kelas) {
    const r1 = week1.filter((s) => s.Kelas === cls.Kelas && s.Jenis === 'Residu').reduce((a, b) => a + b.Berat_kg, 0);
    const r2 = week2.filter((s) => s.Kelas === cls.Kelas && s.Jenis === 'Residu').reduce((a, b) => a + b.Berat_kg, 0);
    if (r1 > r2 && r2 > 0) {
      insightOtomatis.push({
        id: `ins-res-${cls.Kelas}`,
        tingkat: 'warning',
        judul: `Kenaikan Sampah Residu di Kelas ${cls.Kelas}`,
        deskripsi: `Berat residu ${cls.Kelas} naik dari ${r2.toFixed(1)} kg menjadi ${r1.toFixed(1)} kg dalam 2 minggu terakhir.`,
        rekomendasi: `Saran diskusi PjBL: audit isi kotak bekal dan ajak siswa mengganti kemasan sachet/styrofoam dengan wadah guna ulang.`,
      });
    }
  }

  if (currentBucket.diversion_rate >= 80) {
    insightOtomatis.push({
      id: 'ins-diversion-good',
      tingkat: 'success',
      judul: `Efisiensi Pengalihan Limbah (Diversion Rate) Mencapai ${currentBucket.diversion_rate}%`,
      deskripsi: `${(currentBucket.organik_kg + currentBucket.anorganik_kg).toFixed(1)} kg sampah berhasil dialihkan ke komposter dan bank sampah pada periode ${currentBucket.label}.`,
      rekomendasi: 'Pertahankan edukasi pemilahan di kantin dan jadwalkan panen kompos bersama kelas PjBL SMA/SMK.',
    });
  }

  const activeFull = db.Notifikasi_Log.filter((n) => n.Status === 'Aktif');
  if (activeFull.length > 0) {
    insightOtomatis.push({
      id: 'ins-bin-alert',
      tingkat: 'warning',
      judul: `${activeFull.length} Kompartemen Tong Melewati Batas Kapasitas 80%`,
      deskripsi: activeFull.map((a) => `${a.Station_ID} (${a.Kompartemen} ${a.Isi_Persen}%)`).join(', ') + ' menunggu pengosongan Eco Ranger.',
      rekomendasi: 'Target SLA pengosongan (G4) adalah ≤ 1 hari kerja agar sensor tidak meluap.',
    });
  }

  const totalIot = currentBucket.iot_count;
  const totalAll = currentBucket.setoran_count;
  const iotPct = totalAll > 0 ? Math.round((totalIot / totalAll) * 100) : 0;
  insightOtomatis.push({
    id: 'ins-iot-adopt',
    tingkat: 'info',
    judul: `Adopsi Smart Waste Station IoT: ${iotPct}% (Target PRD G3 ≥ 70%)`,
    deskripsi: `${totalIot} dari ${totalAll} setoran bulan ${currentBucket.label} tercatat otomatis lewat kartu RFID dan load cell.`,
    rekomendasi: 'Dorong siswa menggunakan kartu RFID pribadi atau Kartu Kelas di station untuk mempercepat pencatatan real-time.',
  });

  const residuRatio =
    currentBucket.total_kg > 0
      ? Math.round((currentBucket.residu_kg / currentBucket.total_kg) * 100)
      : 0;

  return {
    generatedAt: new Date().toISOString(),
    periodeBulan: currentBucket.label,
    ringkasan: {
      total_kg: currentBucket.total_kg,
      diversion_rate: currentBucket.diversion_rate,
      residu_ratio: residuRatio,
      akurasi_pilah: currentBucket.accuracy_rate,
      iot_adoption: iotPct,
      avg_response_hours: Number((currentBucket.avg_response_min / 60).toFixed(1)),
      efisiensi_per_siswa_kg:
        totalSiswaFiltered > 0
          ? Number((currentBucket.total_kg / totalSiswaFiltered).toFixed(2))
          : 0,
      perubahan_residu_pct: residuChange,
    },
    trenBulanan,
    perJenjang,
    insightOtomatis,
  };
}
