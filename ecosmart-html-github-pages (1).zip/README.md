# Eco Smart School — YPIK PAM JAYA (Versi HTML)

Aplikasi pemilahan sampah sekolah lintas jenjang (TK, SD, SMP, SMA/SMK) dalam **satu file `index.html`**: tanpa server, tanpa instalasi.

**Coba langsung:** buka `index.html` di browser, atau lihat versi online di GitHub Pages repo ini.

## Akun demo

| Peran | Email |
| --- | --- |
| Admin | `admin@ypikpamjaya.sch.id` |
| Siswa | `raka.pratama@ypikpamjaya.sch.id` |

Akun lain tersedia lewat tombol daftar akun di halaman login.

## Catatan

- Data tersimpan di **localStorage** browser masing-masing pengguna (tidak dibagi antar-perangkat).
- Untuk kembali ke data awal: DevTools → Application → Local Storage → hapus kunci `eco-smart-school:fs:data/db.json`, lalu muat ulang.
- Internet hanya diperlukan untuk memuat font Google; aplikasi tetap berjalan tanpa itu.
